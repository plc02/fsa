/**
 * Gooflow在线流程图设计器
 * Version: 1.3
 * Copyright: foolegg126(sdlddr)
 */
//定义一个区域图类：
function GooFlow(bgDiv,property){
	if (navigator.userAgent.indexOf("MSIE 8.0")>0||navigator.userAgent.indexOf("MSIE 7.0")>0||navigator.userAgent.indexOf("MSIE 6.0")>0)
		GooFlow.prototype.useSVG="";
	else	GooFlow.prototype.useSVG="1";
//初始化区域图的对象
	this.$id=bgDiv.attr("id");
	this.$bgDiv=bgDiv;//最父框架的DIV
	this.$bgDiv.addClass("GooFlow");
	if(GooFlow.prototype.color.font){
		this.$bgDiv.css("color",GooFlow.prototype.color.font);
	}
	if(GooFlow.prototype.color.main){
		this.$bgDiv.append('<style>.GooFlow_tool_btndown{background:'+GooFlow.prototype.color.main+'}</style>');
	}
	var width=(property.width||this.$bgDiv.width());
	var height=(property.height||this.$bgDiv.height());
	this.$bgDiv.css({width:width+"px",height:height+"px"});
	this.$tool=null;//左侧工具栏对象
	this.$head=null;//顶部标签及工具栏按钮
	this.$title="FSA";//流程图的名称
	//this.$nodeRemark={};//每一种结点或按钮的说明文字,JSON格式,key为类名,value为用户自定义文字说明
	this.$nowType="cursor";//当前要绘制的对象类型
	this.$lineData={};
	this.$lineCount=0;
	this.$nodeData={};
	this.$nodeCount=0;
	this.$areaData={};
	this.$areaCount=0;
	this.$lineDom={};
	this.$nodeDom={};
	this.$areaDom={};
	this.$slotMsg={};
	this.$divSlotMsg=null;
	this.$divSlotTxt=null;
	this.$divSlotCtrl=null;
	this.$divSlotHead=null;
	this.$divTmpSlot=null;
	this.$oldSlotName="";
	this.$oldSlotTxt="";
	this.$usedSlots={};
	this.$endNodes=[];//控制结束结点的颜色
	this.$moveDivLines={};
	this.$moveDivNodes={};
	this.$RightGo=0;//图形区域右扩展标志
	this.$DownGo=0;//图形区域下扩展标志
	this.$max=1;//计算默认ID值的起始SEQUENCE
	this.$focus="";//当前被选定的结点/转换线ID,如果没选中或者工作区被清空,则为""
	this.$cursor="default";//鼠标指针在工作区内的样式
	this.$editable=false;//工作区是否可编辑
	this.$deletedItem={};//在流程图的编辑操作中被删除掉的元素ID集合,元素ID为KEY,元素类型(node,line.area)为VALUE
	this.$workExtendStep=200;//在自动/手动扩展可编辑区时，一次扩展后宽/高增加多少像素
	this.$scale=1.00;//工作区内容的缩放比例，从0.1至无穷大，初始默认为1
	var headHeight=0;
	var tmp="";
	var color_main = GooFlow.prototype.color.main;
	tmp ="<div class='GooFlow_head' style='border-bottom-color:"+color_main+"'>";
	tmp+="<label title='"+this.$title+"' style='background:"+color_main+"'>"+this.$title+"</label>";
	tmp+="<a href='"+document.URL+"' target='_blank' class='GooFlow_head_btn' title='新建流程'><i class='ico_new'></i></a>";
	tmp+="<a href='javascript:void(0)' class='GooFlow_head_btn' title='打开文件'><i class='ico_open'></i></a>";
	tmp+="<a href='javascript:void(0)' class='GooFlow_head_btn' title='保存结果,ctrl+S'><i class='ico_save'></i></a>";
	tmp+="<a href='javascript:void(0)' class='GooFlow_head_btn' title='撤销,ctrl+Z'><i class='ico_undo'></i></a>";
	tmp+="<a href='javascript:void(0)' class='GooFlow_head_btn' title='重做'><i class='ico_redo'></i></a>";
	tmp+="<a href='javascript:void(0)' class='GooFlow_head_btn' title='重构网络,ctrl+R'><i class='ico_reload'></i></a>";
	tmp+="<a href='javascript:void(0)' class='GooFlow_head_btn' title='工作区扩展,ctrl+->' ><i class='ico_youxiashixin'></i></a>";
	tmp+="<a href='javascript:void(0)' class='GooFlow_head_btn' title='编辑槽信息,ctrl+H' ><i class='ico_slot'></i></a>";
	tmp+="<a href='javascript:void(0)' class='GooFlow_head_btn' title='清空网络,ctrl+D' ><i class='ico_QingKong'></i></a>";
	tmp+="<a href='javascript:void(0)' class='GooFlow_head_btn' title='查找路径' ><i class='ico_Find'></i></a>";
	tmp+="</div>";
	this.$head=$(tmp);
	this.$bgDiv.append(this.$head);
	$("#logbox").on("dblclick",function(){
		if(this.style.height=="30px")
			this.style.height="200px";
		else
			this.style.height="30px";
	});
	$("#logbox")[0].onblur=function()
	{
		this.style.height="30px";
	}
	this.$bgDiv[0].ondragover=function(e){
		e.preventDefault();
	}
	this.X_c=0;
	this.Y_c=0;
	this.vX_c=0;
	this.vY_c=0;
	this.findDivMove=false;
	this.slotMsgMove=false;
	var tmpThis=this;
	this.$bgDiv[0].ondrop=function(e){
		e.preventDefault();
		var ev=mousePosition(e);
		tmpThis.X_c=ev.x-tmpThis.vX_c;
		tmpThis.Y_c=ev.y-tmpThis.vY_c;
		if(tmpThis.findDivMove)
		{
			$("#findPathDiv")[0].style.left=tmpThis.X_c+'px';
			$("#findPathDiv")[0].style.top=tmpThis.Y_c+'px';
			tmpThis.findDivMove=false;
		}
		if(tmpThis.slotMsgMove)
		{
			$("#slotMsgCheck")[0].style.left=tmpThis.X_c+'px';
			$("#slotMsgCheck")[0].style.top=tmpThis.Y_c+'px';
			tmpThis.slotMsgMove=false;
		}
	}
	headHeight=28;
		//以下是当工具栏按钮被点击时触发的事件自定义(虚函数),格式为function(),因为可直接用THIS操作对象本身,不用传参；用户可自行重定义:
		function loadFSA(filestr,This)
		{
			This.QingKong();
			var nodes={};
			var nodesArr=[];
			var lines={};
			var slots={};
			var slotOnly=[];
			var initnum=0;
			var tmpNodeMsg={};
			var filearr=filestr.trim().split(";");
			if(filearr.length<3)
			{
				This.addLog("文件格式不对",true);
				return false;
			}
			if(filearr[0].trim().slice(0,4)!="#FSA")
			{
				This.addLog("文件头为#FSA",true);
				return false;
			}
			//添加槽内信息
			for(var i = 2;i<filearr.length-1;i++)
			{
				var tmparr=filearr[i].trim().split(":");
				var slot_words=[];
				var tmpwordarr=tmparr[1].split("|");
				for(var j=0; j<tmpwordarr.length;j++)
				{
					slot_words.push(tmpwordarr[j].trim());
				}
				var tmpSlotName=tmparr[0].trim().slice(1,tmparr[0].trim().length-1);
				slots[tmpSlotName]=slot_words;
				slotOnly.push(tmpSlotName);
			}
			var tmpslotheadarr=filearr[1].trim().split("\n");
			for(var i =0;i<tmpslotheadarr.length;i++)
			{
				var tmpheadstr=tmpslotheadarr[i].replace(/ /g,"");
				if(tmpheadstr=="")
					break;
				var tmpflag=false;
				var tmpheadstrarr=tmpheadstr.split("\t");
				var leftid=tmpheadstrarr[0];
				for(var m=0;m<nodesArr.length;m++)
				{
					if(leftid==nodesArr[m])
					{
						tmpflag=true;
						break;
					}
				}
				if(!tmpflag)
					nodesArr.push(leftid);
				tmpflag=false;
				var rightid=tmpheadstrarr[1];
				for(var m=0;m<nodesArr.length;m++)
				{
					if(rightid==nodesArr[m])
					{
						tmpflag=true;
						break;
					}
				}
				if(!tmpflag)
					nodesArr.push(rightid);
				var arcname=tmpheadstrarr[2].trim();
				var dashflag = false;
				var tmptype="cl";
				if(arcname=="-")
				{
					dashflag=true;
					tmptype="xl";
				}else
				{
					if(arcname.indexOf('<')>-1)
					{
						arcname=arcname.replace(/<|>/g,"");
						if(escape(arcname).indexOf("%u")>=0)
						{
							alert("槽名不能含有中文");
							This.addLog("槽名不能含有中文",true);
							return false;
						}
						if(!isNaN(arcname.slice(0,1)))
						{
							alert("槽名不能以数字开头，只能以字母开头");
							This.addLog("槽名不能以数字开头，只能以字母开头",true);
							return false;
						}
						var regx=/^[A-Za-z0-9]*$/;
						if(!regx.test(arcname))
						{
							alert("槽名只能是数字和字母组合");
							This.addLog("槽名只能是数字和字母组合",true);
							return false;
						}
					}
					else
					{
						for(var k=0;k<slotOnly.length;k++)
						{
							if(slotOnly[k]==arcname)
							{
								alert("弧名"+arcname+"与槽名重复了");
								This.addLog("弧名"+arcname+"与槽名重复了",true);
								return false;
							}
						}
						slots[arcname]=[];
						tmptype="al";
					}
				}
				tmpflag=false;
				for(var j in lines)
				{
					if(leftid===lines[j].from && rightid===lines[j].to)
					{
						if(lines[j]["type"].length==3)
						{
							alert("两结点中弧数量超过2个");
							This.addLog("结点"+lines[j].from+"与结点"+lines[j].to+"之间的弧数量大于两个，请修改",true);
							return false;
						}
						if(!dashflag)
						{
							if(lines[j]["type"]!="xl")
							{
								alert("两结点中有2条实弧");
								This.addLog("结点"+lines[j].from+"与结点"+lines[j].to+"之间有两条实弧，请修改",true);
								return false;
							}
							lines[j]["name"]=arcname;
							if(tmptype=="cl")
								lines[j]["type"]="cxl";
							else if(tmptype=="al")
								lines[j]["type"]="axl";
						}else
						{
							if(lines[j]["type"]=="xl")
							{
								alert("两结点中有2条虚弧");
								This.addLog("结点"+lines[j].from+"与结点"+lines[j].to+"之间有两条虚弧，请修改",true);
								return false;
							}
							if(lines[j]["type"]=="cl")
								lines[j]["type"]="cxl";
							else if(lines[j]["type"]=="al")
								lines[j]["type"]="axl";
						}
						lines[j]["dash"]=false;
						tmpflag=true;
						break;
					}
				}
				if(!tmpflag)
				{
					lines[i]={"type":tmptype,"from":leftid,"to":rightid,"name":arcname,"dash":dashflag,"alt":true};
					if(!tmpNodeMsg[leftid])
					{
						tmpNodeMsg[leftid]={"in":0,"out":1};
					}else
					{
						tmpNodeMsg[leftid].out++;
					}
					if(!tmpNodeMsg[rightid])
					{
						tmpNodeMsg[rightid]={"in":1,"out":0};
					}else
					{
						tmpNodeMsg[rightid].in++;
					}
				}
				initnum++;
			}
			//检测fsa网络是否有误
			var tmpIn=0,tmpInArr=[];
			for(var i in tmpNodeMsg)
			{
				if(tmpNodeMsg[i].in==0)
				{
					tmpIn++;
					tmpInArr.push(i);
					if(tmpNodeMsg[i].out==0)
					{
						alert("node:"+i+"既没有入弧也没有出弧");
						This.addLog("node:"+i+"既没有入弧也没有出弧，请修改FSA文件",true);
						return false;
					}
				}
			}
			if(tmpIn!=1)
			{
				if(tmpIn>1)
				{
					alert("网络有多个开始结点");
					var logtxt="网络有多个开始结点:";
					for(var i=0;i<tmpInArr.length;i++)
						logtxt+=tmpInArr[i]+",";
					This.addLog(logtxt,true);
				}else
				{
					alert("网络没有开始结点");
					This.addLog("网络没有开始结点",true);
				}
				return false;
			}
			//添加结点信息
			for(var i=0;i<nodesArr.length;i++)
			{
				nodes[i.toString()]={"name":i,"left":0,"top":0,"type":"end round","width":28,"height":28,"alt":true};
			}
			var g=new dagre.graphlib.Graph();
			g.setGraph({});
			g.setDefaultEdgeLabel(function(){return {};});
			var outNodes={};
			for(var i in nodes)
			{
				outNodes[i]=0;
				g.setNode(i,{label:i,width:28,height:28});
			}
			for(var i in lines)
			{
				outNodes[lines[i].from]++;
				g.setEdge(lines[i].from,lines[i].to);
			}
			dagre.layout(g);
			for(var i in This.$nodeData)
			{
				This.delNode(i,false);
			}
			This.$slotMsg=slots;
			This.$usedSlots={};//初始化槽标记
			This.$max=nodesArr.length;
			for(var i in nodes)
			{
				nodes[i].left=g._nodes[i].y+10;
				nodes[i].top=g._nodes[i].x+50;
			    This.addNode(i,nodes[i]);
			}
			for(var i in outNodes)
			{
				if(outNodes[i]==0)
					This.$nodeDom[i].css({"background-color":"#ff0000"});
			}
			for(var i in lines)
			{
				var mm=lines[i].from+"\x01"+lines[i].to+"\x01"+"\x00";
				var nn=g._edgeLabels;
				var arrobj;
				for(var j in nn)
				{
					if(mm===j)
					{
						arrobj=nn[j].points;
						break;
					}
				}
				if(arrobj.length<=2)
				    This.addLine(i+initnum,lines[i]);
				else if(arrobj.length>2)
					This.addDuodianLine(i+initnum,arrobj,lines[i]);
			}
			return true;
		}

		//this.onBtnOpenClick=null;//打开流程图按钮定义
		function opensth(obj)
		{
			if($("#filename")[0].value!="")
			{
				var reader = new FileReader();
				var str=null;
				try{
					reader.readAsText($("#filename")[0].files[0],"UTF-8");
				}
				catch(eee)
				{
					alert("cannot open this file");
					obj.addLog("cannot open this file",true);
					return;
				}	
				reader.onload=function(){
					str=reader.result;
					if(str != "")
					{
						if(loadFSA(str,obj))
							obj.addLog("网络加载成功："+str);
					}else
					{
						alert("文件"+$("#filename")[0].value+"没有可读取内容");
						obj.addLog("文件"+$("#filename")[0].value+"没有可读取内容",true);
					}
				}
			}
		}
		this.onBtnOpenClick=function()
		{
			$("#openfsa").remove();
			var tmpdiv = $("<div id='openfsa' style='visibility:hidden;'><input type='file' id='filename' onchange=''></input></div>");
		    this.$workArea.append(tmpdiv);
			var This=this;
			$("#filename").on("change",function(e){
				opensth(This);
				$("#openfsa").remove();
			});
			$("#filename").click();			
		}
		this.QingKong=function()
		{
			this.clearDivSlotArc("");
			this.clearSlotMsg();
			for(var i in this.$nodeData)
			{
				this.delNode(i,false);
			}
			this.$moveDivLines={};
			this.$moveDivNodes={};
			this.$endNodes=[];
			this.$focus="";
			this.$lineCount=0;
			this.$nodeCount=0;
			this.$slotMsg={};
			this.$usedSlots={};
			this.$redoStack=[];
			this.$undoStack=[];
			this.$oldSlotName="";
			this.$max=1;
			this.addLog("网络信息已经全部删除",true);
		}
		this.onBtnSaveClick = function()//save to FSA.txt
		{
			var This =this;
			if(JSON.stringify(This.$nodeData)=="{}")
			{
				alert("没有网络可以保存");
				This.addLog("没有网络可以保存",true);
				return;
			}
			if(JSON.stringify(This.$lineData)=="{}")
			{
				alert("网络中没有连线，不能保存");
				This.addLog("网络中没有连线，不能保存",true);
				return;
			}
			This.onFreshClick();
			var startNodeid=0;
			function nodeMsg(inputNum,outNum,outNodes,isUsed,nodeId)
			{
				this.inputNum = inputNum;
				this.outNum = outNum;
				this.outNodes=outNodes;
				this.isUsed=isUsed;
				this.nodeId=nodeId;
			}
			var outMsg={};
			for(var x in This.$nodeData)
			{
				var tmpOutNodes=[];
				var tmpMsg=new nodeMsg(0,0,tmpOutNodes,false,0);
				outMsg[x]=tmpMsg;
			}
			var cotrl=[];
			var nodeid = 0;
			for(var x in This.$lineData)
			{
				if(This.$lineData[x].type==="cxl" || This.$lineData[x].type==="axl")
				{
					outMsg[This.$lineData[x].from].outNum+=2;
					outMsg[This.$lineData[x].from].outNodes.push(This.$lineData[x].to);
					outMsg[This.$lineData[x].from].outNodes.push(This.$lineData[x].to);
					outMsg[This.$lineData[x].to].inputNum+=2;
				}else
				{
					outMsg[This.$lineData[x].from].outNum++;
					outMsg[This.$lineData[x].from].outNodes.push(This.$lineData[x].to);
					outMsg[This.$lineData[x].to].inputNum++;
				}
			}
			var tmpStartNodes=0;
			for(var i in outMsg)
			{
				if(outMsg[i].inputNum == 0)
				{
					cotrl.push(i);
					startNodeid=i;
					outMsg[i].nodeId = nodeid;
					nodeid++;
					tmpStartNodes++;
				}
			}
			if(tmpStartNodes!=1)
			{
				if(tmpStartNodes>1)
				{
					alert("至少有两个结点没有入弧");
					This.addLog("至少有两个结点没有入弧",true);
				}else
				{
					alert("网络没有开始结点");
					This.addLog("网络没有开始结点",true);
				}
				return;
			}
			var count =0;
			while(count < This.$nodeCount)
			{
				if(cotrl.length==0)
					break;
				var tmpStr = cotrl.shift();
				for(var i in outMsg[tmpStr].outNodes)
				{
					outMsg[outMsg[tmpStr].outNodes[i]].inputNum--;
					if(outMsg[outMsg[tmpStr].outNodes[i]].inputNum == 0 && !outMsg[outMsg[tmpStr].outNodes[i]].isUsed)
					{
						cotrl.push(outMsg[tmpStr].outNodes[i]);
						outMsg[outMsg[tmpStr].outNodes[i]].nodeId = nodeid;
						nodeid++;
						outMsg[outMsg[tmpStr].outNodes[i]].isUsed = true;
					}
				}
				count++;
			}
			//检查是否为多个网络
			var tmpNodes={},tmpLines=This.$lineData;
			for(var j in This.$nodeData)
			{
				tmpNodes[j]=0;
			}
			cotrl.push(startNodeid);
			tmpNodes[startNodeid]++;
			while(cotrl.length>0)
			{
				var tmpNodeid=cotrl.shift();
				for(var k in tmpLines)
				{
					if(tmpNodeid==tmpLines[k].from)
					{
						tmpNodes[tmpLines[k].to]++;
						var tmpFlag=false;
						for(var l=0;l<cotrl.length;l++)
						{
							if(cotrl[l]==tmpLines[k].to)
							{
								tmpFlag=true;
								break;
							}
						}
						if(!tmpFlag)
							cotrl.push(tmpLines[k].to);
					}
				}
			}
			for(var j in tmpNodes)
			{
				if(tmpNodes[j]==0)
				{
					This.onFreshClick();
					alert("含有多个网络");
					This.addLog("含有多个网络",true);
					return;
				}
			}
			//写到文件中，按照左右结点数值大小排序
			function WriteMsg(i,j,slot)
			{
				this.LNode=i;
				this.RNode=j;
				this.slotName=slot;
			}
			var writemsg = [];
			for(var i in This.$lineData)
			{
				var ln = outMsg[This.$lineData[i].from].nodeId;
				var rn = outMsg[This.$lineData[i].to].nodeId;
				var slot = This.$lineData[i].name;
				var tmpMsg1="",tmpMsg2="";
				if(This.$lineData[i].type==="cxl" || This.$lineData[i].type==="axl")
				{
					tmpMsg2=new WriteMsg(ln,rn,"-");
				}
				tmpMsg1 = new WriteMsg(ln,rn,slot);
				var len = writemsg.length;
				for(var j=0;j<len;j++)
				{
					var lflag=false;
					var rflag=false;
					if(ln<writemsg[j].LNode)
					{
						if(tmpMsg2!="")
							writemsg.splice(j,0,tmpMsg1,tmpMsg2);
						else
							writemsg.splice(j,0,tmpMsg1);
						break;
					}
					if(ln ==writemsg[j].LNode)
					{
						if(rn <= writemsg[j].RNode)
						{
							if(tmpMsg2!="")
								writemsg.splice(j,0,tmpMsg1,tmpMsg2);
							else
								writemsg.splice(j,0,tmpMsg1);
							break;
						}else
						{
							continue;
						}
					}
				}
				if(len == writemsg.length)
				{
					if(tmpMsg2!="")
						writemsg.push(tmpMsg2);
					writemsg.push(tmpMsg1);
				}
			}
			var WriteStr = "#FSA 1.0;\r\n";
			for(var i in writemsg)
			{
				WriteStr += writemsg[i].LNode.toString()+"\t"+writemsg[i].RNode.toString()+"\t";
				if(writemsg[i].slotName == "-")
				{
					WriteStr+=writemsg[i].slotName+"\r\n";
				}else
				{
					if(This.$slotMsg[writemsg[i].slotName].length==0)
						WriteStr+=writemsg[i].slotName+"\r\n";
					else
						WriteStr+="<"+writemsg[i].slotName+">"+"\r\n";
				}
			}
			WriteStr+=";\r\n";
			for(var i in This.$slotMsg)
			{
				if(This.$slotMsg[i].length==0)
					continue;
				WriteStr+="<"+i+">:";
				for(var j =0;j< This.$slotMsg[i].length-1;j++)
				{
					WriteStr+=This.$slotMsg[i][j]+"|";
					if(j%10==9)
						WriteStr+="\r\n";
				}
				WriteStr+=This.$slotMsg[i][j]+";\r\n";
			}
			var exprot_data = new Blob([WriteStr]);
			// var dataURL=window.URL || window.webkitURL || window;
			var a = document.createElementNS("http://www.w3.org/1999/xhtml", "a"),
				tmpStr=encodeURIComponent(WriteStr);
			a.href = "data:text;charset=UTF-8,"+tmpStr;//dataURL.createObjectURL(exprot_data);//\ufeff
			//a.href =URL.createObjectURL(exprot_data);
			a.download = "fsa.txt";  //设定下载名称
			document.body.appendChild(a);
			a.click(); //点击触发下载
			document.body.removeChild(a);
			console.log(WriteStr);
		}

		//this.onFreshClick=null;//重载流程图按钮定义
		this.onFreshClick=function()
		{
			if(JSON.stringify(this.$nodeData)=="{}")
				return;
			var tmpRedo=this.$redoStack;
			var tmpUndo=this.$undoStack;
			var outNodes={};
			this.$moveDivLines={};
			this.$moveDivNodes={};
			this.$redoStack=[];
			this.$undoStack=[];
			this.$usedSlots={};
			this.$endNodes=[];
			var g=new dagre.graphlib.Graph();
			g.setGraph({});
			g.setDefaultEdgeLabel(function(){return {};});
			for(var i in this.$nodeData)
			{
				outNodes[i]=0;
				g.setNode(i,{label:i,width:28,height:28});
			}
			for(var i in this.$lineData)
			{
				outNodes[this.$lineData[i].from]++;
				g.setEdge(this.$lineData[i].from,this.$lineData[i].to);
			}
			dagre.layout(g);
			for(var i in this.$nodeData)
			{
				this.$nodeDom[i].remove();
				delete this.$nodeDom[i];
				this.$nodeData[i].left=g._nodes[i].y+10;
				this.$nodeData[i].top=g._nodes[i].x+50;
			    this.addNode(i,this.$nodeData[i]);
				//this.$endNodes.push(i);
			}
			for(var i in this.$lineData)
			{
				this.$lineDom[i].remove();
				delete this.$lineDom[i];
				var mm=this.$lineData[i].from+"\x01"+this.$lineData[i].to+"\x01"+"\x00";
				var nn=g._edgeLabels;
				var arrobj;
				for(var j in nn)
				{
					if(mm===j)
					{
						arrobj=nn[j].points;
						break;
					}
				}
				
				if(arrobj.length<=2)
				    this.addLine(i+this.$max,this.$lineData[i]);
				else if(arrobj.length>2)
				{
					var lineData=this.$lineData[i];
					if(lineData.type=="xl")
						lineData.dash=true;
					if(lineData.name.trim()=="")
						lineData.name="-";
					this.$lineDom[i]=GooFlow.prototype.drawPolyLine(i,arrobj,lineData,this.$scale,this);
					this.$draw.appendChild(this.$lineDom[i]);
					for(var j=0;j<this.$endNodes.length;j++)
					{
						if(this.$endNodes[j]==this.$lineData[i].from)
						{
							this.$endNodes.splice(j,1);
							this.$nodeDom[this.$lineData[i].from].css({"background-color":"#c0ccda"});
							break;
						}
					}
					if(lineData.name!="-" && this.$slotMsg[lineData.name].length==0)
						$("#"+i)[0].childNodes[1].setAttribute("stroke","#FF0000");
				}
			}
			this.$redoStack=tmpRedo;
			this.$undoStack=tmpUndo;
			this.addLog("网络重构成功");
		}
		this.$head.on("click",{inthis:this},function(e){
			if(!e)e=window.event;
			var tar=e.target;
			$("#choseDiv").hide();
			if(tar.tagName=="DIV"||tar.tagName=="SPAN")	return;
			else if(tar.tagName=="A")	tar=tar.childNodes[0];
			var This=e.data.inthis;
			//定义顶部操作栏按钮的事件
			switch($(tar).attr("class")){
				case "ico_open":
					if(This.onBtnOpenClick!=null)
						This.onBtnOpenClick();
					break;
				case "ico_save":	
				    if(This.onBtnSaveClick!=null)	
					{
				        This.onBtnSaveClick();
					}
					break;
				case "ico_undo":	This.undo();break;
				case "ico_redo":	This.redo();break;
				case "ico_reload":
					if(This.onFreshClick!=null)
					{
						try{
							This.onFreshClick();
						}catch(ee)
						{
							This.addLog("网络重构失败",true);
						}
					}
					break;
				case "ico_youxiashixin":
					This.$workArea.children(".Gooflow_extend_right").click();
					This.$RightGo++;
					//This.$workArea.children(".Gooflow_extend_bottom").click();
					break;
				case "ico_slot":
					This.showSlotMsg();
					break;
				case "ico_QingKong":
					$("qingKongDiv").remove();
					if(JSON.stringify(This.$nodeData)=="{}")
					{
						This.addLog("没有任何网络信息",true);
						break;
					}
					var qingKongDiv=$("<div id='qingKongDiv' style='display:block;z-index:200;position:fixed;left:50%;bottom:50%;width:200px;height:160px;border-color:black;border-width:3px;border-style:solid'><div style='background-color:white;width:100%;height:50%'>删除后网络信息将彻底消失，请确定是否删除</div>\
				<div style='background-color:grey;width:100%;height:50%'><input type='submit' style='position:relative;left:20px;top:30px' value='确定'></input><input type='submit' style='position:relative;left:80px;top:30px' value='取消'></input></div></div>");
					This.$bgDiv.append(qingKongDiv);
					qingKongDiv.click("on",function(e){
						var tar=e.target;
						if(tar.value=="确定")
						{
							This.QingKong();
							qingKongDiv.remove();
						}
						if(tar.value=="取消")
							qingKongDiv.remove();
					});
					break;
				case "ico_Find":
					$("#findPathDiv").remove();
					var tmpDivFind=$("<div id='findPathDiv' draggable='true' style='border-style:solid;border-color:black;border-width:3px;background-color:#C0C0C0;position:absolute;left:200px;top:100px;height:400px;width:400px;'></div>");
					var tmpDiv1=$("<div id='findPathDivHead' title='搜索规则为：回车用于区分多条语句；空格为英文分词（中文的空格将被忽略）；“\\”用于将句子分开。中文搜索只识别回车符和“\\”,中英混合视为中文搜索。搜索信息将显示在下面的灰色显示框内。' style='width:100%;height:40px;background-color:white'>路径查找</div>");
					tmpDivFind.append(tmpDiv1);
					tmpDiv1=$("<div style='width:100%;height:100px'><textarea type='text' id='findPathTxt' style='left:float;top:40px;width:340px;height:100px;display:block;resize:none'></textarea><input id='findPathSub' type='submit' style='float:right;width:50px;height:100px' value='搜索'></input></div>");
					tmpDivFind.append(tmpDiv1);
					tmpDiv1=$("<textarea id='findPathMsg' readonly title='搜索结果显示框，双击显示框变大' style='background-color:#f0f0f0;left:1px;top:141px;width:100%;height:220px;display:block'></textarea>");
					tmpDivFind.append(tmpDiv1);
					tmpDiv1=$("<div style='position:absolute;left:1px;top:365px'><input id='closeFindPathSub' type='submit' value='关闭'></input></div>");
					tmpDivFind.append(tmpDiv1);
					This.$bgDiv.append(tmpDivFind);
					$("#findPathMsg")[0].ondblclick=function(){
						if(this.style.width=="100%")
						{
							this.style.width="800px";
							this.style.height="300px";
						}else
						{
							this.style.width="100%";
							this.style.height="220px";
						}
					}
					$("#findPathMsg")[0].onblur=function(){
						this.style.width="100%";
						this.style.height="220px";
					}
					$("#findPathDiv")[0].ondragstart=function(e){
						e.dataTransfer.setData("Text","findPathDivHead");
						var ev=mousePosition(e),
							t=This.t;
						This.X_c=ev.x-t.left+This.$workArea[0].parentNode.scrollLeft;
						This.Y_c=ev.y-t.top+This.$workArea[0].parentNode.scrollTop;
						This.vX_c=ev.x-$("#findPathDiv")[0].offsetLeft*This.$scale;
						This.vY_c=ev.y-$("#findPathDiv")[0].offsetTop*This.$scale;
						This.findDivMove=true;
					}
					$("#closeFindPathSub").click({inthis:this},function(e){
						$("#findPathDiv").remove();
					});
					var timer=null;
					$("#findPathSub").click({inthis:this},function(e){
						$("#findPathMsg")[0].value="";
						var ii=0;
						clearInterval(timer);
						if($("#findPathTxt")[0].value.trim().length==0)
						{
							$("#findPathMsg")[0].value="请输入要搜索的语句";
							timer=setInterval(function(){
								$("#findPathTxt")[0].style.backgroundColor=ii++%2?"red":"";
								ii>8&&clearInterval(timer);
							},100);
							return;
						}
						if(JSON.stringify(This.$lineData)=="{}")
						{
							$("#findPathMsg")[0].value="不存在一条可用路径或者网络不存在";
							timer=setInterval(function(){
								$("#findPathMsg")[0].style.backgroundColor=ii++%2?"red":"";
								ii>8&&clearInterval(timer);
							},100);
							return;
						}
						var strArrTmp=$("#findPathTxt")[0].value.trim().split("\n"),
							showtxt="",
							retTxt="",
							pathNumber=1;
						for(var len=0;len < strArrTmp.length;len++)
						{
							if(strArrTmp[len].length==0)
								continue;
							showtxt+="第"+pathNumber+"条语句：\n";
							pathNumber++;
							ii=0;
							clearInterval(timer);
							if(escape(strArrTmp[len]).indexOf("%u")>=0)
							{
								var str=strArrTmp[len].replace(/ /g,"").split("\\");
								retTxt=This.findPath(This,str,false);
							}
							else
							{
								var arr=strArrTmp[len].split("\\");
								var str=[];
								for(var i = 0;i<arr.length;i++)
								{
									str[i]=arr[i].split(" ");
								}
								retTxt=This.findCplxPath(This,str);
							}
							if(retTxt.length==0)
							{
								showtxt+="在网络中没有搜索到\n";
								timer=setInterval(function(){
									$("#findPathMsg")[0].style.backgroundColor=ii++%2?"red":"";
									ii>8&&clearInterval(timer);
								},100);
							}
							else
							{
								if(retTxt=="N")
								{
									showtxt="请检查网络中的开始结点以及是否有孤立结点\n开始结点只能有一个，并删除不必要的孤立结点";
									timer=setInterval(function(){
										$("#findPathMsg")[0].style.backgroundColor=ii++%2?"red":"";
										ii>8&&clearInterval(timer);
									},100);
									This.onFreshClick();
									break;
								}
								showtxt+=retTxt;
							}
							showtxt+="\n";
						}
						$("#findPathMsg")[0].value=showtxt;
					});
					break;
			}
		});

	var toolWidth=31;
	this.$bgDiv.append("<div class='GooFlow_tool'><div style='height:"+(height-headHeight-5)+"px' class='GooFlow_tool_div'></div></div>");
	this.$tool=this.$bgDiv.find(".GooFlow_tool div");	
	var titleCursor=" title='"+GooFlow.prototype.remarks.toolBtns["cursor"]+"'";
    var titleDirect=" title='"+GooFlow.prototype.remarks.toolBtns["direct"]+"'";
    tmp  = "<div style='margin-bottom:4px'><span/><span/><span/></div>";
    tmp += "<a href='javascript:void(0)' title='选择指针' type='cursor' class='GooFlow_tool_btndown' id='"+this.$id+"_btn_cursor'><i class='ico_cursor'/></a>";
    tmp += "<a href='javascript:void(0)' title='绘制连线指针' type='direct' class='GooFlow_tool_btn' id='"+this.$id+"_btn_direct'><i class='ico_direct'/></a>";
    tmp	+= "<span/>";
  	tmp += "<a href='javascript:void(0)' title='绘制结点指针' type='end round' id='demo_btn_end' class='GooFlow_tool_btn'><i class='ico_end round'/></a>";
	this.$tool.append(tmp);
	this.$nowType="cursor";
	//绑定各个按钮的点击事件
	this.$tool.on("click",{inthis:this},function(e){
		if(!e)e=window.event;
		var tar;
		$("#choseDiv").hide();
		switch(e.target.tagName){
			case "SPAN":return false;
			case "DIV":return false;
			case "I":	tar=e.target.parentNode;break;
			case "A":	tar=e.target;
		};
		var type=$(tar).attr("type");
		e.data.inthis.switchToolBtn(type);
		return false;
	});
	this.$editable=true;//只有具有工具栏时可编辑

	width=width-toolWidth;
	height=height-headHeight-5-40;
	var top_margin = 30;
	var left_margin = 35;
	this.$bgDiv.append("<div class='GooFlow_work' style='top:"+top_margin+"px;left:"+left_margin+"px' ></div>");
	this.$workArea=$("<div class='GooFlow_work_inner' style='width:"+width+"px;height:"+height+"px;'></div>")
		.attr({"unselectable":"on","onselectstart":'return false',"onselect":'document.selection.empty()'});
	this.$bgDiv.children(".GooFlow_work").append(this.$workArea);
	//计算工作区相对GooFlow父框架的绝对定位运算值，并保存
	this.t={top:top_margin,left:left_margin};
	this.$draw=null;//画矢量线条的容器
	this.initDraw("draw_"+this.$id,width,height);
	this.$group=null;
	if(property.haveGroup)
		this.initGroup(width,height);
	this.initExpendFunc();
	//为了结点而增加的一些集体delegate绑定
	this.initWorkForNode();
	//对结点进行移动或者RESIZE时用来显示的遮罩层
	this.$ghost=$("<div class='rs_ghost'></div>").attr({"unselectable":"on","onselectstart":'return false',"onselect":'document.selection.empty()'});
	this.$bgDiv.append(this.$ghost);
	this.$choseDiv=$("<div id='choseDiv' style='border-style:dashed;border-width:2px;position:absolute;display:none'><div>");
	this.$workArea.append(this.$choseDiv);
	this.$isMove=false;
	this.$X,this.$Y,this.$vX,this.$vY;
	if(this.$editable){
	  //绑定工作区事件
	var tmpMoveFlag=false;
    var tmp_X,tmp_Y;
    var tmpChosed=false;
    var Pos_X,Pos_Y,PosDiv_X,PosDiv_Y;
	
    this.$choseDiv.mousedown({inthis:this},function(e){
	    if(!e)
			e=window.event;
		var This=e.data.inthis;
		if(e.ctrlKey)
		{
			if($("#moveDiv")[0])
			{
				var _x=parseInt($("#moveDiv")[0].style.left),
					_y=parseInt($("#moveDiv")[0].style.top);
				$("#moveDiv").remove();
				for(var i in This.$moveDivNodes)
				{
					This.addNode(This.$max,{name:This.$max,left:This.$moveDivNodes[i].left+_x-PosDiv_X,top:This.$moveDivNodes[i].top+_y-PosDiv_Y,type:"end round"});
					This.$moveDivNodes[i]["newid"]=This.$max;
					This.$max++;
				}
				for(var i in This.$moveDivLines)
				{
					This.$lineData[This.$max]={};
					This.$lineData[This.$max].name=This.$moveDivLines[i].text.replace(/<|>/g,"");
					This.$lineData[This.$max].type=This.$moveDivLines[i].type;
					This.$lineData[This.$max].alt=true;
					This.$lineData[This.$max].marked=false;
					This.$lineData[This.$max].dash=false;
					for(var j in This.$moveDivNodes)
					{
						if(This.$moveDivLines[i].from==This.$moveDivNodes[j].id)
							This.$lineData[This.$max].from=This.$moveDivNodes[j].newid;
						if(This.$moveDivLines[i].to==This.$moveDivNodes[j].id)
							This.$lineData[This.$max].to=This.$moveDivNodes[j].newid;
					}
					var tmpArr=This.$moveDivLines[i].d.replace(/M/,"L").split("L ");
					var arr=[];
					for(var k =1;k<tmpArr.length;k++)
					{
						arr.push({y:parseInt(tmpArr[k].split(" ")[0]-24)+_x-PosDiv_X,x:parseInt(tmpArr[k].split(" ")[1])+_y-PosDiv_Y-64});
					}
					This.$lineDom[This.$max]=GooFlow.prototype.drawPolyLine(This.$max,arr,This.$lineData[This.$max],This.$scale,This);
					for(var j=0;j<This.$endNodes.length;j++)
					{
						if(This.$endNodes[j]==This.$lineData[This.$max].from)
						{
							This.$endNodes.splice(j,1);
							This.$nodeDom[This.$lineData[This.$max].from].css({"background-color":"#c0ccda"});
							break;
						}
					}
					This.$draw.appendChild(This.$lineDom[This.$max]);
					This.$max++;
				}
			}	
			if(!tmpMoveFlag)
			  {
				  var tmpMoveDiv=$("<div id='moveDiv' style='border-style:dashed;border-width:2px;position:absolute;display:none'><div>");
				  This.$workArea.append(tmpMoveDiv);
				  var tmpDrawDiv=document.createElementNS("http://www.w3.org/2000/svg","svg");
				  tmpMoveDiv.prepend(tmpDrawDiv);
				  $("#moveDiv").mousedown({inthis:this},function(e){
					  if(e.ctrlKey)
						  tmpMoveFlag=true;
				  });
				  var ev=mousePosition(e),
					  tmpMDiv=$("#moveDiv");
				  PosDiv_X=parseInt(this.style.left);
				  PosDiv_Y=parseInt(this.style.top);
				  tmp_X=ev.x-PosDiv_X;
				  tmp_Y=ev.y-PosDiv_Y;
				  $("#moveDiv")[0].style.width=$("#choseDiv")[0].style.width;
				  $("#moveDiv")[0].style.height=$("#choseDiv")[0].style.height;
				  for(var i in This.$moveDivNodes)
				  {
					  var tmpDiv=$("<div class='GooFlow_item item_round' style='position:absolute;top:"+(This.$moveDivNodes[i].top-PosDiv_Y)*This.$scale+"px;left:"+(This.$moveDivNodes[i].left-PosDiv_X)*This.$scale+"px'><table cellspacing='0' style='width:"+(28*This.$scale-2)+"px;height:"+(28*This.$scale-2)+"px;'></table><div class='span'>"+i+"</div></div>");//json.type
					  $("#moveDiv").append(tmpDiv);
				  }
				  for(var i in This.$moveDivLines)
				  {
					  var name=This.$moveDivLines[i].text,
						  type=This.$moveDivLines[i].type,
						  dd=This.$moveDivLines[i].d.replace(/M/,"L").split("L ");
						  arr=[];
						for(var j=1;j<dd.length;j++)
						{
							arr.push({"x":parseInt(dd[j].split(" ")[0]),"y":parseInt(dd[j].split(" ")[1])});
						}
					    for(var j=0;j<arr.length;j++)
						{
							arr[j]["x"]-=PosDiv_X;
							arr[j]["y"]-=PosDiv_Y;
						}
						var x=arr[parseInt(arr.length/2)]["x"];
						var y=arr[parseInt(arr.length/2)]["y"];
						var sp=arr.shift();
						var ep=arr.pop();
						var poly=document.createElementNS("http://www.w3.org/2000/svg","g");
						var hi=document.createElementNS("http://www.w3.org/2000/svg","path");
						var path=document.createElementNS("http://www.w3.org/2000/svg","path");
						poly.setAttribute("from",sp["x"]+","+sp["y"]);
						poly.setAttribute("to",ep["x"]+","+ep["y"]);
						if(type=="cxl" || type=="axl")
						{
							hi.setAttribute("visibility","visible");	
							if(type=="axl")
							{
								hi.setAttribute("stroke","#FF0000");
							}
							else
							{
								hi.setAttribute("stroke","#3892D3");
							}
						}
						else
						{
							hi.setAttribute("visibility","hidden");
							hi.setAttribute("stroke","white");
						}
						hi.setAttribute("style", "stroke-dasharray:6,5");
						hi.setAttribute("stroke-width",4);
						hi.setAttribute("fill","none");	
						strPath="M "+sp["x"]+" "+sp["y"];
						for(var j=0;j<arr.length;j++)
						{
							strPath+=" L "+arr[j]["x"]+" "+arr[j]["y"];
						}
						strPath+=" L "+ep["x"]+" "+ep["y"];
						hi.setAttribute("d",strPath);
						hi.setAttribute("pointer-events","stroke");
						path.setAttribute("d",strPath);
						path.setAttribute("stroke-width",1.4);
						path.setAttribute("stroke-linecap","round");
						path.setAttribute("fill","none");
						if(name=="-")	path.setAttribute("style", "stroke-dasharray:6,5");
						path.setAttribute("stroke","#3892D3");//GooFlow.prototype.color.line||"#3892D3");
						path.setAttribute("marker-end","url(#arrow1)");
						poly.appendChild(hi);
						poly.appendChild(path);
						var text=document.createElementNS("http://www.w3.org/2000/svg","text");
						text.setAttribute("fill","#333");//GooFlow.prototype.color.lineFont||"#333");
						text.textContent=name;
						poly.appendChild(text);
						text.setAttribute("text-anchor","middle");
						text.setAttribute("x",x);
						text.setAttribute("y",y);
						text.style.cursor="text";
						poly.style.cursor="pointer";
						text.style.fontSize=14*This.$scale+"px";
						tmpDrawDiv.appendChild(poly);
				  }
			  }			
			  tmpMoveFlag=true;
		  }
	  });
	    this.$workArea.on("click",{inthis:this},function(e){
		    if(!e)e=window.event;
			var This=e.data.inthis;
			if(!This.$editable)
				return;
			var type=This.$nowType;
			var X,Y;
			var ev=mousePosition(e),t=getElCoordinate(this);
			X=ev.x-t.left+this.parentNode.scrollLeft;
			Y=ev.y-t.top+this.parentNode.scrollTop;
			if(type=="cursor"){
				var t=$(e.target);
				var n=t.prop("tagName");
				var sdsd=t.prop("class");
				if(n=="svg"||(n=="DIV"&&t.prop("class").indexOf("GooFlow_work")>-1)||n=="LABEL"){
					This.blurItem();
				}
				return;
			}
			else if(type=="direct")
				return;
			tmpChosed=false;
			This.addNode(This.$max,{name:This.$max,left:X,top:Y,type:This.$nowType});
			This.addLog("添加了结点"+This.$max.toString());
			This.$max++;
	    });
	  //划线或改线时用的绑定
	   this.$workArea.mousedown({inthis:this},function(e){
		    if(!e)e=window.event;
			var This=e.data.inthis;
			if(!e.ctrlKey)
			{	
				if($("#moveDiv")[0])
				{
					var _x=parseInt($("#moveDiv")[0].style.left),
						_y=parseInt($("#moveDiv")[0].style.top);
					$("#moveDiv").remove();
					for(var i in This.$moveDivNodes)
					{
						This.addNode(This.$max,{name:This.$max,left:This.$moveDivNodes[i].left+_x-PosDiv_X,top:This.$moveDivNodes[i].top+_y-PosDiv_Y,type:"end round"});
						This.$moveDivNodes[i]["newid"]=This.$max;
						This.$max++;
					}
					for(var i in This.$moveDivLines)
					{
						This.$lineData[This.$max]={};
						This.$lineData[This.$max].name=This.$moveDivLines[i].text.replace(/<|>/g,"");
						This.$lineData[This.$max].type=This.$moveDivLines[i].type;
						This.$lineData[This.$max].alt=true;
						This.$lineData[This.$max].marked=false;
						This.$lineData[This.$max].dash=false;
						for(var j in This.$moveDivNodes)
						{
							if(This.$moveDivLines[i].from==This.$moveDivNodes[j].id)
								This.$lineData[This.$max].from=This.$moveDivNodes[j].newid;
							if(This.$moveDivLines[i].to==This.$moveDivNodes[j].id)
								This.$lineData[This.$max].to=This.$moveDivNodes[j].newid;
						}
						var tmpArr=This.$moveDivLines[i].d.replace(/M/,"L").split("L ");
						var arr=[];
						for(var k =1;k<tmpArr.length;k++)
						{
							arr.push({y:parseInt(tmpArr[k].split(" ")[0]-24)+_x-PosDiv_X,x:parseInt(tmpArr[k].split(" ")[1])+_y-PosDiv_Y-64});
						}
						This.$lineDom[This.$max]=GooFlow.prototype.drawPolyLine(This.$max,arr,This.$lineData[This.$max],This.$scale,This);
						for(var j=0;j<This.$endNodes.length;j++)
						{
							if(This.$endNodes[j]==This.$lineData[This.$max].from)
							{
								This.$endNodes.splice(j,1);
								This.$nodeDom[This.$lineData[This.$max].from].css({"background-color":"#c0ccda"});
								break;
							}
						}
						This.$draw.appendChild(This.$lineDom[This.$max]);
						This.$max++;
					}
				}
				if($("#choseDiv")[0].style.display!="none")
				{
					for(var j in This.$moveDivLines)
					{
						var i = This.$moveDivLines[j].id;
						switch(This.$lineData[i].type)
						{
							case "cxl":
							case "xl":
							case "cl":
								This.$lineDom[i].childNodes[1].setAttribute("stroke","#3892d3");
								This.$lineDom[i].childNodes[0].setAttribute("stroke","#3892d3");
								break;
							case "axl":
							case "al":
								This.$lineDom[i].childNodes[0].setAttribute("stroke","#ff0000");
								This.$lineDom[i].childNodes[1].setAttribute("stroke","#ff0000");
								break;
						}
						This.$lineDom[i].childNodes[2].setAttribute("stroke",GooFlow.prototype.color.text);
						delete This.$moveDivLines[j];
					}
					for(var j in This.$moveDivNodes)
					{
						var i = This.$moveDivNodes[j].id;
						var tmpFlag=false;
						for(var k=0;k<This.$endNodes.length;k++)
						{
							if(This.$endNodes[k]==i)
							{
								This.$nodeDom[i].css({"background-color":"#ff0000"});
								tmpFlag=true;
								break;
							}
						}
						if(!tmpFlag)
							This.$nodeDom[i].css({"background-color":GooFlow.prototype.color.node});
						delete This.$moveDivNodes[j];
					}
					$("#choseDiv").hide();
				}
				This.$moveDivLines={};
				This.$moveDivNodes={};
			}
			if(!This.$editable)
				return;
			var type=This.$nowType;
			if(type=="cursor"){
				var t=$(e.target);
				var n=t.prop("tagName");
				var sdsd=t.prop("class");
				if(n=="svg"||(n=="DIV"&&t.prop("class").indexOf("GooFlow_work")>-1)||n=="LABEL"){
					This.blurItem();
					tmpChosed=true;
					var ev=mousePosition(e),t=getElCoordinate(this);
					Pos_X=ev.x-t.left+this.parentNode.scrollLeft;
					Pos_Y=ev.y-t.top+this.parentNode.scrollTop;
				}
			}
	    });
		this.$workArea.mousemove({inthis:this},function(e){
			var ev=mousePosition(e),t=getElCoordinate(this);
			var X,Y;
			var This =e.data.inthis;
			X=ev.x-t.left+this.parentNode.scrollLeft;
			Y=ev.y-t.top+this.parentNode.scrollTop;
			if(e.ctrlKey)
			{
				  if(tmpMoveFlag)
				  {
					  $("#moveDiv")[0].style.left=ev.x-tmp_X+"px";
					  $("#moveDiv")[0].style.top=ev.y-tmp_Y+"px";
					  $("#moveDiv").show();
				  }
			}
			if(tmpChosed)
			{
				var tmpDiv=$("#choseDiv");
				var left=Math.min(X,Pos_X);
				var top=Math.min(Y,Pos_Y);
				var tmpWidth=Math.abs(X-Pos_X);
				var tmpHeight=Math.abs(Y-Pos_Y),
					tmpArea={"left":left,"top":top,"width":tmpWidth,"height":tmpHeight},
					tmpNodeFlags={};
				tmpDiv[0].style.left=left+"px";
				tmpDiv[0].style.top=top+"px";
				tmpDiv[0].style.width=tmpWidth+"px";
				tmpDiv[0].style.height=tmpHeight+"px";
				tmpDiv.show();
				for(var i in This.$nodeData)
				{
					if(This.NodeInArea(This.$nodeData[i],tmpArea))
					{
						tmpNodeFlags[i.toString()]=1;
						This.$nodeDom[i].css({"background-color":"#0000ff"});
						This.$moveDivNodes[i+'\'']={"left":This.$nodeData[i].left,"top":This.$nodeData[i].top,"id":i};
					}
					else
					{
						tmpNodeFlags[i.toString()]=0;
						var tmpFlag=false;
						for(var j=0;j<This.$endNodes.length;j++)
						{
							if(This.$endNodes[j]==i)
							{
								This.$nodeDom[i].css({"background-color":"#ff0000"});
								tmpFlag=true;
								break;
							}
						}
						if(!tmpFlag)
							This.$nodeDom[i].css({"background-color":GooFlow.prototype.color.node});
						delete This.$moveDivNodes[i+'\''];
					}
				}
				for(var i in This.$lineData)
				{
					if(tmpNodeFlags[This.$lineData[i].from]==1 && tmpNodeFlags[This.$lineData[i].to]==1)
					{
						This.$lineDom[i].childNodes[0].setAttribute("stroke","#0000ff");
						This.$lineDom[i].childNodes[1].setAttribute("stroke","#0000ff");
						This.$lineDom[i].childNodes[2].setAttribute("stroke","#0000ff");
						var asds=This.$lineDom[i].childNodes[1]["attributes"]["d"].nodeValue;
						This.$moveDivLines[i+'\'']={"d":asds,"text":This.$lineDom[i].textContent,"from":This.$lineData[i].from,"to":This.$lineData[i].to,"type":This.$lineData[i].type,"id":i};
					}else
					{
						switch(This.$lineData[i].type)
						{
							case "cxl":
							case "xl":
							case "cl":
								This.$lineDom[i].childNodes[1].setAttribute("stroke","#3892d3");
								This.$lineDom[i].childNodes[0].setAttribute("stroke","#3892d3");
								break;
							case "axl":
							case "al":
								This.$lineDom[i].childNodes[0].setAttribute("stroke","#ff0000");
								This.$lineDom[i].childNodes[1].setAttribute("stroke","#ff0000");
								break;
						}
						This.$lineDom[i].childNodes[2].setAttribute("stroke",GooFlow.prototype.color.text);
						delete This.$moveDivLines[i+'\''];
					}
				}
			}
			if((e.data.inthis.$nowType!="direct"&&e.data.inthis.$nowType!="dashed")&&!e.data.inthis.$mpTo.data("p"))
				return;
			var lineStart=$(this).data("lineStart");
			var lineEnd=$(this).data("lineEnd");
			if(!lineStart&&!lineEnd)return;
			var line=document.getElementById("GooFlow_tmp_line");
			if(lineStart){
					if(GooFlow.prototype.useSVG!=""){
					line.childNodes[0].setAttribute("d","M "+lineStart.x+" "+lineStart.y+" L "+X+" "+Y);
					line.childNodes[1].setAttribute("d","M "+lineStart.x+" "+lineStart.y+" L "+X+" "+Y);
					if(line.childNodes[1].getAttribute("marker-end")=="url(\"#arrow2\")")
						line.childNodes[1].setAttribute("marker-end","url(#arrow3)");
					else	line.childNodes[1].setAttribute("marker-end","url(#arrow2)");
					}
					else	line.points.value=lineStart.x+","+lineStart.y+" "+X+","+Y;
				}else if(lineEnd){
				if(GooFlow.prototype.useSVG!=""){
					line.childNodes[0].setAttribute("d","M "+X+" "+Y+" L "+lineEnd.x+" "+lineEnd.y);
					line.childNodes[1].setAttribute("d","M "+X+" "+Y+" L "+lineEnd.x+" "+lineEnd.y);
					if(line.childNodes[1].getAttribute("marker-end")=="url(\"#arrow2\")")
						line.childNodes[1].setAttribute("marker-end","url(#arrow3)");
					else	line.childNodes[1].setAttribute("marker-end","url(#arrow2)");
				}
				else	line.points.value=X+","+Y+" "+lineEnd.x+","+lineEnd.y;
				}
		});
		this.$workArea.mouseup({inthis:this},function(e){
			tmpMoveFlag=false;
			tmpChosed=false;
			var This=e.data.inthis;
			if((This.$nowType!="direct"&&This.$nowType!="dashed")&&!This.$mpTo.data("p"))	return;
			var tmp=document.getElementById("GooFlow_tmp_line");
			if(tmp){
				$(this).css("cursor","auto").removeData("lineStart").removeData("lineEnd");
				This.$mpTo.hide().removeData("p");
				This.$mpFrom.hide().removeData("p");
				This.$draw.removeChild(tmp);
				This.focusItem(This.$focus,false);
			}
	  });

	  this.$textArea=$("<textarea maxlength='18'></textarea>");
	  this.$bgDiv.append(this.$textArea);
	  this.$textArea.keydown({inthis:this},function(e)
	  {
		  if(e.keyCode==13)
		  {
			  var This=e.data.inthis;
			  var tmpFocus=$("#"+This.$focus);
			  var tmpType="";
			  if(tmpFocus[0].nodeName=="g")
				  tmpType="line";
			  if(tmpFocus[0].nodeName=="div")
				  tmpType="node";
			  //This.setName(This.$textArea.data("id"),This.$textArea.val(),tmpType);
			  This.setName(This.$focus,this.value,tmpType);
			  This.$textArea.val("").removeData("id").hide();
		  }
	  });
	  this.$lineMove=$('<div class="GooFlow_linemove" style="display:none"></div>');//操作折线时的移动框
	  this.$workArea.append(this.$lineMove);
	  this.$lineMove.on("mousedown",{inthis:this},function(e){
		  if(e.button==2)return false;
		  var lm=$(this);
		  lm.css({"background-color":"#333"});
		  var This=e.data.inthis;
		  var ev=mousePosition(e),t=getElCoordinate(This.$workArea[0]);
		  var X,Y;
		  X=ev.x-t.left+This.$workArea[0].parentNode.scrollLeft;
		  Y=ev.y-t.top+This.$workArea[0].parentNode.scrollTop;
		  var p=This.$lineMove.position();
		  var vX=X-p.left,vY=Y-p.top;
		  var isMove=false;
		  document.onmousemove=function(e){
			if(!e)e=window.event;
			var ev=mousePosition(e);
			var ps=This.$lineMove.position();
			X=ev.x-t.left+This.$workArea[0].parentNode.scrollLeft;
		 	Y=ev.y-t.top+This.$workArea[0].parentNode.scrollTop;
			if(This.$lineMove.data("type")=="lr"){
			  X=X-vX;
			  if(X<0)	X=0;
			  else if(X>This.$workArea.width())
				X=This.$workArea.width();
			  This.$lineMove.css({left:X+"px"});
			}
			else if(This.$lineMove.data("type")=="tb"){
			  Y=Y-vY;
			  if(Y<0)	Y=0;
			  else if(Y>This.$workArea.height())
				Y=This.$workArea.height();
			  This.$lineMove.css({top:Y+"px"});
		    }
			isMove=true;
		  }
		  document.onmouseup=function(e){
			if(isMove){
				var p=This.$lineMove.position();
			}
			This.$lineMove.css({"background-color":"transparent"});
			if(This.$focus==This.$lineMove.data("tid")){
				This.focusItem(This.$lineMove.data("tid"));
			}
			document.onmousemove=null;
			document.onmouseup=null;
		  }
	  });

	  //新增移动线两个端点至新的结点功能移动功能，这里要提供移动用的DOM
	  this.$mpFrom=$("<div class='GooFlow_line_mp' style='display:none'></div>");
	  this.$mpTo=$("<div class='GooFlow_line_mp' style='display:none'></div>");
	  this.$workArea.append(this.$mpFrom).append(this.$mpTo);
	  this.initLinePointsChg();

	  //下面绑定当结点/线/分组块的一些操作事件,这些事件可直接通过this访问对象本身
	  //当操作某个单元（结点/线/分组块）被添加时，触发的方法，返回FALSE可阻止添加事件的发生
	  //格式function(id，type,json)：id是单元的唯一标识ID,type是单元的种类,有"node","line","area"三种取值,json即addNode,addLine或addArea方法的第二个传参json.
	  this.onItemAdd=null;
	  //当操作某个单元（结点/线/分组块）被删除时，触发的方法，返回FALSE可阻止删除事件的发生
	  //格式function(id，type)：id是单元的唯一标识ID,type是单元的种类,有"node","line","area"三种取值
	  this.onItemDel=null;
	  //当操作某个单元（结点/分组块）被移动时，触发的方法，返回FALSE可阻止移动事件的发生
	  //格式function(id，type,left,top)：id是单元的唯一标识ID,type是单元的种类,有"node","area"两种取值，线line不支持移动,left是新的左边距坐标，top是新的顶边距坐标
	  this.onItemMove=null;
	  //当操作某个单元（结点/线/分组块）被重命名时，触发的方法，返回FALSE可阻止重命名事件的发生
	  //格式function(id,name,type)：id是单元的唯一标识ID,type是单元的种类,有"node","line","area"三种取值,name是新的名称
	  this.onItemRename=null;
	  //当操作某个单元（结点/线）被由不选中变成选中时，触发的方法，返回FALSE可阻止选中事件的发生
	  //格式function(id,type)：id是单元的唯一标识ID,type是单元的种类,有"node","line"两种取值,"area"不支持被选中
	  this.onItemFocus=null;
	  //当操作某个单元（结点/线）被由选中变成不选中时，触发的方法，返回FALSE可阻止取消选中事件的发生
	  //格式function(id，type)：id是单元的唯一标识ID,type是单元的种类,有"node","line"两种取值,"area"不支持被取消选中
	  this.onItemBlur=null;
	  //当操作某个单元（结点/分组块）被重定义大小或造型时，触发的方法，返回FALSE可阻止重定大小/造型事件的发生
	  //格式function(id，type,width,height)：id是单元的唯一标识ID,type是单元的种类,有"node","line","area"三种取值;width是新的宽度,height是新的高度
	  this.onItemResize=null;
	  //当移动某条折线中段的位置，触发的方法，返回FALSE可阻止重定大小/造型事件的发生
	  //格式function(id，M)：id是单元的唯一标识ID,M是中段的新X(或Y)的坐标
	  this.onLineMove=null;
	  //当变换某条连接线的类型，触发的方法，返回FALSE可阻止重定大小/造型事件的发生
	  //格式function(id，type)：id是单元的唯一标识ID,type是连接线的新类型,"sl":直线,"lr":中段可左右移动的折线,"tb":中段可上下移动的折线
	  this.onLineSetType=null;
	  //当变换某条连接线的端点变更连接的结点时，触发的方法，返回FALSE可阻止重定大小/造型事件的发生
	  //格式function(id，newStart,newEnd)：id是连线单元的唯一标识ID,newStart,newEnd分别是起始结点的ID和到达结点的ID
	  this.onLinePointMove=null;
	  //当用重色标注某个结点/转换线时触发的方法，返回FALSE可阻止重定大小/造型事件的发生
	  //格式function(id，type，mark)：id是单元的唯一标识ID,type是单元类型（"node"结点,"line"转换线），mark为布尔值,表示是要标注TRUE还是取消标注FALSE
	  this.onItemMark=null;
      //当操作某个单元（结点/线）被由不选中变成选中时，触发的方法，返回FALSE可阻止选中事件的发生
      //格式function(id,type)：id是单元的唯一标识ID,type是单元的种类,有"node","line"两种取值,"area"不支持被选中
      this.onItemDbClick=null;
      //当操作某个单元（结点/线/区域块）被双击时，触发的方法，返回FALSE可阻止取消原来双击事件（双击后直接编辑）的发生
      //格式function(id，type)：id是单元的唯一标识ID,type是单元的种类,有"node","line","area"三种取值
      this.onItemRightClick=null;
      //当操作某个单元（结点/线/区域块）被右键点击时，触发的方法，返回FALSE可阻止取消原来右击事件（一般是浏览器默认的右键菜单）的发生
      //格式function(id，type)：id是单元的唯一标识ID,type是单元的种类,有"node","line","area"三种取值


	  if(property.useOperStack&&this.$editable){//如果要使用堆栈记录操作并提供“撤销/重做”的功能,只在编辑状态下有效
		this.$undoStack=[];
		this.$redoStack=[];
		this.$isUndo=0;
		///////////////以下是构造撤销操作/重做操作的方法
		//为了节省浏览器内存空间,undo/redo中的操作缓存栈,最多只可放40步操作;超过40步时,将自动删掉最旧的一个缓存
		this.pushOper=function(funcName,paras){
			var len=this.$undoStack.length;
			if(this.$isUndo==1){
				this.$redoStack.push([funcName,paras]);
				this.$isUndo=false;
				if(this.$redoStack.length>40)	this.$redoStack.shift();
			}else{
				this.$undoStack.push([funcName,paras]);
				if(this.$undoStack.length>40)	this.$undoStack.shift();
				if(this.$isUndo==0){
					this.$redoStack.splice(0,this.$redoStack.length);
				}
				this.$isUndo=0;
			}
		};
		//将外部的方法加入到GooFlow对象的事务操作堆栈中,在过后的undo/redo操作中可以进行控制，一般用于对流程图以外的附加信息进行编辑的事务撤销/重做控制；
		//传参func为要执行方法对象,jsonPara为外部方法仅有的一个面向字面的JSON传参,由JSON对象带入所有要传的信息；
		//提示:为了让外部方法能够被UNDO/REDO,需要在编写这些外部方法实现时,加入对该方法执行后效果回退的另一个执行方法的pushExternalOper
		this.pushExternalOper=function(func,jsonPara){
			this.pushOper("externalFunc",[func,jsonPara]);
		};
		//撤销上一步操作
		this.undo=function(){
			if(this.$undoStack.length==0)	return;
			this.blurItem();
			var tmp=this.$undoStack.pop();
			this.$isUndo=1;
			if(tmp[0]=="externalFunc"){
				tmp[1][0](tmp[1][1]);
			}
			else{
			//传参的数量,最多支持6个.
			switch(tmp[1].length){
				case 0:this[tmp[0]]();break;
				case 1:this[tmp[0]](tmp[1][0]);break;
				case 2:this[tmp[0]](tmp[1][0],tmp[1][1]);break;
				case 3:this[tmp[0]](tmp[1][0],tmp[1][1],tmp[1][2]);break;
				case 4:this[tmp[0]](tmp[1][0],tmp[1][1],tmp[1][2],tmp[1][3]);break;
				case 5:this[tmp[0]](tmp[1][0],tmp[1][1],tmp[1][2],tmp[1][3],tmp[1][4]);break;
				case 6:this[tmp[0]](tmp[1][0],tmp[1][1],tmp[1][2],tmp[1][3],tmp[1][4],tmp[1][5]);break;
			}
			}
		};
		//重做最近一次被撤销的操作
		this.redo=function(){
			if(this.$redoStack.length==0)	return;
			this.blurItem();
			var tmp=this.$redoStack.pop();
			this.$isUndo=2;
			if(tmp[0]=="externalFunc"){
				tmp[1][0](tmp[1][1]);
			}
			else{
			//传参的数量,最多支持6个.
			switch(tmp[1].length){
				case 0:this[tmp[0]]();break;
				case 1:this[tmp[0]](tmp[1][0]);break;
				case 2:this[tmp[0]](tmp[1][0],tmp[1][1]);break;
				case 3:this[tmp[0]](tmp[1][0],tmp[1][1],tmp[1][2]);break;
				case 4:this[tmp[0]](tmp[1][0],tmp[1][1],tmp[1][2],tmp[1][3]);break;
				case 5:this[tmp[0]](tmp[1][0],tmp[1][1],tmp[1][2],tmp[1][3],tmp[1][4]);break;
				case 6:this[tmp[0]](tmp[1][0],tmp[1][1],tmp[1][2],tmp[1][3],tmp[1][4],tmp[1][5]);break;
			}
			}
		};
	  }
	  $(document).keydown({inthis:this},function(e){
		//绑定键盘快捷键操作
		var This=e.data.inthis;
		if(This.$focus=="")//结点和弧没有被选定
		{
			if($("#choseDiv")[0].style.display!="none")
			{
				//if(e.ctrlKey && e.keyCode==67)//ctrl+C
				//else if(e.ctrlKey && e.keyCode==88)//ctrl+X
				if(e.keyCode==46 && !$("#moveDiv")[0])//delete
				{
					$("#choseDiv").hide();
					for(var i in This.$moveDivNodes)
					{
						This.delNode(This.$moveDivNodes[i].id);
					}
					This.$moveDivNodes={};
					This.$moveDivLines={};
				}
			}
			if(e.ctrlKey && e.keyCode==90)//ctrl+Z
			{
				e.preventDefault();
				This.undo();
			}
			else if(e.ctrlKey && e.keyCode==83)//ctrl+S
			{
				e.preventDefault();
				if(This.onBtnSaveClick!=null)	
				{				
					This.onBtnSaveClick();
				}
			}
			else if(e.ctrlKey && e.keyCode==82)//ctrl+R
			{
				e.preventDefault();
				if(This.onFreshClick!=null)
				{
					try{					
						This.onFreshClick();
						This.addLog("网络重构成功");
					}catch(ee)
					{
						This.addLog("网络重构失败",true);
					}
				}
			}
			else if(e.ctrlKey && e.keyCode==37)//ctrl+<-
			{
				if(This.$RightGo<=0)
				{
					This.addLog("已经是默认最小水平宽度",true);
					return;
				}
				This.$RightGo--;
				var w = This.$workArea.width()-This.$workExtendStep;
				var h = This.$workArea.height();
				This.$workArea.css({width:w+"px"});
				if(GooFlow.prototype.useSVG==""){
					This.$draw.coordsize = w+","+h;
				}
				This.$draw.style.width = w + "px";
				if(This.$group!=null){
					This.$group.css({width:w+"px"});
				}
				var parentDiv = This.$workArea.parent()[0];
				parentDiv.scrollLeft = parentDiv.scrollWidth;
				This.$workArea.parent().css("overflow","scroll");
				This.addLog("工作区向左缩小了"+This.$workExtendStep.toString()+"px");
			}
			else if(e.ctrlKey && e.keyCode==38)//ctrl+up
			{
				if(This.$DownGo<=0)
				{
					This.addLog("已经是默认最小垂直高度",true);
					return;
				}
				This.$DownGo--;
				var w = This.$workArea.width();
				var h = This.$workArea.height()-This.$workExtendStep;
				This.$workArea.css({height:h+"px"});
				if(GooFlow.prototype.useSVG==""){
					This.$draw.coordsize = w+","+h;
				}
				This.$draw.style.height = h + "px";
				if(This.$group!=null){
					This.$group.css({height:h+"px"});
				}
				var parentDiv = This.$workArea.parent()[0];
				parentDiv.scrollTop = parentDiv.scrollHeight;
				This.$workArea.parent().css("overflow","scroll");
				This.addLog("工作区向上缩小了"+This.$workExtendStep.toString()+"px");
			}
			else if(e.ctrlKey && e.keyCode==39)//ctrl+->
			{
				This.$RightGo++;
				var w = This.$workArea.width()+This.$workExtendStep;
				var h = This.$workArea.height();
				This.$workArea.css({width:w+"px"});
				if(GooFlow.prototype.useSVG==""){
					This.$draw.coordsize = w+","+h;
				}
				This.$draw.style.width = w + "px";
				if(This.$group!=null){
					This.$group.css({width:w+"px"});
				}
				var parentDiv = This.$workArea.parent()[0];
				parentDiv.scrollLeft = parentDiv.scrollWidth;
				This.$workArea.parent().css("overflow","scroll");
				This.addLog("工作区向右扩展了"+This.$workExtendStep.toString()+"px");
			}
			else if(e.ctrlKey && e.keyCode==40)//ctrl+down
			{
				This.$DownGo++;
				var w = This.$workArea.width();
				var h = This.$workArea.height()+This.$workExtendStep;
				This.$workArea.css({height:h+"px"});
				if(GooFlow.prototype.useSVG==""){
					This.$draw.coordsize = w+","+h;
				}
				This.$draw.style.height = h + "px";
				if(This.$group!=null){
					This.$group.css({height:h+"px"});
				}
				var parentDiv = This.$workArea.parent()[0];
				parentDiv.scrollTop = parentDiv.scrollHeight;
				This.$workArea.parent().css("overflow","scroll");
				This.addLog("工作区向下扩展了"+This.$workExtendStep.toString()+"px");
			}
			else if(e.ctrlKey && e.keyCode==72)//ctrl+H
			{
				e.preventDefault();
				This.showSlotMsg();
			}
		}else
		{
			switch(e.keyCode){
				case 46://删除
				if(This.$nodeData[This.$focus])
					This.addLog("删除结点"+This.$nodeData[This.$focus].name+"以及连接的弧");
				else if(This.$lineData[This.$focus])
				{
					This.addLog("删除了结点"+This.$nodeData[This.$lineData[This.$focus].from].name+"和结点"+This.$nodeData[This.$lineData[This.$focus].to].name+"之间的弧");
					This.clearDivSlotArc("");
				}
				This.delNode(This.$focus,true);
				This.delLine(This.$focus);
				break;
			}
		}
	  });
	}
}

GooFlow.prototype={
	useSVG:"",
	getSvgMarker:function(id,color){
		var m=document.createElementNS("http://www.w3.org/2000/svg","marker");
		m.setAttribute("id",id);
		m.setAttribute("viewBox","0 0 6 6");
		m.setAttribute("refX",5);
		m.setAttribute("refY",3);
		m.setAttribute("markerUnits","strokeWidth");
		m.setAttribute("markerWidth",6);
		m.setAttribute("markerHeight",6);
		m.setAttribute("orient","auto");
		var path=document.createElementNS("http://www.w3.org/2000/svg","path");
		path.setAttribute("d","M 0 0 L 6 3 L 0 6 z");
		path.setAttribute("fill",color);
		path.setAttribute("stroke-width",0);
		m.appendChild(path);
		return m;
	},
	initDraw:function(id,width,height){
		var elem;		
		this.$draw=document.createElementNS("http://www.w3.org/2000/svg","svg");//可创建带有指定命名空间的元素节点
		this.$workArea.prepend(this.$draw);
		var defs=document.createElementNS("http://www.w3.org/2000/svg","defs");
		this.$draw.appendChild(defs);
		defs.appendChild(GooFlow.prototype.getSvgMarker("arrow1",GooFlow.prototype.color.line||"#3892D3"));
		defs.appendChild(GooFlow.prototype.getSvgMarker("arrow2",GooFlow.prototype.color.mark||"#ff8800"));
		defs.appendChild(GooFlow.prototype.getSvgMarker("arrow3",GooFlow.prototype.color.mark||"#ff8800"));
	
		this.$draw.id = id;
		this.$draw.style.width = width + "px";
		this.$draw.style.height = height + "px";
		//绑定连线的点击选中以及双击编辑事件
		var line_svg_element="g";		
		$(this.$draw).delegate(line_svg_element,"click",{inthis:this},function(e){
			e.data.inthis.focusItem(this.id,true);
		});
        //绑定右键事件
   $(this.$draw).delegate(line_svg_element,"contextmenu",{inthis:this},function(e){
      if(e.data.inthis.onItemRightClick!=null && !e.data.inthis.onItemRightClick(this.id,"line")){
          window.event? window.event.returnValue=false : e.preventDefault();
          return false;
        }
   });
		$(this.$draw).delegate(line_svg_element,"dblclick",{inthis:this},function(e){
            if(e.data.inthis.onItemDbClick!=null&&!e.data.inthis.onItemDbClick(this.id,"line"))return;
			var oldTxt,x,y,from,to;
			var This=e.data.inthis;
			oldTxt=this.childNodes[2].textContent;
			if(oldTxt.indexOf("<")>-1)
				oldTxt=oldTxt.slice(1,oldTxt.length-1);
			if(oldTxt.indexOf("-")>-1)
				oldTxt="";
			x=parseInt(this.childNodes[2].attributes["x"].value)-70;
			y=parseInt(this.childNodes[2].attributes["y"].value)-13;
			var t=This.t;
			This.$textArea.val(oldTxt).css({display:"block",width:130,height:26,
				left:t.left+x-This.$workArea[0].parentNode.scrollLeft,
				top:t.top+y-This.$workArea[0].parentNode.scrollTop}).data("id",This.$focus).focus();
			This.showSlotMsg();
			This.$workArea.parent().one("mousedown",function(e){
				if(e.button==2)return false;
				This.setName(This.$textArea.data("id"),This.$textArea.val(),"line");
				This.$textArea.val("").removeData("id").hide();
			});
		});
	},
	initGroup:function(width,height){
		this.$group=$("<div class='GooFlow_work_group' style='width:"+width+"px;height:"+height+"px'></div>");//存放背景区域的容器
		this.$workArea.prepend(this.$group);
		if(!this.$editable)	return;

        //绑定右键事件
        this.$group.delegate("GooFlow_area","contextmenu",{inthis:this},function(e){
            if(e.data.inthis.onItemRightClick!=null && !e.data.inthis.onItemRightClick(this.id,"area")){
                window.event? window.event.returnValue=false : e.preventDefault();
                return false;
            }
        });
	  //区域划分框操作区的事件绑定
	  this.$group.on("mousedown",{inthis:this},function(e){//绑定RESIZE功能以及移动功能
		if(e.button==2)return false;
		var This=e.data.inthis;
		if(This.$nowType!="group")	return;
		if(!e)e=window.event;
		var cursor=$(e.target).css("cursor");
		var id=e.target.parentNode;
		switch(cursor){
			case "nw-resize":id=id.parentNode;break;
			case "w-resize":id=id.parentNode;break;
			case "n-resize":id=id.parentNode;break;
			case "move":break;
			default:return;
		}
		id=id.id;

		var ev=mousePosition(e),t=This.t;//t=getElCoordinate(This.$workArea[0]);

		var X,Y;
		X=ev.x-t.left+This.$workArea[0].parentNode.scrollLeft;
		Y=ev.y-t.top+This.$workArea[0].parentNode.scrollTop;
		if(cursor!="move"){
			This.$ghost.css({display:"block",
				width:This.$areaData[id].width*This.$scale+"px", height:This.$areaData[id].height*This.$scale+"px",
				top:This.$areaData[id].top*This.$scale+t.top-This.$workArea[0].parentNode.scrollTop+"px",
				left:This.$areaData[id].left*This.$scale+t.left-This.$workArea[0].parentNode.scrollLeft+"px",
			cursor:cursor});
			var vX=(This.$areaData[id].left*This.$scale+This.$areaData[id].width*This.$scale)-X;
			var vY=(This.$areaData[id].top*This.$scale+This.$areaData[id].height*This.$scale)-Y;
		}
		else{
			var vX=X-This.$areaData[id].left*This.$scale;
			var vY=Y-This.$areaData[id].top*This.$scale;
		}
		var isMove=false;
		This.$ghost.css("cursor",cursor);
		document.onmousemove=function(e){
			if(!e)e=window.event;
			var ev=mousePosition(e);
			if(cursor!="move"){
			X=ev.x-t.left+This.$workArea[0].parentNode.scrollLeft-This.$areaData[id].left*This.$scale+vX;
			Y=ev.y-t.top+This.$workArea[0].parentNode.scrollTop-This.$areaData[id].top*This.$scale+vY;
			if(X<200*This.$scale)	X=200*This.$scale;
			if(Y<100*This.$scale)	Y=100*This.$scale;
			switch(cursor){
				case "nw-resize":This.$ghost.css({width:X+"px",height:Y+"px"});break;
				case "w-resize":This.$ghost.css({width:X+"px"});break;
				case "n-resize":This.$ghost.css({height:Y+"px"});break;
			}
			}
			else{
				if(This.$ghost.css("display")=="none"){
					This.$ghost.css({display:"block",
						width:This.$areaData[id].width*This.$scale+"px", height:This.$areaData[id].height*This.$scale+"px",
						top:This.$areaData[id].top*This.$scale+t.top-This.$workArea[0].parentNode.scrollTop+"px",
						left:This.$areaData[id].left*This.$scale+t.left-This.$workArea[0].parentNode.scrollLeft+"px",cursor:cursor});
				}
				X=ev.x-vX;Y=ev.y-vY;
				if(X<t.left-This.$workArea[0].parentNode.scrollLeft)
					X=t.left-This.$workArea[0].parentNode.scrollLeft;
				else if(X+This.$workArea[0].parentNode.scrollLeft+This.$areaData[id].width*This.$scale>t.left+This.$workArea.width())
					X=t.left+This.$workArea.width()-This.$workArea[0].parentNode.scrollLeft-This.$areaData[id].width*This.$scale;
				if(Y<t.top-This.$workArea[0].parentNode.scrollTop)
					Y=t.top-This.$workArea[0].parentNode.scrollTop;
				else if(Y+This.$workArea[0].parentNode.scrollTop+This.$areaData[id].height*This.$scale>t.top+This.$workArea.height())
					Y=t.top+This.$workArea.height()-This.$workArea[0].parentNode.scrollTop-This.$areaData[id].height*This.$scale;
				This.$ghost.css({left:X+"px",top:Y+"px"});
			}
			isMove=true;
		}
		document.onmouseup=function(e){
			This.$ghost.empty().hide();
			document.onmousemove=null;
			document.onmouseup=null;
			if(!isMove)return;
			if(cursor!="move")
				This.resizeArea(id,This.$ghost.outerWidth()/This.$scale,This.$ghost.outerHeight()/This.$scale);
			else
				This.moveArea(id,(X+This.$workArea[0].parentNode.scrollLeft-t.left)/This.$scale, (Y+This.$workArea[0].parentNode.scrollTop-t.top)/This.$scale);
			return false;
	  	}
	  });
	  //绑定修改文字说明功能
	  this.$group.on("dblclick",{inthis:this},function(e){
		var This=e.data.inthis;
		if(This.$nowType!="group")	return;
		if(!e)e=window.event;
		if(e.target.tagName!="LABEL")	return false;
        var p=e.target.parentNode;
        if(e.data.inthis.onItemDbClick!=null&&!e.data.inthis.onItemDbClick(p.id,"area"))return;

		var oldTxt=e.target.innerHTML;
		var x=parseInt(p.style.left,10)+18,y=parseInt(p.style.top,10)+1;
		var t=This.t;//t=getElCoordinate(This.$workArea[0]);
		This.$textArea.val(oldTxt).css({display:"block",width:130,height:26,
			left:t.left+x-This.$workArea[0].parentNode.scrollLeft,
			top:t.top+y-This.$workArea[0].parentNode.scrollTop}).data("id",p.id).focus();
		This.$workArea.parent().one("mouseup",function(e){
			if(e.button==2)return false;
			if(This.$textArea.css("display")=="block"){
				This.setName(This.$textArea.data("id"),This.$textArea.val(),"area");
				This.$textArea.val("").removeData("id").hide();
			}
			return false;
		});
		return false;
	  });
	  //绑定点击事件
	  this.$group.mouseup({inthis:this},function(e){
		var This=e.data.inthis;
		if(This.$textArea.css("display")=="block"){
			This.setName(This.$textArea.data("id"),This.$textArea.val(),"area");
			This.$textArea.val("").removeData("id").hide();
			return false;
		};
		
		if(This.$nowType!="group")	return;
		if(!e)e=window.event;
		switch($(e.target).attr("class")){
			case "rs_close":	This.delArea(e.target.parentNode.parentNode.id);return false;//删除该分组区域
			case "bg":	return;
		}
		switch(e.target.tagName){
			case "LABEL":	return false;
			case "I"://绑定变色功能
			var id=e.target.parentNode.id;
			switch(This.$areaData[id].color){
				case "red":	This.setAreaColor(id,"yellow");break;
				case "yellow":	This.setAreaColor(id,"blue");break;
				case "blue":	This.setAreaColor(id,"green");break;
				case "green":	This.setAreaColor(id,"red");break;
			}
			return false;
		}
		if(e.data.inthis.$ghost.css("display")=="none"){
      var X,Y;
      var ev=mousePosition(e),t=getElCoordinate(this);
      X=ev.x-t.left+this.parentNode.parentNode.scrollLeft;
      Y=ev.y-t.top+this.parentNode.parentNode.scrollTop;
      var color=["red","yellow","blue","green"];
      e.data.inthis.addArea(new Date().getTime(),
		{name:"area_"+e.data.inthis.$max,left:X/This.$scale,top:Y/This.$scale,color:color[e.data.inthis.$max%4],width:200,height:100}
	  );
      e.data.inthis.$max++;
      return false;
		}
	  });
	},
	//加入手动扩展编辑区功能，一次扩展200px
	initExpendFunc:function(){
		var titleExendRight=GooFlow.prototype.remarks.extendRight? ' title="'+GooFlow.prototype.remarks.extendRight+'"':'';
        var titleExendBottom=GooFlow.prototype.remarks.extendBottom? ' title="'+GooFlow.prototype.remarks.extendBottom+'"':'';
		this.$workArea.append('<div class="Gooflow_extend_right"'+titleExendRight+' style="display:none"></div><div class="Gooflow_extend_bottom"'+titleExendBottom+' style="display:none"></div>');
	    this.$workArea.children(".Gooflow_extend_right").on("click",{inthis:this},function(e){
			var This=e.data.inthis;
			var w = This.$workArea.width()+This.$workExtendStep;
			var h = This.$workArea.height();
			This.$workArea.css({width:w+"px"});
			if(GooFlow.prototype.useSVG==""){
				This.$draw.coordsize = w+","+h;
			}
			This.$draw.style.width = w + "px";
			if(This.$group!=null){
				This.$group.css({width:w+"px"});
			}
			var parentDiv = This.$workArea.parent()[0];
			parentDiv.scrollLeft = parentDiv.scrollWidth;
            This.$workArea.parent().css("overflow","scroll");
			This.addLog("工作区向右扩展了"+This.$workExtendStep.toString()+"px");
			return false;
	    });
	    this.$workArea.children(".Gooflow_extend_bottom").on("click",{inthis:this},function(e){
			var This=e.data.inthis
			var w = This.$workArea.width();
			var h = This.$workArea.height()+This.$workExtendStep;
			This.$workArea.css({height:h+"px"});
			if(GooFlow.prototype.useSVG==""){
				This.$draw.coordsize = w+","+h;
			}
			This.$draw.style.height = h + "px";
			if(This.$group!=null){
				This.$group.css({height:h+"px"});
			}
			var parentDiv = This.$workArea.parent()[0];
			parentDiv.scrollTop = parentDiv.scrollHeight;
            This.$workArea.parent().css("overflow","scroll");
			This.addLog("工作区向下扩展了"+This.$workExtendStep.toString()+"px");
			return false;
	    });
	},
	//初始化用来改变连线的连接端点的两个小方块的操作事件
	initLinePointsChg:function(){
		this.$mpFrom.on("mousedown",{inthis:this},function(e){
			var This=e.data.inthis;
			This.switchToolBtn("cursor");
			var ps=This.$mpFrom.data("p").split(",");
			var pe=This.$mpTo.data("p").split(",");
			$(this).hide();
			var line=GooFlow.prototype.drawLine("GooFlow_tmp_line",[ps[0],ps[1]],[pe[0],pe[1]],true,true,1,"",This);
			This.$draw.appendChild(line);
			return false;
	    });
		this.$mpTo.on("mousedown",{inthis:this},function(e){
			var This=e.data.inthis;
			This.switchToolBtn("cursor");
			var ps=This.$mpFrom.data("p").split(",");
			var pe=This.$mpTo.data("p").split(",");
			$(this).hide();
			var line=GooFlow.prototype.drawLine("GooFlow_tmp_line",[ps[0],ps[1]],[pe[0],pe[1]],true,true,1,"",This);
			This.$draw.appendChild(line);
			return false;
	    });
	},
	//每一种类型结点及其按钮的说明文字
	setNodeRemarks:function(remark){
        if(this.$tool==null)  return;
		this.$tool.children("a").each(function(){
			this.title=remark[$(this).attr("id").split("btn_")[1]];
		});
		//this.$nodeRemark=remark;
	},

	//切换左边工具栏按钮,传参TYPE表示切换成哪种类型的按钮
	switchToolBtn:function(type){
		if(this.$tool!=null){
			this.$tool.children("#"+this.$id+"_btn_"+this.$nowType.split(" ")[0]).attr("class","GooFlow_tool_btn");
		}
		if(this.$nowType=="group"){
			this.$workArea.prepend(this.$group);
			for(var key in this.$areaDom)	this.$areaDom[key].addClass("lock").children("div:eq(1)").css("display","none");
		}
		this.$nowType=type;
		if(this.$tool!=null){
			this.$tool.children("#"+this.$id+"_btn_"+type.split(" ")[0]).attr("class","GooFlow_tool_btndown");
		}
		if(this.$nowType=="group"){
			this.blurItem();
			this.$workArea.append(this.$group);
			for(var key in this.$areaDom)	this.$areaDom[key].removeClass("lock").children("div:eq(1)").css("display","");
		}else if(this.$nowType=="direct"||this.$nowType=="dashed"){
            this.blurItem();
		}
		if(this.$textArea&&this.$textArea.css("display")=="none")	this.$textArea.removeData("id").val("").hide();
	},
	//增加一个流程结点,传参为一个JSON,有id,name,top,left,width,height,type(结点类型)等属性
	addNode:function(id,json){
		if(this.onItemAdd!=null&&!this.onItemAdd(id,"node",json))return;
		if(this.$undoStack&&this.$editable){
			this.pushOper("delNode",[id]);
		}
		var mark=json.marked? " item_mark":"";
		if(json.type.indexOf(" round")<0){
			if(!json.width||json.width<104)json.width=104;
			if(!json.height||json.height<28)json.height=28;
			if(!json.top||json.top<0)json.top=0;
			if(!json.left||json.left<0)json.left=0;

			this.$nodeDom[id]=$("<div class='GooFlow_item"+mark+"' id='"+id+"' style='top:"+json.top*this.$scale+"px;left:"+json.left*this.$scale+"px'><table cellspacing='1' style='width:"+(json.width*this.$scale-2)+"px;height:"+(json.height*this.$scale-2)+"px;'><tr><td class='ico'><i class='ico_"+json.type+"'></i></td><td><div>"+json.name+"</div></td></tr></table><div style='display:none'><div class='rs_bottom'></div><div class='rs_right'></div><div class='rs_rb'></div><div class='rs_close'></div></div></div>");
		}
		else{
			json.width=28;json.height=28;
			this.$nodeDom[id]=$("<div class='GooFlow_item item_round"+mark+"' id='"+id+"' style='top:"+json.top*this.$scale+"px;left:"+json.left*this.$scale+"px'><table cellspacing='0' style='width:"+(json.width*this.$scale-2)+"px;height:"+(json.height*this.$scale-2)+"px;'><tr><td class='ico'><i class='ico_mm'></i></td></tr></table><div  style='display:none'><div class='rs_close'></div></div><div class='span'>"+json.name+"</div></div>");//json.type
		}
		if(GooFlow.prototype.color.node){
            if(json.type.indexOf(" mix")>-1){
                this.$nodeDom[id].css({"background-color":GooFlow.prototype.color.mix,"border-color":GooFlow.prototype.color.mix});
		        if(GooFlow.prototype.color.mixFont){
			        this.$nodeDom[id].find("td:eq(1)").css("color",GooFlow.prototype.color.mixFont);
			        this.$nodeDom[id].find(".span").css("color",GooFlow.prototype.color.mixFont);
		        }
            }else{
                //this.$nodeDom[id].css({"background-color":GooFlow.prototype.color.node,"border-color":GooFlow.prototype.color.node});//#c0ccda
				this.$nodeDom[id].css({"background-color":"#ff0000"});
				this.$endNodes.push(id);
            }
            if(mark&&GooFlow.prototype.color.mark){
                this.$nodeDom[id].css({"border-color":GooFlow.prototype.color.mark});
            }
        }
		if(json.type.indexOf(" mix")>-1){
            this.$nodeDom[id].addClass("item_mix");
		}
		
		var ua=navigator.userAgent.toLowerCase();
		if(ua.indexOf('msie')!=-1 && ua.indexOf('8.0')!=-1)
			this.$nodeDom[id].css("filter","progid:DXImageTransform.Microsoft.Shadow(color=#94AAC2,direction=135,strength=2)");
		this.$workArea.append(this.$nodeDom[id]);
		this.$nodeData[id]=json;
		++this.$nodeCount;
		if(this.$editable){
			this.$nodeData[id].alt=true;
			if(this.$deletedItem[id])	delete this.$deletedItem[id];//在回退删除操作时,去掉该元素的删除记录
		}
	},

	initWorkForNode:function(){
		//绑定点击事件
		this.$workArea.delegate(".GooFlow_item","click",{inthis:this},function(e){
			e.data.inthis.focusItem(this.id,true);
			$(this).removeClass("item_mark");
		});
		//绑定右键事件
        this.$workArea.delegate(".GooFlow_item","contextmenu",{inthis:this},function(e){
            if(e.data.inthis.onItemRightClick!=null && !e.data.inthis.onItemRightClick(this.id,"node")){
                window.event? window.event.returnValue=false : e.preventDefault();
                return false;
			}
        });
		//绑定用鼠标移动事件
		this.$workArea.delegate(".ico","mousedown",{inthis:this},function(e){
			if(!e)e=window.event;
			if(e.button==2)return false;
			var This=e.data.inthis;
			if(This.$nowType=="direct"||This.$nowType=="dashed")	return;
			var Dom=$(this).parents(".GooFlow_item");
			var id=Dom.attr("id");
			This.focusItem(id,true);
			var ev=mousePosition(e),t=This.t;		
			Dom.children("table").clone().prependTo(This.$ghost);
			var X,Y;
			X=ev.x-t.left+This.$workArea[0].parentNode.scrollLeft;
			Y=ev.y-t.top+This.$workArea[0].parentNode.scrollTop;
			var vX=X-This.$nodeData[id].left*This.$scale,vY=Y-This.$nodeData[id].top*This.$scale;
			var isMove=false;
			document.onmousemove=function(e){
				if(!e)e=window.event;
				var ev=mousePosition(e);
				if(X==ev.x-vX&&Y==ev.y-vY)	return false;
				X=ev.x-vX;Y=ev.y-vY;

				if(isMove&&This.$ghost.css("display")=="none"){
					This.$ghost.css({display:"block",
						width:This.$nodeData[id].width*This.$scale+"px", height:This.$nodeData[id].height*This.$scale+"px",
						top:This.$nodeData[id].top*This.$scale+t.top-This.$workArea[0].parentNode.scrollTop+"px",
						left:This.$nodeData[id].left*This.$scale+t.left-This.$workArea[0].parentNode.scrollLeft+"px",
						cursor:"move"
					});
				}

				if(X<t.left-This.$workArea[0].parentNode.scrollLeft)
					X=t.left-This.$workArea[0].parentNode.scrollLeft;
				else if(X+This.$workArea[0].parentNode.scrollLeft+This.$nodeData[id].width*This.$scale>t.left+This.$workArea.width())
					X=t.left+This.$workArea.width()-This.$workArea[0].parentNode.scrollLeft-This.$nodeData[id].width*This.$scale;
				if(Y<t.top-This.$workArea[0].parentNode.scrollTop)
					Y=t.top-This.$workArea[0].parentNode.scrollTop;
				else if(Y+This.$workArea[0].parentNode.scrollTop+This.$nodeData[id].height*This.$scale>t.top+This.$workArea.height())
					Y=t.top+This.$workArea.height()-This.$workArea[0].parentNode.scrollTop-This.$nodeData[id].height*This.$scale;
				This.$ghost.css({left:X+"px",top:Y+"px"});
				isMove=true;
			}
			document.onmouseup=function(e){
				if(isMove)This.moveNode(id,(X+This.$workArea[0].parentNode.scrollLeft-t.left)/This.$scale,(Y+This.$workArea[0].parentNode.scrollTop-t.top)/This.$scale);
				This.$ghost.empty().hide();
				document.onmousemove=null;
				document.onmouseup=null;
			}
		});
		//绑定双击功能
        this.$workArea.delegate(".ico","dblclick",{inthis:this},function(e){
			var id=$(this).parents(".GooFlow_item").attr("id");
            if(e.data.inthis.onItemDbClick!=null&&!e.data.inthis.onItemDbClick(id,"node"))return;
        });
		if(!this.$editable){
			this.$workArea.delegate(".GooFlow_item > .span","dblclick",{inthis:this},function(e){
				var id=this.parentNode.id;
				if(e.data.inthis.onItemDbClick!=null&&!e.data.inthis.onItemDbClick(id,"node"))return;
			});
			this.$workArea.delegate(".ico + td","dblclick",{inthis:this},function(e){
				var id=$(this).parents(".GooFlow_item").attr("id");
				if(e.data.inthis.onItemDbClick!=null&&!e.data.inthis.onItemDbClick(id,"node"))return;
			});
			return;
		}
		
		//以下是工作区为编辑模式时才绑定的事件
		//绑定鼠标覆盖/移出事件
		this.$workArea.delegate(".GooFlow_item","mouseenter",{inthis:this},function(e){
			if((e.data.inthis.$nowType!="direct"&&e.data.inthis.$nowType!="dashed")&&!document.getElementById("GooFlow_tmp_line"))	return;
			$(this).addClass("item_mark").addClass("crosshair").css("border-color",GooFlow.prototype.color.mark||"#ff8800");
		});
		this.$workArea.delegate(".GooFlow_item","mouseleave",{inthis:this},function(e){
			if((e.data.inthis.$nowType!="direct"&&e.data.inthis.$nowType!="dashed")&&!document.getElementById("GooFlow_tmp_line"))	return;
			$(this).removeClass("item_mark").removeClass("crosshair");
			if(this.id==e.data.inthis.$focus){
        $(this).css("border-color",GooFlow.prototype.color.line||"#3892D3");
			}else{
        $(this).css("border-color",GooFlow.prototype.color.node||"#A1DCEB");
			}
		});
		//绑定连线时确定初始点
		this.$workArea.delegate(".GooFlow_item","mousedown",{inthis:this},function(e){
			if(e.button==2)return false;
			var This=e.data.inthis;
			if(This.$nowType!="direct"&&This.$nowType!="dashed")	return;
			var ev=mousePosition(e),t=getElCoordinate(This.$workArea[0]);
			var X,Y;
			X=ev.x-t.left+This.$workArea[0].parentNode.scrollLeft;
			Y=ev.y-t.top+This.$workArea[0].parentNode.scrollTop;
			This.$workArea.data("lineStart",{"x":X,"y":Y,"id":this.id}).css("cursor","crosshair");
			var line=GooFlow.prototype.drawLine("GooFlow_tmp_line",[X,Y],[X,Y],true,true,1,"",This);
			This.$draw.appendChild(line);
		});
		//绑定连线时确定结束点
		this.$workArea.delegate(".GooFlow_item","mouseup",{inthis:this},function(e){
			var This=e.data.inthis;
			if((This.$nowType!="direct"&&This.$nowType!="dashed")&&!This.$mpTo.data("p"))	return;
			var lineStart=This.$workArea.data("lineStart");
			var lineEnd=This.$workArea.data("lineEnd");
			if(lineStart&&!This.$mpTo.data("p")){
				for(var i in This.$lineData)
				{
					if((This.$lineData[i].from==lineStart.id && This.$lineData[i].to==this.id) || (This.$lineData[i].to==lineStart.id && This.$lineData[i].from==this.id))
					{
						alert("两个结点之间只能有一条连线");
						This.addLog("两个结点之间只能有一条连线",true);
						return;
					}
				}
                var tmp={from:lineStart.id,to:this.id,name:""};
                if(This.$nowType=="dashed"){
                	tmp.dash=true;
				}
				This.addLine(new Date().getTime(),tmp);
				This.addLog("在结点"+This.$nodeData[lineStart.id].name+"和结点"+This.$nodeData[this.id].name+"之间添加了一条空弧");
				This.$max++;
			}
			else{
				if(lineStart){
					This.moveLinePoints(This.$focus,lineStart.id,this.id);
				}else if(lineEnd){
					This.moveLinePoints(This.$focus,this.id,lineEnd.id);
				}
				if(!This.$nodeData[this.id].marked){
          $(this).removeClass("item_mark");
          if(this.id!=This.$focus){
            $(this).css("border-color",GooFlow.prototype.color.node);
          }
          else{
            $(this).css("border-color",GooFlow.prototype.color.line);
          }
				}
			}
		});
		//绑定双击编辑事件
		// this.$workArea.delegate(".GooFlow_item > .span","dblclick",{inthis:this},function(e){
            // var id=this.parentNode.id;
            // if(e.data.inthis.onItemDbClick!=null&&!e.data.inthis.onItemDbClick(id,"node"))return;
			// var oldTxt=this.innerHTML;
			// var This=e.data.inthis;
			// var t=This.t;//t=getElCoordinate(This.$workArea[0]);
			// This.$textArea.val(oldTxt).css({display:"block",height:$(this).height()+6,width:100,
				// left:t.left+This.$nodeData[id].left*This.$scale-This.$workArea[0].parentNode.scrollLeft-26,
				// top:t.top+This.$nodeData[id].top*This.$scale-This.$workArea[0].parentNode.scrollTop+26})
				// .data("id",This.$focus).focus();
			// This.$workArea.parent().one("mousedown",function(e){
				// if(e.button==2)return false;
				// This.setName(This.$textArea.data("id"),This.$textArea.val(),"node");
				// This.$textArea.val("").removeData("id").hide();
			// });
		// });
		this.$workArea.delegate(".ico + td","dblclick",{inthis:this},function(e){
            var id=$(this).parents(".GooFlow_item").attr("id");
            if(e.data.inthis.onItemDbClick!=null&&!e.data.inthis.onItemDbClick(id,"node"))return;
			var oldTxt=this.childNodes[0].innerHTML;
			var This=e.data.inthis;
			var t=This.t;//t=getElCoordinate(This.$workArea[0]);
			This.$textArea.val(oldTxt).css({display:"block",width:$(this).width()+26,height:$(this).height()+6,
				left:t.left+26+This.$nodeData[id].left*This.$scale-This.$workArea[0].parentNode.scrollLeft,
				top:t.top+2+This.$nodeData[id].top*This.$scale-This.$workArea[0].parentNode.scrollTop})
				.data("id",This.$focus).focus();
			This.$workArea.parent().one("mousedown",function(e){
				if(e.button==2)return false;
				This.setName(This.$textArea.data("id"),This.$textArea.val(),"node");
				This.$textArea.val("").removeData("id").hide();
			});
		});
		//绑定结点的删除功能
		this.$workArea.delegate(".rs_close","click",{inthis:this},function(e){
			if(!e)e=window.event;
			var This=e.data.inthis;
			This.addLog("删除了结点"+This.$nodeData[This.$focus].name+"以及相连的弧");
			This.delNode(e.data.inthis.$focus);
			return false;
		});
		//绑定结点的RESIZE功能
		this.$workArea.delegate(".GooFlow_item > div > div[class!=rs_close]","mousedown",{inthis:this},function(e){
			if(!e)e=window.event;
			if(e.button==2)return false;
			var cursor=$(this).css("cursor");
			if(cursor=="pointer"){return;}
			var This=e.data.inthis;
			var id=This.$focus;
			This.switchToolBtn("cursor");
			e.cancelBubble = true;
			e.stopPropagation();

			var ev=mousePosition(e),t=This.t;//t=getElCoordinate(This.$workArea[0]);
			This.$ghost.css({display:"block",
				width:This.$nodeData[id].width*This.$scale+"px", height:This.$nodeData[id].height*This.$scale+"px",
				top:This.$nodeData[id].top*This.$scale+t.top-This.$workArea[0].parentNode.scrollTop+"px",
				left:This.$nodeData[id].left*This.$scale+t.left-This.$workArea[0].parentNode.scrollLeft+"px",
				cursor:cursor
			});
			var X,Y;
			X=ev.x-t.left+This.$workArea[0].parentNode.scrollLeft;
			Y=ev.y-t.top+This.$workArea[0].parentNode.scrollTop;
			var vX=(This.$nodeData[id].left*This.$scale+This.$nodeData[id].width*This.$scale)-X;
			var vY=(This.$nodeData[id].top*This.$scale+This.$nodeData[id].height*This.$scale)-Y;
			var isMove=false;
			This.$ghost.css("cursor",cursor);
			document.onmousemove=function(e){
				if(!e)e=window.event;
				var ev=mousePosition(e);
				X=ev.x-t.left+This.$workArea[0].parentNode.scrollLeft-This.$nodeData[id].left*This.$scale+vX;
				Y=ev.y-t.top+This.$workArea[0].parentNode.scrollTop-This.$nodeData[id].top*This.$scale+vY;
				if(X<104*This.$scale)	X=104*This.$scale;
				if(Y<28*This.$scale)	Y=28*This.$scale;
				isMove=true;
				switch(cursor){
					case "nw-resize":This.$ghost.css({width:X+"px",height:Y+"px"});break;
					case "w-resize":This.$ghost.css({width:X+"px"});break;
					case "n-resize":This.$ghost.css({height:Y+"px"});break;
				}
			}
			document.onmouseup=function(e){
				document.onmousemove=null;
				document.onmouseup=null;
				This.$ghost.hide();
				if(!isMove)return;
				if(!e)e=window.event;
				This.resizeNode(id,This.$ghost.outerWidth()/This.$scale,This.$ghost.outerHeight()/This.$scale);
	  		}
		});
	},
	//获取结点/连线/分组区域的详细信息
	getItemInfo:function(id,type){
		switch(type){
			case "node":	return this.$nodeData[id]||null;
			case "line":	return this.$lineData[id]||null;
			case "area":	return this.$areaData[id]||null;
		}
	},
	//取消所有结点/连线被选定的状态
	blurItem:function(){
		//this.clearLog();
		//this.clearSlotMsg();
		this.clearDivSlotArc("");
		if(this.$focus!=""){
			var jq=$("#"+this.$focus);
			if(jq.prop("tagName")=="DIV"){
				if(this.onItemBlur!=null&&!this.onItemBlur(this.$focus,"node"))	return false;
				jq.removeClass("item_focus").children("div:eq(0)").css("display","none");
				if(this.$nodeData[this.$focus].marked){
					jq.addClass("item_mark").css("border-color",GooFlow.prototype.color.mark||'#ff8800');
				}
			}
			else{
				if(this.onItemBlur!=null&&!this.onItemBlur(this.$focus,"line"))	return false;
				if(GooFlow.prototype.useSVG!=""){
					if(!this.$lineData[this.$focus].marked){
						var tmpCntat=jq[0].textContent.trim();
						if(tmpCntat.indexOf("<")>-1)
							tmpCntat=tmpCntat.slice(1,tmpCntat.length-1);
						if(tmpCntat!="" && tmpCntat!="-" && this.$slotMsg[tmpCntat].length==0)
						{
							jq[0].childNodes[1].setAttribute("stroke","#FF0000");
						}else
						{
						    jq[0].childNodes[1].setAttribute("stroke",GooFlow.prototype.color.line||"#3892D3");
						}
						jq[0].childNodes[1].setAttribute("marker-end","url(#arrow1)");
					}
				}
				else{
					if(!this.$lineData[this.$focus].marked){
                        jq[0].strokeColor=GooFlow.prototype.color.line||"#3892D3";
					}
				}
				this.$lineMove.hide().removeData("type").removeData("tid");
				if(this.$editable){
						//this.$lineOper.hide().removeData("tid");
						this.$mpFrom.hide().removeData("p");
						this.$mpTo.hide().removeData("p");
				}
			}
		}
		this.$focus="";
		return true;
	},
	NodeInArea(nodeData,Area)
	{
		var x = nodeData.left+nodeData.width/2,
			y = nodeData.top+nodeData.height/2;
		if(x>Area.left && x<Area.left+Area.width && y>Area.top && y<Area.top+Area.height)
			return true;
		else
			return false;
	},
	clearDivSlotArc:function(slotName)
	{
		if($("#slotArcName")[0])
		{
			if($("#slotArcName")[0].value == slotName)
			{
				return ;
			}
		}
		$("#GooFlow_slotMsg").remove();
	},
	saveArcSlotMsg:function(slotName)
	{
		var aaa= this.$divTmpSlot[0].childNodes.length;
		var delnum=[];
		var newtxt=[];
		for(var i =0;i<aaa;i++)
		{
			if(this.$divTmpSlot[0].childNodes[i].type != "text")
			{
				continue;
			}
			var sss=this.$divTmpSlot[0].childNodes[i];
			var tmpslotm = sss.value.trim();
			if(tmpslotm!="")
			{
				newtxt.push(tmpslotm);
				var tmpflag = false;
				for(var k = 0;k<newtxt.length-1;k++)
				{
					if(tmpslotm == newtxt[k])
					{
						delnum.push(sss.id);
						tmpflag=true;
						break;
					}
				}
				if(!tmpflag)
				{
					for(var j in this.$slotMsg[slotName])
					{
						if(this.$slotMsg[slotName][j] == tmpslotm)
						{
							tmpflag = true;
							break;
						}
					}
					if(!tmpflag)
					{
						this.$slotMsg[slotName].push(tmpslotm);
					}
				}
			}
			else
			{
				delnum.push(sss.id);
			}
		}
		for(var i=0;i< delnum.length;i++)
		{
			$("#"+delnum[i]).remove();
			$("#"+delnum[i].slice(1)).remove();
		}
		
		for(var j=this.$slotMsg[slotName].length-1;j>=0;j--)
		{
			var tmpflag = false;
			for(var i=0;i< newtxt.length;i++)
			{
				if(newtxt[i] == this.$slotMsg[slotName][j])
				{
					tmpflag=true;
					break;
				}
			}
			if(!tmpflag)
			{
				delete this.$slotMsg[slotName][j];
			}
		}
	},
	clearSlotMsg:function()
	{
		if($("#slotMsgTxt")[0])
		{
			var len = $("#slotMsgTxt")[0].childNodes.length;
			for(var i=0;i<len;i+=2)
			{
				var tmpTxt=$("#slotMsgTxt")[0].childNodes[i];
				var tmpTxtValue=tmpTxt.value.trim();
				if(tmpTxtValue=="")
					continue;
			}
		}
		$("#slotMsgCheck").remove();
	},
	saveSlotMsg:function(oldSlotName,newSlotName)
	{
		if(oldSlotName!="")
		{
			if(oldSlotName==newSlotName)
			{
				this.$slotMsg[newSlotName]=[];
			}
			else
			{
				this.$slotMsg[newSlotName]=this.$slotMsg[oldSlotName];
				delete this.$slotMsg[oldSlotName];
				if(this.$usedSlots[oldSlotName])
				{
					for(var i in this.$lineData)
					{
						if(oldSlotName==this.$lineData[i].name)
						{
							this.$lineData[i].name=newSlotName;
						}
					}
					this.onFreshClick();
				}
				this.clearDivSlotArc("");
			}
		}
		else
		{
			this.$slotMsg[newSlotName]=[];
		}
	},
	showSlotMsg:function()
	{
		this.clearSlotMsg();
		var tmpdiv1=$("<div id='slotMsgCheck' class='slotMsgCheck' draggable='true' style='border-style:solid;border-color:black;border-width:3px;background-color:#C0C0C0;position:absolute;right:300px;top:20px;height:500px;width:226px;'></div>");	
		var tmpdiv11=$("<div id='slotMsgHead' title='该区域显示当前网络所有槽（包括未使用的）的信息，单击“+”按钮，可以添加一个新槽，主要槽的命名；单击槽名按钮，可以显示出当前槽内的所有词条，而且，该槽在网络中的位置都会以紫色区别显示；单击槽名按钮后面的“-”按钮，会删除该槽的信息，如果这个槽在正在网络中使用，则不能删除，但可以更改名称。' style='background-color:#DCDCDC;height:40px;'>槽信息编辑</div>");
		tmpdiv1.append(tmpdiv11);
		var tmpdiv12=$("<div id='slotMsgBody' style='overflow:auto;background-color:white;height:420px;text-align:center;vertical-align:text-bottom;'></div>");
		tmpdiv1.append(tmpdiv12);
		var tmpdiv13=$("<div  id='slotMsgCtrl' style='background-color:#808080;height:28px;width:100%;'><input id='close' style='width:100%' type='submit' value='关闭'></input></div>");
		tmpdiv1.append(tmpdiv13);
		var tmpdiv14=$("<div id='slotMsgTxt' ></div>");
		tmpdiv12.append(tmpdiv14);
		for(var i in this.$slotMsg)
		{
			if(this.$slotMsg[i].length==0)
				continue;
			var tmpslottxt=$("<input id='_"+i+"' type='submit' style='width:80%;left:1px;' value='"+i+"' onchange=''></input>");
			tmpdiv14.append(tmpslottxt);
			var This=this;
			tmpslottxt[0].onblur=function()
			{
				if(this.type=="text" && this.value.trim()!="")
					this.type="submit";
			}
			tmpslottxt[0].onchange=function()
			{
				this.value=this.value.trim();
				var tmpValue=this.value;
				if(this.value=="")
					this.value=This.$oldSlotName;
				else
				{
					if(escape(tmpValue).indexOf("%u")>=0)
					{
						alert("槽名不能含有中文");
						This.addLog("槽名不能含有中文",true);
						this.value=This.$oldSlotName;
						return;
					}
					if(!isNaN(tmpValue.slice(0,1)))
					{
						alert("槽名不能以数字开头，只能以字母开头");
						This.addLog("槽名不能以数字开头，只能以字母开头",true);
						this.value=This.$oldSlotName;
						return;
					}
					var regx=/^[A-Za-z0-9]*$/;
					if(!regx.test(tmpValue))
					{
						alert("槽名只能是数字和字母组合");
						This.addLog("槽名只能是数字和字母组合",true);
						this.value=This.$oldSlotName;
						return;
					}
					for(var j in This.$slotMsg)
					{
						if(j==tmpValue)
						{
							if(This.$slotMsg[j].length==0)
							{
								This.addLog("存在同名的弧",true);
							}else
							{
								This.addLog("存在同名的槽",true);
							}
							this.value=This.$oldSlotName;
							return;
						}
					}
					this.type="submit";
					This.saveSlotMsg(This.$oldSlotName,this.value);
					This.$oldSlotName=this.value;
				}
			}
			tmpslottxt = $("<input type='submit' style='right:2px;width:10%;' id="+i+" value='-'></input>");			
			tmpdiv14.append(tmpslottxt);
		}
		tmpdiv12.append($("<input type='submit' style='width:90%;left:5%;' id='addSlotMsg' value='+'></input>"));
		this.$bgDiv.append(tmpdiv1);
		var This=this;
		$("#slotMsgCheck")[0].ondragstart=function(e){
			var ev=mousePosition(e),
				t=This.t;
			This.X_c=ev.x-t.left+This.$workArea[0].parentNode.scrollLeft;
			This.Y_c=ev.y-t.top+This.$workArea[0].parentNode.scrollTop;
			This.vX_c=ev.x-$("#slotMsgCheck")[0].offsetLeft*This.$scale;
			This.vY_c=ev.y-$("#slotMsgCheck")[0].offsetTop*This.$scale;
			This.slotMsgMove=true;
		}
		$("#slotMsgTxt").on("dblclick",{inthis:this},function(e){
			if(!e)e=window.event;
			var tar=e.target;
			var This = e.data.inthis;
			This.clearDivSlotArc("");
			if(tar.tagName!="INPUT")	return;
			if(tar.value!="-")
			{
				tar.type="text";
			}
		});
		$("#slotMsgCheck").on("click",{inthis:this},function(e){
			if(!e)e=window.event;
			var tar=e.target;
			var This = e.data.inthis;
			This.clearDivSlotArc("");
			if(tar.tagName!="INPUT")	return;
			switch(tar.id)
			{
				case "close":
					for(var k in This.$lineData)
					{
						This.$lineDom[k].childNodes[2].setAttribute("stroke",1||"#ff8800");
					}
					var tmpDel=$("#slotMsgTxt")[0].childNodes;
					for(var i=0;i<tmpDel.length;i++)
					{
						var tmpName=tmpDel[i].value.trim();
						if(tmpName=="-")
							continue;
						if(tmpName!="")
						{
							if(This.$slotMsg[tmpName].length==0)
								delete This.$slotMsg[tmpName];
						}
					}
					This.clearSlotMsg();
					break;
				case "addSlotMsg":
					var tmpName=new Date().getTime();
					for(var i =0;i<tmpdiv14[0].childNodes.length;i+=2)
					{
						if(tmpdiv14[0].childNodes[i].value.trim()=="")
						{
							This.addLog("只允许添加一个空槽",true);
							return;
						}
					}
					var tmpinput=$("<input id='_"+tmpName+"' type='text' style='width:80%;left:1px;'></input>");
					tmpdiv14.append(tmpinput);
					tmpinput[0].onblur=function()
					{
						if(this.type=="text" && this.value.trim()!="")
							this.type="submit";
					}
					tmpinput[0].onchange=function()
					{
						this.value=this.value.trim();
						var tmpValue=this.value;
						if(this.value=="")
							this.value=This.$oldSlotName;
						else
						{
							if(escape(tmpValue).indexOf("%u")>=0)
							{
								alert("槽名不能含有中文");
								This.addLog("槽名不能含有中文",true);
								this.value=This.$oldSlotName;
								return;
							}
							if(!isNaN(tmpValue.slice(0,1)))
							{
								alert("槽名不能以数字开头，只能以字母开头");
								This.addLog("槽名不能以数字开头，只能以字母开头",true);
								this.value=This.$oldSlotName;
								return;
							}
							var regx=/^[A-Za-z0-9]*$/;
							if(!regx.test(tmpValue))
							{
								alert("槽名只能是数字和字母组合");
								This.addLog("槽名只能是数字和字母组合",true);
								this.value=This.$oldSlotName;
								return;
							}	
							for(var j in This.$slotMsg)
							{
								if(j==tmpValue)
								{
									if(This.$slotMsg[j].length==0)
									{
										This.addLog("存在同名的弧",true);
									}else
									{
										This.addLog("存在同名的槽",true);
									}
									this.value=This.$oldSlotName;
									return;
								}
							}
							this.type="submit";
							This.saveSlotMsg(This.$oldSlotName,this.value);
							This.$oldSlotName=this.value;
						}
					}
					tmpinput=$("<input type='submit' style='right:2px;width:10%;' id="+tmpName+" value='-'></input>");
					tmpdiv14.append(tmpinput);
					break;
				default:
					if(tar.type == "submit")
					{
						if(tar.value=="-")
						{
							if($("#_"+tar.id)[0].value!="")
							{
								var tmpValue=$("#_"+tar.id)[0].value;
								for(var j in This.$usedSlots)
								{
									if(j==tmpValue)
									{
										This.addLog("槽"+tmpValue+"在网络中使用，不能删除",true);
										return;
									}
								}
								This.addLog("删除了槽"+tmpValue+"的全部信息");
								for(var i in This.$slotMsg)
								{
									if(i==$("#_"+tar.id)[0].value)
									{
										delete This.$slotMsg[i];
										break;
									}
								}
							}
							$("#_"+tar.id).remove();
							$("#"+tar.id).remove();
							if($("#slotArcName")[0] && $("#slotArcName")[0].value==tmpValue)
							{
								This.clearDivSlotArc("");
							}
						}
						else
						{
							This.$oldSlotName=tar.value;
							This.showArcSlotMsg(tar.value,"");
							for(var k in This.$lineData)
							{
								if(This.$lineData[k].name==tar.value)
								{
									This.$lineDom[k].childNodes[2].setAttribute("stroke","#ff00ff");
								}else
								{
									This.$lineDom[k].childNodes[2].setAttribute("stroke",1||"#ff8800");
								}
							}
						}
					}
					else if(tar.type=="text")
					{
						if(tar.value.trim()=="")
							This.$oldSlotName="";
					}
					break;
			}
		});
	},
	showArcSlotMsg:function(slotName,lineid)
	{
		this.clearDivSlotArc("");
		if(slotName == "" || slotName == "-")
		{
			return;
		}
		else
		{		
			var tmpvalue='槽';
			var tmpflag=false;
			if(lineid!="")
			{
				if(this.$slotMsg[slotName].length==0)
				{
					tmpvalue="弧";
					tmpflag=true;
				}
			}
			this.$divSlotMsg=$("<div id='GooFlow_slotMsg' style='border-style:solid;border-color:black;border-width:3px;background-color:#C0C0C0;position:absolute;right:20px;top:1px;height:600px;width:226px;'></div>");
			if(lineid!="")
			{
				if(!tmpflag)
					this.$divSlotHead=$("<div id='slothead' style='background-color:#DCDCDC;height:60px;'><input id='slotArcName' type='text' style='width:50%;' value='"+slotName+"' disabled='true'></input><input id='arc_cao' title='槽和弧的转变' style='width:20%;' type='submit' value='"+tmpvalue+"'></input><input type='checkbox' id='checkxl' title='设置组合线'></input>\
				<br><input type='submit' id='daoru' title='批量导入词条，文件内词条间用“\\r\\n”隔开，暂时只支持GBK' value='导入'></input><input type='submit' id='daochu' style='right:10px' value='导出'></input></br></div>");
				else
					this.$divSlotHead=$("<div id='slothead' style='background-color:#DCDCDC;height:60px;'><input id='slotArcName' type='text' style='width:50%;' value='"+slotName+"' disabled='true'></input><input id='arc_cao' title='槽和弧的转变' style='width:20%;' type='submit' value='"+tmpvalue+"'></input><input type='checkbox' id='checkxl' title='设置组合线'></input>\
				<br><input type='submit' id='daoru' style='display:none' title='批量导入词条，文件内词条间用“\\r\\n”隔开，暂时只支持GBK' value='导入'></input><input type='submit' id='daochu' style='display:none;right:10px' value='导出'></input></br></div>");
			}
			else
				this.$divSlotHead=$("<div id='slothead' style='background-color:#DCDCDC;height:60px;'><input id='slotArcName' type='text' style='width:50%;' value='"+slotName+"' disabled='true'></input><br><input type='submit' id='daoru' title='批量导入词条，文件内词条间用“\\r\\n”隔开，暂时只支持GBK' value='导入'></input>\
			<input type='submit' id='daochu' style='right:10px' value='导出'></input></br></div>");
			this.$divSlotMsg.append(this.$divSlotHead);
			this.$divSlotTxt=$("<div id='slotbody' style='overflow:auto;background-color:white;height:510px;text-align:center;vertical-align:text-bottom;'></div>");
			this.$divSlotMsg.append(this.$divSlotTxt);
			this.$divSlotCtrl=$("<div  id='slotctrl' style='background-color:#808080;height:28px;width:100%;'><input id='closeSlot' style='width:100%;right:5%;' type='submit' value='关闭'></input></div>");
			this.$divSlotMsg.append(this.$divSlotCtrl);
			this.$divTmpSlot=$("<div id='slottxt' ></div>");
			this.$divSlotTxt.append(this.$divTmpSlot);
			for(var i in this.$slotMsg[slotName])
			{
				var tmpslottxt=$("<input id='_"+slotName+"_"+i.toString()+"' maxlength='256' type='text' style='width:80%;left:1px;' value='"+this.$slotMsg[slotName][i]+"'></input>");
				this.$divTmpSlot.append(tmpslottxt);
				var This=this;
				tmpslottxt[0].onfocus=function()
				{
					This.$oldSlotTxt=this.value.trim();
				}
				tmpslottxt[0].onchange=function()
				{
					//This.saveArcSlotMsg($("#slotArcName")[0].value);
					var tmpNum=This.$slotMsg[slotName].length;
					var tmpValue=this.value.trim();
					if(This.$oldSlotTxt!=tmpValue)
					{
						if(tmpValue=="")
						{
							for(var k=0;k<This.$slotMsg[slotName].length;k++)
							{
								if(This.$slotMsg[slotName][k]==This.$oldSlotTxt)
								{
									This.$slotMsg[slotName].splice(k,1);
									break;
								}
							}
						}else
						{
							for(var k=0;k<This.$slotMsg[slotName].length;k++)
							{
								if(This.$slotMsg[slotName][k]==tmpValue)
								{
									This.addLog("槽中已经存在这个词语",true);
									this.value=This.$oldSlotTxt;
									return;
								}
							}
							if(This.$oldSlotTxt=="")
								This.$slotMsg[slotName].push(tmpValue);
							else
							{
								for(var k=0;k<This.$slotMsg[slotName].length;k++)
								{
									if(This.$slotMsg[slotName][k]==This.$oldSlotTxt)
									{
										This.$slotMsg[slotName][k]=tmpValue;
										break;
									}
								}
							}
						}
					}
					else
					{
						if(tmpValue=="")
							return;
						else
						{
							for(var k=0;k<This.$slotMsg[slotName].length;k++)
							{
								if(This.$slotMsg[slotName][k]==tmpValue)
								{
									This.addLog("槽中已经存在这个词语",true);
									this.value="";
									return;
								}
							}
							This.$slotMsg[slotName].push(tmpValue);
						}
					}
					if((tmpNum==0 && This.$slotMsg[slotName].length>0) || (tmpNum>0 && This.$slotMsg[slotName].length==0))
					{
						for(var k in This.$lineDom)
						{
							if(This.$lineDom[k].textContent.replace(/<|>/g,"")==slotName)
							{
								This.$lineDom[k].childNodes[2].textContent="<"+slotName+">";
								This.$lineDom[k].childNodes[1].setAttribute("stroke","#3892d3");
							}
						}
					}
				}
				tmpslottxt = $("<input title='删除当前词语' type='submit' style='right:2px;width:10%;' id="+slotName+"_"+i.toString()+" value='-'></input>");
				this.$divTmpSlot.append($(tmpslottxt));	
			}
			if(tmpflag)
			    this.$divSlotTxt.append($("<input title='添加一个词语' type='submit' style='width:90%;left:5%;display:none;' id='addSlot' value='+'></input>"));
			else
				this.$divSlotTxt.append($("<input title='添加一个词语' type='submit' style='width:90%;left:5%;' id='addSlot' value='+'></input>"));
			this.$bgDiv.append(this.$divSlotMsg);
			if(lineid!="")
				if(this.$lineData[lineid].type.length==3)
					$("#checkxl")[0].checked=true;
			this.$divSlotMsg.on("click",{inthis:this},function(e){
				if(!e)e=window.event;
				var tar=e.target;
				if(tar.tagName!="INPUT")	return;
				var This = e.data.inthis;
				switch(tar.id)
				{
					case "closeSlot":
						This.clearDivSlotArc("");
						break;
					case "addSlot":
						var len = This.$divTmpSlot[0].childNodes.length;
						var tmpName=new Date().getTime();
						for(var i =0;i<len;i+=2)
						{
							if(This.$divTmpSlot[0].childNodes[i].value.trim()=="")
							{
								alert("每次只允许添加一个空槽，已经有一个空槽了");
								This.addLog("每次只允许添加一个空槽，已经有一个空槽了",true);
								return;
							}
						}
						var tmpinput=$("<input id='_"+tmpName+"' type='text' maxlength='256' style='width:80%;left:1px;' onchange=''></input>");
						This.$divTmpSlot.append(tmpinput);
						tmpinput[0].onfocus=function()
						{
							This.$oldSlotTxt=this.value.trim();
						}
						tmpinput[0].onchange=function()
						{
							var tmpNum=This.$slotMsg[slotName].length;
							var tmpValue=this.value.trim();
							if(This.$oldSlotTxt!=tmpValue)
							{
								if(tmpValue=="")
								{
									for(var k=0;k<This.$slotMsg[slotName].length;k++)
									{
										if(This.$slotMsg[slotName][k]==This.$oldSlotTxt)
										{
											This.$slotMsg[slotName].splice(k,1);
											break;
										}
									}
								}else
								{
									for(var k=0;k<This.$slotMsg[slotName].length;k++)
									{
										if(This.$slotMsg[slotName][k]==tmpValue)
										{
											This.addLog("槽中已经存在这个词语",true);
											this.value=This.$oldSlotTxt;
											return;
										}
									}
									if(This.$oldSlotTxt=="")
										This.$slotMsg[slotName].push(tmpValue);
									else
									{
										for(var k=0;k<This.$slotMsg[slotName].length;k++)
										{
											if(This.$slotMsg[slotName][k]==This.$oldSlotTxt)
											{
												This.$slotMsg[slotName][k]=tmpValue;
												break;
											}
										}
									}
								}
							}
							else
							{
								if(tmpValue=="")
									return;
								else
								{
									for(var k=0;k<This.$slotMsg[slotName].length;k++)
									{
										if(This.$slotMsg[slotName][k]==tmpValue)
										{
											This.addLog("槽中已经存在这个词语",true);
											this.value="";
											return;
										}
									}
									This.$slotMsg[slotName].push(tmpValue);
								}
							}
							//This.saveArcSlotMsg($("#slotArcName")[0].value);
							if((tmpNum==0 && This.$slotMsg[slotName].length>0) || (tmpNum>0 && This.$slotMsg[slotName].length==0))
							{
								for(var k in This.$lineDom)
								{
									if(This.$lineDom[k].textContent.replace(/<|>/g,"")==slotName)
									{
										This.$lineDom[k].childNodes[2].textContent="<"+slotName+">";
										This.$lineDom[k].childNodes[1].setAttribute("stroke","#3892d3");
									}
								}
							}
						}
						tmpinput=$("<input type='submit' style='right:2px;width:10%;' id="+tmpName+" value='-'></input>");
						This.$divTmpSlot.append($(tmpinput));
						break;
					case "daochu":
						var writeStr="";
						for(var i=0;i< This.$slotMsg[slotName].length;i++)
						{
							writeStr+=This.$slotMsg[slotName][i]+"\r\n";
						}
						var a = document.createElementNS("http://www.w3.org/1999/xhtml", "a"),
							tmpStr=encodeURIComponent(writeStr);
						a.href = "data:text;charset=utf-8,\ufeff"+tmpStr;//dataURL.createObjectURL(exprot_data);//
						a.download = slotName+".txt";  //设定下载名称
						document.body.appendChild(a);
						a.click(); //点击触发下载
						document.body.removeChild(a);
						break;
					case "daoru":
						$("#openslottxt").remove();
						var tmpdiv = $("<div id='openslottxt' style='visibility:hidden;'><input type='file' id='filename_slot' onchange=''></input></div>");
						This.$workArea.append(tmpdiv);
						$("#filename_slot").on("change",function(e){
							if(this.value!="")
							{
								var reader = new FileReader();
								var str=null;
								try{
									reader.readAsText(this.files[0],"UTF-8");
								}
								catch(eee)
								{
									alert("cannot open this file");
									This.addLog("cannot open this file",true);
									return;
								}	
								reader.onload=function(){
									str=reader.result;
									if(str != "")
									{
										var slotTexts=str.split('\n');
										for(var i=0;i<slotTexts.length;i++)
										{
											var tmpTxt=slotTexts[i].trim();
											if(tmpTxt=="")
												continue;
											var tmpslottxt=$("<input id='_"+slotName+"_"+i.toString()+"' type='text' style='width:80%;left:1px;' value='"+tmpTxt+"'></input>");
											This.$divTmpSlot.append(tmpslottxt);
											This.$slotMsg[slotName].push(tmpTxt);
											tmpslottxt[0].onchange=function()
											{
												This.saveArcSlotMsg($("#slotArcName")[0].value);
											}
											tmpslottxt = $("<input title='删除当前词语' type='submit' style='right:2px;width:10%;' id="+slotName+"_"+i.toString()+" value='-'></input>");
											This.$divTmpSlot.append(tmpslottxt);	
										}
										This.addLog("槽"+slotName+"添加了："+str);
									}else
									{
										alert("文件"+this.value+"为空");
										This.addLog("文件"+this.value+"为空",true);
									}
								}
							}
							$("#openslottxt").remove();
						});
						$("#filename_slot").click();	
						break;
					case "arc_cao":
					    if(tar.value == "槽")
						{
							if(This.$slotMsg[slotName].length>0)
							{
								alert("这个槽内含有至少一个词，不能转为弧，请重新输入弧名");
								This.addLog("这个槽内含有至少一个词，不能转为弧，请重新输入弧名",true);
								return;
							}
							var len = This.$divTmpSlot[0].childNodes.length/2;
							for(var i=0;i<len;i++)
							{
							   $("#_"+slotName+"_"+i.toString()).remove();
							   $("#"+slotName+"_"+i.toString()).remove();
							}
							tar.value="弧";
							$("#daoru").hide();
							$("#daochu").hide();
							if(This.$focus!="")
							{
								if($("#"+This.$focus)[0].textContent.indexOf("<")>-1)
								{
									$("#"+This.$focus)[0].childNodes[2].textContent=$("#"+This.$focus)[0].textContent.slice(1,$("#"+This.$focus)[0].textContent.length-1);
								}
							}
							$("#addSlot").hide();
						}else
						{
							if(escape(slotName).indexOf("%u")>=0)
							{
								This.addLog("名称为中文的弧不能转换为槽",true);
								return;
							}
							if(!isNaN(slotName.slice(0,1)))
							{
								This.addLog("槽名不能以数字开头，只能以字母开头",true);
								return;
							}
							var regx=/^[A-Za-z0-9]*$/;
							if(!regx.test(slotName))
							{
								This.addLog("槽名只能是数字和字母组合",true);
								return;
							}
							This.saveArcSlotMsg(slotName);
							tar.value="槽";
							if(This.$focus!="")
							{
								var tttt=$("#"+This.$focus)[0];
								if($("#"+This.$focus)[0].nodename=="g")
								{
									$("#"+This.$focus)[0].childNodes[2].textContent="<"+$("#"+This.$focus)[0].textContent+">";
								}
							}
							$("#addSlot").show();
							$("#daoru").show();
							$("#daochu").show();
						}
						break;
					case "checkxl":
						if(tar.checked)
						{
							if($("#arc_cao")[0].value=="弧")
							{
								This.setLineType(lineid,"axl");
							}
							else
							{
								This.setLineType(lineid,"cxl");
							}
							This.addLog("结点"+This.$nodeData[This.$lineData[lineid].from].name+"与结点"+This.$nodeData[This.$lineData[lineid].to].name+"之间添加了空弧");
						}else
						{
							if($("#arc_cao")[0].value=="弧")
							{
								This.setLineType(lineid,"al");
								This.addLog("结点"+This.$nodeData[This.$lineData[lineid].from].name+"与结点"+This.$nodeData[This.$lineData[lineid].to].name+"之间弧转换为槽");
							}
							else
							{
								This.setLineType(lineid,"cl");
								This.addLog("结点"+This.$nodeData[This.$lineData[lineid].from].name+"与结点"+This.$nodeData[This.$lineData[lineid].to].name+"之间槽转换为弧");
							}
						}
						break;
					default:
						if(tar.type == "submit")
						{
							if($("#_"+tar.id)[0].value!="")
							{
								This.addLog("删除了槽<"+slotName+">的词语\""+$("#_"+tar.id)[0].value+"\"");
								for(var i in This.$slotMsg[slotName])
								{
									if(This.$slotMsg[slotName][i]==$("#_"+tar.id)[0].value)
									{
										This.$slotMsg[slotName].splice(i,1);
										if(This.$slotMsg[slotName].length==0)
										{
											for(var k in This.$lineDom)
											{
												if(This.$lineDom[k].textContent.replace(/<|>/g,"")==slotName)
												{
													This.$lineDom[k].childNodes[2].textContent=slotName;
													This.$lineDom[k].childNodes[1].setAttribute("stroke","#FF0000");
												}
											}
										}
										break;
									}
								}
							}
							$("#_"+tar.id).remove();
							$("#"+tar.id).remove();
						}
						// else if(tar.type=="text")
						// {
							// This.$oldSlotTxt=tar.value.trim();
						// }
						break;
				}
				
		});
		}
	},
	findCplxPath:function(This,str){
		var nodes={},
			que=[],
			path={},
			findPath={},
			showTxt="",
			startFlag=0,
			startNodeId=0;
		for(var i in This.$nodeData)
		{
			nodes[i]={ins:[],outs:[],lineid:[]};
			path[i]={way:[],str:[],contxt:[]};
		}
		for(var i in This.$lineData)
		{
			nodes[This.$lineData[i].from].outs.push(parseInt(This.$lineData[i].to));
			nodes[This.$lineData[i].to].ins.push(parseInt(This.$lineData[i].from));
			nodes[This.$lineData[i].from].lineid.push(i);
		}
		for(var i in nodes)
		{
			if(nodes[i].ins.length==0)
			{
				startFlag++;
				startNodeId=i;
			}
		}
		if(startFlag!=1)
		{
			showTxt="N";
			return showTxt;
		}
		que.push(startNodeId);
		path[startNodeId]={way:[startNodeId],str:[str],contxt:[[]]};
		while(que.length!=0)
		{
			var tmpNodeId=que.shift();
			if(JSON.stringify(path[tmpNodeId])=="{}")
				continue;
			var tmpFlag=false;
			if(nodes[tmpNodeId].outs.length==0)
				tmpFlag=true;
			for(var j=0;j<path[tmpNodeId].way.length;j++)
			{
				var tmpPath=path[tmpNodeId].way[j];
				if(tmpPath.length==0)
					continue;
				var tmpStr=path[tmpNodeId].str[j],
					tmpContxt=path[tmpNodeId].contxt[j];
				if(tmpStr.length>0)
				{
					if(!tmpFlag)
					{
						for(var i=0;i<nodes[tmpNodeId].outs.length;i++)
						{
							var tmpOutNodeId=nodes[tmpNodeId].outs[i],
								tmpLineId=nodes[tmpNodeId].lineid[i],
								tmpType=This.$lineData[tmpLineId].type;
							if(tmpType=="xl" || tmpType=="axl" || tmpType=="cxl")
							{
								var tmpQueFlag=false;
								for(var l=0;l<que.length;l++)
								{
									if(que[l]==tmpOutNodeId)
									{
										tmpQueFlag=true;
										break;
									}
								}
								if(!tmpQueFlag)
								{
									que.push(tmpOutNodeId);
								}
								path[tmpOutNodeId].str.push(tmpStr);
								path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
								path[tmpOutNodeId].contxt.push(tmpContxt.concat("-"));
							}
							if(tmpType=="al" || tmpType=="axl")
							{
								var tmpArcTxt=This.$lineData[tmpLineId].name;
								if(tmpArcTxt.length<=tmpStr[0][0].length)
								{
									if(tmpArcTxt==tmpStr[0][0].slice(0,tmpArcTxt.length))
									{
										if(tmpStr[0][0].length==tmpArcTxt.length)
										{
											if(tmpStr[0].length>1)
											{
												var aaa=[tmpStr[0].slice(1,tmpStr[0].length)];
												path[tmpOutNodeId].str.push(aaa.concat(tmpStr.slice(1,tmpStr.length)));
											}
											else
											{
												path[tmpOutNodeId].str.push(tmpStr.slice(1,tmpStr.length));
											}
										}
										else
										{
											var aaa=[[tmpStr[0][0].slice(tmpArcTxt.length,tmpStr[0][0].length)].concat(tmpStr[0].slice(1,tmpStr[0].length))];
											path[tmpOutNodeId].str.push(aaa.concat(tmpStr.slice(1,tmpStr.length)));
										}
										var tmpQueFlag=false;
										for(var l=0;l<que.length;l++)
										{
											if(que[l]==tmpOutNodeId)
											{
												tmpQueFlag=true;
												break;
											}
										}
										if(!tmpQueFlag)
											que.push(tmpOutNodeId);
										path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
										path[tmpOutNodeId].contxt.push(tmpContxt.concat(tmpArcTxt));
									}
								}
							}
							if(tmpType=="cl" || tmpType=="cxl")
							{
								var tmpSlotTxt=This.$slotMsg[This.$lineData[tmpLineId].name];//.replace(/<|>/g,"")];
								var tmpMaxLen=0;
								for(var k=0;k<tmpSlotTxt.length;k++)
								{
									if(tmpMaxLen<tmpSlotTxt[k].length)
										tmpMaxLen=tmpSlotTxt[k].length;
								}
								if(tmpMaxLen<tmpStr[0][0].length)
								{
									var tmpStopFlag=false;
									for(var k=tmpMaxLen;k>0;k--)
									{
										var tmpCmpStr=tmpStr[0][0].slice(0,k);
										for(var m=0;m<tmpSlotTxt.length;m++)
										{
											if(tmpSlotTxt[m].length==k)
											{
												if(tmpSlotTxt[m]==tmpCmpStr)
												{
													var tmpQueFlag=false;
													for(var l=0;l<que.length;l++)
													{
														if(que[l]==tmpOutNodeId)
														{
															tmpQueFlag=true;
															break;
														}
													}
													if(!tmpQueFlag)
														que.push(tmpOutNodeId);
													var aaa=[[tmpStr[0][0].slice(k,tmpStr[0][0].length)].concat(tmpStr[0].slice(1,tmpStr[0].length))];
													path[tmpOutNodeId].str.push(aaa.concat(tmpStr.slice(1,tmpStr.length)));
													//path[tmpOutNodeId].str.push(tmpStr.slice(k,tmpStr.length));
													path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
													path[tmpOutNodeId].contxt.push(tmpContxt.concat(tmpCmpStr));
													tmpStopFlag=true;
													break;
												}
											}
										}
										if(tmpStopFlag)
											break;
									}
								}
								else
								{
									for(var k=tmpStr[0][0].length;k>0;k--)
									{
										var tmpStopFlag=false;
										var tmpCmpStr=tmpStr[0][0].slice(0,k);
										for(var m=0;m<tmpSlotTxt.length;m++)
										{
											if(tmpSlotTxt[m].length==k)
											{
												if(tmpSlotTxt[m]==tmpCmpStr)
												{
													if(k==tmpStr[0][0].length)
													{
														if(tmpStr[0].length>1)
														{
															var aaa=[tmpStr[0].slice(1,tmpStr[0].length)];
															path[tmpOutNodeId].str.push(aaa.concat(tmpStr.slice(1,tmpStr.length)));
														}
														else
														{
															path[tmpOutNodeId].str.push(tmpStr.slice(1,tmpStr.length));
														}
													}
													else
													{
														var aaa=[[tmpStr[0][0].slice(k,tmpStr[0][0].length)].concat(tmpStr[0].slice(1,tmpStr[0].length))];
														path[tmpOutNodeId].str.push(aaa.concat(tmpStr.slice(1,tmpStr.length)));
														//path[tmpOutNodeId].str.push(tmpStr.slice(k,tmpStr.length));
													}
													var tmpQueFlag=false;
													for(var l=0;l<que.length;l++)
													{
														if(que[l]==tmpOutNodeId)
														{
															tmpQueFlag=true;
															break;
														}
													}
													if(!tmpQueFlag)
														que.push(tmpOutNodeId);
													path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
													path[tmpOutNodeId].contxt.push(tmpContxt.concat(tmpCmpStr));
													tmpStopFlag=true;
													break;
												}
											}
										}
										if(tmpStopFlag)
											break;
									}
								}
							}
						}
						//delete path[tmpNodeId].str[j];
						path[tmpNodeId].way[j]="";
					}
					else
					{
						//delete path[tmpNodeId].str[j];
						path[tmpNodeId].way[j]="";
					}
				}
				else
				{
					if(!tmpFlag)
					{
						var tmpDel=false;
						for(var i=0;i<nodes[tmpNodeId].outs.length;i++)
						{
							var tmpOutNodeId=nodes[tmpNodeId].outs[i];
							var tmpLineId=nodes[tmpNodeId].lineid[i];
							var tmpType=This.$lineData[tmpLineId].type;
							if(tmpType=="xl" || tmpType=="cxl" || tmpType=="axl")
							{
								tmpDel=true;
								var tmpQueFlag=false;
								for(var l=0;l<que.length;l++)
								{
									if(que[l]==tmpOutNodeId)
									{
										tmpQueFlag=true;
										break;
									}
								}
								if(!tmpQueFlag)
								{
									que.push(tmpOutNodeId);
								}
								path[tmpOutNodeId].str.push(tmpStr);
								path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
								path[tmpOutNodeId].contxt.push(tmpContxt.concat("-"));
							}
						}
						if(!tmpDel)
						{
							//delete path[tmpNodeId].str[j];
							path[tmpNodeId].way[j]="";
						}
					}
					else
					{
						if(JSON.stringify(findPath[tmpNodeId])=="{}")
							findPath[tmpNodeId]=tmpPath;
						else
							findPath[tmpNodeId]+=" "+tmpPath;
						//que=[];
						//break;
					}
				}
			}
		}
		for(var i in findPath)
		{
			var tmpWays=findPath[i].split(" ");
			for(var len=1;len<tmpWays.length;len++)
			{
				for(var j=path[i].way.length-1;j>=0;j--)
				{
					if(path[i].way[j]==tmpWays[len])
					{
						var tmpNodeArr=tmpWays[len].split("\x01");
						showTxt+="path"+len+":"+tmpWays[len].replace(/\x01/g,",");
						showTxt+="\n";
						for(var k=0;k<path[i].contxt[j].length;k++)
						{
							for(var m in This.$lineData)
							{
								if(This.$lineData[m].from==tmpNodeArr[k] && This.$lineData[m].to==tmpNodeArr[k+1])
								{
									if(path[i].contxt[j][k]=="-")
									{
										showTxt+=tmpNodeArr[k]+"与"+tmpNodeArr[k+1]+"之间的虚弧：";
									}
									else
									{
										if(This.$lineData[m].type=="al" || This.$lineData[m].type=="axl")
										{
											showTxt+=tmpNodeArr[k]+"与"+tmpNodeArr[k+1]+"之间的弧\""+This.$lineData[m].name+"\"：";
										}
										else if(This.$lineData[m].type=="cl" || This.$lineData[m].type=="cxl")
										{
											showTxt+=tmpNodeArr[k]+"与"+tmpNodeArr[k+1]+"之间的槽<"+This.$lineData[m].name+">：";
										}
									}
									break;
								}
							}
							showTxt+=path[i].contxt[j][k]+"；";
						}
						showTxt+="\n";
						break;
					}
				}
			}
		}
		return showTxt;
	},
	findPath:function(This,str,IsSpace){
		var nodes={},
			que=[],
			path={},
			findPath={},
			showTxt="",
			startNodeId=0,
			startFlag=0;
		for(var i in This.$nodeData)
		{
			nodes[i]={ins:[],outs:[],lineid:[]};
			path[i]={way:[],str:[],contxt:[]};
		}
		for(var i in This.$lineData)
		{
			nodes[This.$lineData[i].from].outs.push(parseInt(This.$lineData[i].to));
			nodes[This.$lineData[i].to].ins.push(parseInt(This.$lineData[i].from));
			nodes[This.$lineData[i].from].lineid.push(i);
		}
		for(var i in nodes)
		{
			if(nodes[i].ins.length==0)
			{
				startFlag++;
				startNodeId=i;
			}
		}
		if(startFlag!=1)
		{
			showTxt="N";
			return showTxt;
		}
		que.push(startNodeId);
		path[startNodeId]={way:[startNodeId],str:[str],contxt:[[]]};
		while(que.length!=0)
		{
			var tmpNodeId=que.shift();
			if(JSON.stringify(path[tmpNodeId])=="{}")
				continue;
			var tmpFlag=false;
			if(nodes[tmpNodeId].outs.length==0)
				tmpFlag=true;
			for(var j=0;j<path[tmpNodeId].way.length;j++)
			{
				var tmpPath=path[tmpNodeId].way[j];
				if(tmpPath.length==0)
					continue;
				var tmpStr=path[tmpNodeId].str[j],
					tmpContxt=path[tmpNodeId].contxt[j];
				if(tmpStr.length>0)
				{
					if(!tmpFlag)
					{
						for(var i=0;i<nodes[tmpNodeId].outs.length;i++)
						{
							var tmpOutNodeId=nodes[tmpNodeId].outs[i],
								tmpLineId=nodes[tmpNodeId].lineid[i],
								tmpType=This.$lineData[tmpLineId].type;
							if(tmpType=="xl" || tmpType=="axl" || tmpType=="cxl")
							{
								var tmpQueFlag=false;
								for(var l=0;l<que.length;l++)
								{
									if(que[l]==tmpOutNodeId)
									{
										tmpQueFlag=true;
										break;
									}
								}
								if(!tmpQueFlag)
								{
									que.push(tmpOutNodeId);
								}
								path[tmpOutNodeId].str.push(tmpStr);
								path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
								path[tmpOutNodeId].contxt.push(tmpContxt.concat("-"));
							}
							if(tmpType=="al" || tmpType=="axl")
							{
								var tmpArcTxt=This.$lineData[tmpLineId].name;
								if(IsSpace)
								{
									if(tmpArcTxt==tmpStr[0])
									{
										path[tmpOutNodeId].str.push(tmpStr.slice(1,tmpStr.length));
										var tmpQueFlag=false;
										for(var l=0;l<que.length;l++)
										{
											if(que[l]==tmpOutNodeId)
											{
												tmpQueFlag=true;
												break;
											}
										}
										if(!tmpQueFlag)
											que.push(tmpOutNodeId);
										path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
										path[tmpOutNodeId].contxt.push(tmpContxt.concat(tmpArcTxt));
									}
								}
								else
								{
									if(tmpArcTxt.length<=tmpStr[0].length)
									{
										if(tmpArcTxt==tmpStr[0].slice(0,tmpArcTxt.length))
										{
											if(tmpStr[0].length==tmpArcTxt.length)
											{
												path[tmpOutNodeId].str.push(tmpStr.slice(1,tmpStr.length));
												//path[tmpOutNodeId].str.push("");
											}
											else
											{
												var asd=[tmpStr[0].slice(tmpArcTxt.length,tmpStr[0].length)];
												path[tmpOutNodeId].str.push(asd.concat(tmpStr.slice(1,tmpStr.length)));
												//path[tmpOutNodeId].str.push(tmpStr.slice(tmpArcTxt.length,tmpStr.length));
											}
											var tmpQueFlag=false;
											for(var l=0;l<que.length;l++)
											{
												if(que[l]==tmpOutNodeId)
												{
													tmpQueFlag=true;
													break;
												}
											}
											if(!tmpQueFlag)
												que.push(tmpOutNodeId);
											path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
											path[tmpOutNodeId].contxt.push(tmpContxt.concat(tmpArcTxt));
										}
									}
								}
							}
							if(tmpType=="cl" || tmpType=="cxl")
							{
								var tmpSlotTxt=This.$slotMsg[This.$lineData[tmpLineId].name];//.replace(/<|>/g,"")];
								if(IsSpace)
								{
									for(var k=0;k<tmpSlotTxt.length;k++)
									{
										if(tmpSlotTxt[k]==tmpStr[0])
										{
											var tmpQueFlag=false;
											for(var l=0;l<que.length;l++)
											{
												if(que[l]==tmpOutNodeId)
												{
													tmpQueFlag=true;
													break;
												}
											}
											if(!tmpQueFlag)
												que.push(tmpOutNodeId);
											path[tmpOutNodeId].str.push(tmpStr.slice(1,tmpStr.length));
											//path[tmpOutNodeId].str.push(tmpStr.slice(k,tmpStr.length));
											path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
											path[tmpOutNodeId].contxt.push(tmpContxt.concat(tmpStr[0]));
											break;
										}
									}
								}
								else
								{
									var tmpMaxLen=0;
									for(var k=0;k<tmpSlotTxt.length;k++)
									{
										if(tmpMaxLen<tmpSlotTxt[k].length)
											tmpMaxLen=tmpSlotTxt[k].length;
									}
									if(tmpMaxLen<tmpStr[0].length)
									{
										var tmpStopFlag=false;
										for(var k=tmpMaxLen;k>0;k--)
										{
											var tmpCmpStr=tmpStr[0].slice(0,k);
											for(var m=0;m<tmpSlotTxt.length;m++)
											{
												if(tmpSlotTxt[m].length==k)
												{
													if(tmpSlotTxt[m]==tmpCmpStr)
													{
														var tmpQueFlag=false;
														for(var l=0;l<que.length;l++)
														{
															if(que[l]==tmpOutNodeId)
															{
																tmpQueFlag=true;
																break;
															}
														}
														if(!tmpQueFlag)
															que.push(tmpOutNodeId);
														var asd=[tmpStr[0].slice(k,tmpStr[0].length)];
														path[tmpOutNodeId].str.push(asd.concat(tmpStr.slice(1,tmpStr.length)));
														//path[tmpOutNodeId].str.push(tmpStr.slice(k,tmpStr.length));
														path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
														path[tmpOutNodeId].contxt.push(tmpContxt.concat(tmpCmpStr));
														tmpStopFlag=true;
														break;
													}
												}
											}
											if(tmpStopFlag)
												break;
										}
									}
									else
									{
										for(var k=tmpStr[0].length;k>0;k--)
										{
											var tmpStopFlag=false;
											var tmpCmpStr=tmpStr[0].slice(0,k);
											for(var m=0;m<tmpSlotTxt.length;m++)
											{
												if(tmpSlotTxt[m].length==k)
												{
													if(tmpSlotTxt[m]==tmpCmpStr)
													{
														if(k==tmpStr[0].length)
														{
															//path[tmpOutNodeId].str.push("");
															path[tmpOutNodeId].str.push(tmpStr.slice(1,tmpStr.length));
														}
														else
														{
															var asd=[tmpStr[0].slice(k,tmpStr[0].length)];
															path[tmpOutNodeId].str.push(asd.concat(tmpStr.slice(1,tmpStr.length)));
															//path[tmpOutNodeId].str.push(tmpStr.slice(k,tmpStr.length));
														}
														var tmpQueFlag=false;
														for(var l=0;l<que.length;l++)
														{
															if(que[l]==tmpOutNodeId)
															{
																tmpQueFlag=true;
																break;
															}
														}
														if(!tmpQueFlag)
															que.push(tmpOutNodeId);
														path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
														path[tmpOutNodeId].contxt.push(tmpContxt.concat(tmpCmpStr));
														tmpStopFlag=true;
														break;
													}
												}
											}
											if(tmpStopFlag)
												break;
										}
									}
								}
							}
						}
						path[tmpNodeId].way[j]="";
					}
					else
					{
						path[tmpNodeId].way[j]="";
					}
				}
				else
				{
					if(!tmpFlag)
					{
						var tmpDel=false;
						for(var i=0;i<nodes[tmpNodeId].outs.length;i++)
						{
							var tmpOutNodeId=nodes[tmpNodeId].outs[i];
							var tmpLineId=nodes[tmpNodeId].lineid[i];
							var tmpType=This.$lineData[tmpLineId].type;
							if(tmpType=="xl" || tmpType=="cxl" || tmpType=="axl")
							{
								tmpDel=true;
								var tmpQueFlag=false;
								for(var l=0;l<que.length;l++)
								{
									if(que[l]==tmpOutNodeId)
									{
										tmpQueFlag=true;
										break;
									}
								}
								if(!tmpQueFlag)
								{
									que.push(tmpOutNodeId);
								}
								path[tmpOutNodeId].str.push(tmpStr);
								path[tmpOutNodeId].way.push(tmpPath+"\x01"+tmpOutNodeId);
								path[tmpOutNodeId].contxt.push(tmpContxt.concat("-"));
							}
						}
						if(!tmpDel)
						{
							path[tmpNodeId].way[j]="";
						}
					}
					else
					{
						if(JSON.stringify(findPath[tmpNodeId])=="{}")
							findPath[tmpNodeId]=tmpPath;
						else
							findPath[tmpNodeId]+=" "+tmpPath;
					}
				}
			}
		}
		for(var i in findPath)
		{
			var tmpWays=findPath[i].split(" ");
			for(var len=1;len<tmpWays.length;len++)
			{
				for(var j=path[i].way.length-1;j>=0;j--)
				{
					if(path[i].way[j]==tmpWays[len])
					{
						var tmpNodeArr=tmpWays[len].split("\x01");
						showTxt+="path"+len+":"+tmpWays[len].replace(/\x01/g,",");
						showTxt+="\n";
						for(var k=0;k<path[i].contxt[j].length;k++)
						{
							for(var m in This.$lineData)
							{
								if(This.$lineData[m].from==tmpNodeArr[k] && This.$lineData[m].to==tmpNodeArr[k+1])
								{
									if(path[i].contxt[j][k]=="-")
									{
										showTxt+=tmpNodeArr[k]+"与"+tmpNodeArr[k+1]+"之间的虚弧：";
									}
									else
									{
										if(This.$lineData[m].type=="al" || This.$lineData[m].type=="axl")
										{
											showTxt+=tmpNodeArr[k]+"与"+tmpNodeArr[k+1]+"之间的弧\""+This.$lineData[m].name+"\"：";
										}
										else if(This.$lineData[m].type=="cl" || This.$lineData[m].type=="cxl")
										{
											showTxt+=tmpNodeArr[k]+"与"+tmpNodeArr[k+1]+"之间的槽<"+This.$lineData[m].name+">：";
										}
									}
									break;
								}
							}
							showTxt+=path[i].contxt[j][k]+"；";
						}
						showTxt+="\n";
						break;
					}
				}
			}
		}
		return showTxt;
	},
	//选定某个结点/转换线 bool:TRUE决定了要触发选中事件，FALSE则不触发选中事件，多用在程序内部调用。
	focusItem:function(id,bool){
		var jq=$("#"+id);
		if(jq.length==0)	return;
		if(!this.blurItem())	return;//先执行"取消选中",如果返回FLASE,则也会阻止选定事件继续进行.
		if(jq.prop("tagName")=="DIV"){
			if(bool&&this.onItemFocus!=null&&!this.onItemFocus(id,"node"))	return;
			jq.addClass("item_focus");
			if(GooFlow.prototype.color.line){
				jq.css("border-color",GooFlow.prototype.color.line);
			}
			if(this.$editable)jq.children("div:eq(0)").css("display","block");
			//this.$workArea.append(jq);
			this.addLog("你选择了结点："+this.$nodeData[id].name);
		}
		else{//如果是连接线
			var logtxt="";
			if(this.$lineData[id].name=="-")
				logtxt+="你选择了一条空弧，";
			else
			{
				if(this.$slotMsg[this.$lineData[id].name].length==0)
				{
					if(this.$lineData[id].type.length===3)
						logtxt+="你选择了含有空弧的弧："+this.$lineData[id].name+"，";
					else
						logtxt+="你选择了弧："+this.$lineData[id].name+"，";
				}
				else
				{
					if(this.$lineData[id].type.length===3)
						logtxt+="你选择了含有空弧的槽：<"+this.$lineData[id].name+">，";
					else
						logtxt+="你选择了槽：<"+this.$lineData[id].name+">，";
				}
			}
			logtxt+="它的前结点是：结点"+this.$nodeData[this.$lineData[id].from].name+"，后结点是：结点"+this.$nodeData[this.$lineData[id].to].name;
			this.addLog(logtxt);
		    this.showArcSlotMsg(this.$lineData[id].name,id);
			if(this.onItemFocus!=null&&!this.onItemFocus(id,"line"))	return;
			if(GooFlow.prototype.useSVG!=""){
				jq[0].childNodes[1].setAttribute("stroke",GooFlow.prototype.color.mark||"#ff8800");
				jq[0].childNodes[1].setAttribute("marker-end","url(#arrow2)");
			}
			else{
                jq[0].strokeColor=GooFlow.prototype.color.mark||"#ff8800";
			}
			if(!this.$editable)	return;
			var x,y,from,to,n;
			if(GooFlow.prototype.useSVG!=""){
				from=jq.attr("from").split(",");
				to=jq.attr("to").split(",");
				n=[from[0],from[1],to[0],to[1]];
			}else{
				n=jq[0].getAttribute("fromTo").split(",");
				from=[n[0],n[1]];
				to=[n[2],n[3]];
			}
			from[0]=parseInt(from[0],10);
			from[1]=parseInt(from[1],10);
			to[0]=parseInt(to[0],10);
			to[1]=parseInt(to[1],10);
			if(this.$lineData[id].type=="lr"){
				from[0]=this.$lineData[id].M*this.$scale;
				to[0]=from[0];
				
				this.$lineMove.css({
					width:"5px",height:(to[1]-from[1])*(to[1]>from[1]? 1:-1)+"px",
					left:from[0]-3+"px",
					top:(to[1]>from[1]? from[1]:to[1])+1+"px",
					cursor:"e-resize",display:"block"
				}).data({"type":"lr","tid":id});
			}
			else if(this.$lineData[id].type=="tb"){
				from[1]=this.$lineData[id].M*this.$scale;
				to[1]=from[1];
				this.$lineMove.css({
					width:(to[0]-from[0])*(to[0]>from[0]? 1:-1)+"px",height:"5px",
					left:(to[0]>from[0]? from[0]:to[0])+1+"px",
					top:from[1]-3+"px",
					cursor:"s-resize",display:"block"
				}).data({"type":"tb","tid":id});
			}
			x=(from[0]+to[0])/2-40;
			y=(from[1]+to[1])/2+4;
			if(this.$editable){
				this.$mpFrom.css({display:"block",left:n[0]-4+"px",top:n[1]-4+"px"}).data("p",n[0]+","+n[1]);
				this.$mpTo.css({display:"block",left:n[2]-4+"px",top:n[3]-4+"px"}).data("p",n[2]+","+n[3]);
			}
			this.$draw.appendChild(jq[0]);
		}
		this.$focus=id;
		this.switchToolBtn("cursor");
	},
	//移动结点到一个新的位置
	moveNode:function(id,left,top){
		if(!this.$nodeData[id])	return;
		if(this.onItemMove!=null&&!this.onItemMove(id,"node",left,top))	return;
		if(left<0)	left=0;
		if(top<0)	top=0;
		$("#"+id).css({left:left*this.$scale+"px",top:top*this.$scale+"px"});
		this.$nodeData[id].left=left;
		this.$nodeData[id].top=top;
		//重画转换线
		this.resetLines(id,this.$nodeData[id]);
		if(this.$editable){
			this.$nodeData[id].alt=true;
		}
	},
	//设置结点/连线/分组区域的文字信息
	setName:function(id,name,type){
		var oldName;
		if(type=="node"){//如果是结点
			name=parseInt(name.trim());
			if(!this.$nodeData[id])
				return;
			if(this.$nodeData[id].name==name)
				return;
			if(this.onItemRename!=null&&!this.onItemRename(id,name,"node"))
				return;
			if(isNaN(name))
			{
				this.addLog("结点编号只允许用数字",true);
				return;
			}
			oldName=this.$nodeData[id].name;
			this.$nodeData[id].name=name;
			if(this.$nodeData[id].type.indexOf("round")>1){
				this.$nodeDom[id].children(".span").text(name);
			}
			else{
				this.$nodeDom[id].find("td:eq(1)").children("div").text(name);

				var width=this.$nodeDom[id].outerWidth();
				var height=this.$nodeDom[id].outerHeight();
				this.$nodeDom[id].children("table").css({width:width-2+"px",height:height-2+"px"});
				this.$nodeData[id].width=width;
				this.$nodeData[id].height=height;
			}
			if(this.$editable){
				this.$nodeData[id].alt=true;
			}
			//重画转换线
			this.resetLines(id,this.$nodeData[id]);
		}
		else if(type=="line"){//如果是线
			if(!this.$lineData[id])	return;
			name=name.replace(/<|>|-/g,"");
			if(this.$lineData[id].name==name)
			{
				return;
			}
			if(this.onItemRename!=null&&!this.onItemRename(id,name,"line"))	return;
			oldName=this.$lineData[id].name;
			if(oldName != name.trim())
			{
				var tmpname = name.trim();
				this.clearDivSlotArc("");
				if(tmpname != "" && tmpname !="-")
				{
					var flag =false;
					for(var i in this.$slotMsg)
					{
						if(tmpname ==i)
						{
							flag = true;
							break;
						}
					}
					if(!flag)
					{
						this.$slotMsg[tmpname]=[];
						this.setLineType(id,"al");
						this.addLog("结点"+this.$nodeData[this.$lineData[id].from].name+"与结点"+this.$nodeData[this.$lineData[id].to].name+"之间变为弧");
					}else
					{
						this.setLineType(id,"cl");
						this.addLog("结点"+this.$nodeData[this.$lineData[id].from].name+"与结点"+this.$nodeData[this.$lineData[id].to].name+"之间变为槽");
					}
					this.showArcSlotMsg(tmpname,id);
					if(this.$slotMsg[tmpname].length>0)
					{
						var tmpFlag=false;
						for(var i in this.$usedSlots)
						{
							if(tmpname==i)
							{
								this.$usedSlots[i]++;
								tmpFlag=true;
								break;
							}
						}
						if(!tmpFlag)
							this.$usedSlots[tmpname]=1;
					}
				}
				else
				{
					name = "-";
					this.setLineType(id,"xl");
					this.addLog("结点"+this.$nodeData[this.$lineData[id].from].name+"与结点"+this.$nodeData[this.$lineData[id].to].name+"之间变为空弧");
				}
				if(oldName!="" && oldName!="-")
				{
					if(this.$slotMsg[oldName].length>0)
					{
						for(var i in this.$usedSlots)
						{
							if(oldName==i)
							{
								this.$usedSlots[i]--;
								if(this.$usedSlots[i]==0)
									delete this.$usedSlots[i];
								break;
							}
						}
					}
					if(this.$slotMsg[oldName].length==0)
					{
						delete this.$slotMsg[oldName];
					}
				}
			}
			this.$lineData[id].name=name;
			if(GooFlow.prototype.useSVG!=""){
				if(name!="" && name!="-")
					if(this.$slotMsg[name].length>0)
						name="<"+name+">";
				this.$lineDom[id].childNodes[2].textContent=name;
			}
			else{
				this.$lineDom[id].childNodes[1].innerHTML=name;
				var n=this.$lineDom[id].getAttribute("fromTo").split(",");
				var x;
				if(this.$lineData[id].type!="lr"){
					x=(n[2]-n[0])/2;
				}
				else{
					var Min=n[2]>n[0]? n[0]:n[2];
					if(Min>this.$lineData[id].M) Min=this.$lineData[id].M;
					x=this.$lineData[id].M-Min;
				}
				if(x<0) x=x*-1;
				this.$lineDom[id].childNodes[1].style.left=x-this.$lineDom[id].childNodes[1].offsetWidth/2+4+"px";
			}
			if(this.$editable){
				this.$lineData[id].alt=true;
			}
		}
		else if(type=="area"){//如果是分组区域
			if(!this.$areaData[id])	return;
			if(this.$areaData[id].name==name)	return;
			if(this.onItemRename!=null&&!this.onItemRename(id,name,"area"))	return;
			oldName=this.$areaData[id].name;
			this.$areaData[id].name=name;
			this.$areaDom[id].children("label").text(name);
			if(this.$editable){
				this.$areaData[id].alt=true;
			}
		}
	},
	//设置结点的尺寸,仅支持非开始/结束结点
	resizeNode:function(id,width,height){
		if(!this.$nodeData[id])	return;
		if(this.onItemResize!=null&&!this.onItemResize(id,"node",width,height))	return;
		if(this.$nodeData[id].type=="start"||this.$nodeData[id].type=="end")return;

		this.$nodeDom[id].children("table").css({width:(width-2)*this.$scale+"px",height:(height-2)*this.$scale+"px"});
		//确保因内部文字太多而撑大时，宽高尺寸仍然是精确的
		width=this.$nodeDom[id].outerWidth();
		height=this.$nodeDom[id].outerHeight();
		this.$nodeDom[id].children("table").css({width:width-2+"px",height:height-2+"px"});
        //确保因内部文字太多而撑大时，宽高尺寸仍然是精确的 END
		this.$nodeData[id].width=width;
		this.$nodeData[id].height=height;
		if(this.$editable){
			this.$nodeData[id].alt=true;
		}
		//重画转换线
		this.resetLines(id,this.$nodeData[id]);
	},
	//删除结点
	delNode:function(id,trigger){
		if(!this.$nodeData[id])	return;
		if(false!=trigger && this.onItemDel!=null&&!this.onItemDel(id,"node"))	return;
		//先删除可能的连线
		for(var k in this.$lineData){
			if(this.$lineData[k].from==id||this.$lineData[k].to==id){
				this.delLine(k,false);
			}
		}
		//再删除结点本身
		if(this.$undoStack){
			var paras=[id,this.$nodeData[id]];
			this.pushOper("addNode",paras);
		}
		delete this.$nodeData[id];
		this.$nodeDom[id].remove();
		delete this.$nodeDom[id];
		--this.$nodeCount;
		if(this.$focus==id)	this.$focus="";

		if(this.$editable){
			//在回退新增操作时,如果节点ID以this.$id+"_node_"开头,则表示为本次编辑时新加入的节点,这些节点的删除不用加入到$deletedItem中
			//if(id.indexOf(this.$id+"_node_")<0)
				this.$deletedItem[id]="node";
		}
	},
	//设置流程图的名称
	setTitle:function(text){
		this.$title=text;
		if(this.$head)	this.$head.children("label").attr("title",text).text(text);
	},
    //仅供内部使用：计算流程图的实际宽高（单位像素）
	suitSize:function(){
        var maxW=0,maxH=0;
        for(var key in this.$nodeData){
            var item = this.$nodeData[key];
            if(maxW < item.width+item.left){
                maxW = item.width+item.left;
            }
            if(maxH < item.height+item.top){
                maxH = item.height+item.top;
            }
        }
        for(var key in this.$areaData){
            var item = this.$areaData[key];
            if(maxW < item.width+item.left){
                maxW = item.width+item.left;
            }
            if(maxH < item.height+item.top){
                maxH = item.height+item.top;
            }
        }
        for(var key in this.$lineData){
            var item = this.$lineData[key];
            if(item.M && item.type=="lt" && maxW < item.M ){
                maxW = M+4;
            }
            if(item.M && item.type=="tb" && maxH < item.M ){
                maxH = M+4;
            }
        }
        return {width:maxW,height:maxH}

	},
	//
	addSlotMsg:function(id,json)
	{
		this.$slotMsg[id]=json;
	},
	//载入一组数据
	loadData:function(data){
		if(data==undefined) return;
		if(JSON.stringify(data)=="{}") return;
		var t=this.$editable;
		this.$editable=false;
		this.$slotMsg=data.slots;
		if(data.title)	this.setTitle(data.title);
		if(data.initNum)	this.$max=data.initNum;
		for(var i in data.nodes)
			this.addNode(i,data.nodes[i]);
		for(var j in data.lines)
			this.addLine(j,data.lines[j]);
		for(var k in data.areas)
			this.addArea(k,data.areas[k]);
		for(var l in data.slots)
			this.addSlotMsg(l,data.slots[l]);
		this.$editable=t;
		this.$deletedItem={};
		//自行重构工作区，使之大小自适应
        var width=this.$workArea.width();
        var height=this.$workArea.height();
        var max=this.suitSize();
        while(max.width>width){
            width+=this.$workExtendStep;
        }
        while(max.height>height){
            height+=this.$workExtendStep;
        }
        this.$workArea.css({height:height+"px",width:width+"px"});
        if(GooFlow.prototype.useSVG==""){
            this.$draw.coordsize = width+","+height;
        }
        this.$draw.style.width = width + "px";
        this.$draw.style.height = height + "px";
        if(this.$group!=null){
            this.$group.css({height:height+"px",width:width+"px"});
        }
	},
	//用AJAX方式，远程读取一组数据
	//参数para为JSON结构，与JQUERY中$.ajax()方法的传参一样
	loadDataAjax:function(para){
		var This=this;
		$.ajax({
			type:para.type,
			url:para.url,
			dataType:"json",
			data:para.data,
			success: function(msg){
				if(para.dataFilter)	para.dataFilter(msg,"json");
     			This.loadData(msg);
				if(para.success)	para.success(msg);
   			},
			error: function(XMLHttpRequest, textStatus, errorThrown){
				if(para.error)	para.error(textStatus,errorThrown);
			}
		})
	},
	//把画好的整个流程图导出到一个变量中(其实也可以直接访问GooFlow对象的$nodeData,$lineData,$areaData这三个JSON属性)
	exportData:function(){
		var ret={};
		ret.title=this.$title;
		ret.nodes={};
		ret.lines={};
		ret.areas={};
		ret.initNum=this.$max;
		for(var k1 in this.$nodeData){
			if(!this.$nodeData[k1].marked){
				delete this.$nodeData[k1]["marked"];
			}
			ret.nodes[k1]=JSON.parse(JSON.stringify(this.$nodeData[k1]));
        }
		for(var k2 in this.$lineData){
			if(!this.$lineData[k2].marked){
				delete this.$lineData[k2]["marked"];
			}
            ret.lines[k2]=JSON.parse(JSON.stringify(this.$lineData[k2]));
		}
        for(var k3 in this.$areaData){
            if(!this.$areaData[k3].marked){
                delete this.$areaData[k3]["marked"];
            }
            ret.areas[k3]=JSON.parse(JSON.stringify(this.$areaData[k3]));
        }
		return ret;
	},
	//只把本次编辑流程图中作了变更(包括增删改)的元素导出到一个变量中,以方便用户每次编辑载入的流程图后只获取变更过的数据
	exportAlter:function(){
		var ret={nodes:{},lines:{},areas:{}};
		for(var k1 in this.$nodeData){
			if(this.$nodeData[k1].alt){
				ret.nodes[k1]=this.$nodeData[k1];
			}
		}
		for(var k2 in this.$lineData){
			if(this.$lineData[k2].alt){
				ret.lines[k2]=this.$lineData[k2];
			}
		}
		for(var k3 in this.$areaData){
			if(this.$areaData[k3].alt){
				ret.areas[k3]=this.$areaData[k3];
			}
		}
		ret.deletedItem=this.$deletedItem;
		return ret;
	},
	//变更元素的ID,一般用于快速保存后,将后台返回新元素的ID更新到页面中;type为元素类型(节点,连线,区块)
	transNewId:function(oldId,newId,type){
		var tmp;
		switch(type){
			case "node":
			if(this.$nodeData[oldId]){
				tmp=this.$nodeData[oldId];
				delete this.$nodeData[oldId];
				this.$nodeData[newId]=tmp;
				tmp=this.$nodeDom[oldId].attr("id",newId);
				delete this.$nodeDom[oldId];
				this.$nodeDom[newId]=tmp;
			}
			break;
			case "line":
			if(this.$lineData[oldId]){
				tmp=this.$lineData[oldId];
				delete this.$lineData[oldId];
				this.$lineData[newId]=tmp;
				tmp=this.$lineDom[oldId].attr("id",newId);
				delete this.$lineDom[oldId];
				this.$lineDom[newId]=tmp;
			}
			break;
			case "area":
			if(this.$areaData[oldId]){
				tmp=this.$areaData[oldId];
				delete this.$areaData[oldId];
				this.$areaData[newId]=tmp;
				tmp=this.$areaDom[oldId].attr("id",newId);
				delete this.$areaDom[oldId];
				this.$areaDom[newId]=tmp;
			}
			break;
		}
	},
	//清空工作区及已载入的数据
	clearData:function(){
		for(var key in this.$nodeData){
			this.delNode(key);
		}
		for(var key in this.$lineData){
			this.delLine(key);
		}
		for(var key in this.$areaData){
			this.delArea(key);
		}
		this.$deletedItem={};
	},
	//销毁自己
	destrory:function(){
		this.$bgDiv.empty();
		this.$lineData=null;
		this.$nodeData=null;
		this.$lineDom=null;
		this.$nodeDom=null;
		this.$areaDom=null;
		this.$areaData=null;
		this.$nodeCount=0;
		this.$areaCount=0;
		this.$areaCount=0;
		this.$deletedItem={};
	},
///////////以下为有关画线的方法
	//绘制一条箭头线，并返回线的DOM
	drawLine:function(id,sp,ep,mark,dash,$scale,name,obj,type){
		var line;
		if(GooFlow.prototype.useSVG!=""){
			line=document.createElementNS("http://www.w3.org/2000/svg","g");
			var hi=document.createElementNS("http://www.w3.org/2000/svg","path");
			var path=document.createElementNS("http://www.w3.org/2000/svg","path");

			if(id!="")	line.setAttribute("id",id);
			line.setAttribute("from",sp[0]+","+sp[1]);
			line.setAttribute("to",ep[0]+","+ep[1]);
			if(type=="cxl" || type=="axl")
			{
				hi.setAttribute("visibility","visible");	
				if(type=="axl")
				{
					hi.setAttribute("stroke","#FF0000");
				}
				else
				{
					hi.setAttribute("stroke","#3892D3");
				}
			}
			else
			{
				hi.setAttribute("visibility","hidden");
				hi.setAttribute("stroke","white");
			}
			hi.setAttribute("stroke-width",4);
			hi.setAttribute("style", "stroke-dasharray:6,5");
			hi.setAttribute("fill","none");
			hi.setAttribute("d","M "+sp[0]+" "+sp[1]+" L "+ep[0]+" "+ep[1]);
			hi.setAttribute("pointer-events","stroke");
			path.setAttribute("d","M "+sp[0]+" "+sp[1]+" L "+ep[0]+" "+ep[1]);
			path.setAttribute("stroke-width",1.4);
			path.setAttribute("stroke-linecap","round");
			path.setAttribute("fill","none");
			if(dash)	path.setAttribute("style", "stroke-dasharray:6,5");
			if(mark){
				path.setAttribute("stroke",GooFlow.prototype.color.mark||"#ff8800");
				path.setAttribute("marker-end","url(#arrow2)");
				//hi.setAttribute("marker-end","url(#arrow2)");
			}
			else{
				path.setAttribute("stroke",GooFlow.prototype.color.line||"#3892D3");
				path.setAttribute("marker-end","url(#arrow1)");
				//hi.setAttribute("marker-end","url(#arrow1)");
			}
			line.appendChild(hi);
			line.appendChild(path);
			line.style.cursor="crosshair";
			if(id!=""&&id!="GooFlow_tmp_line"){
				var text=document.createElementNS("http://www.w3.org/2000/svg","text");
				text.setAttribute("fill",GooFlow.prototype.color.lineFont||"#333");
				if(name=="" || name=="-")
					text.textContent=name;
				else
				{
					if(obj.$slotMsg[name].length>0)
						text.textContent="<"+name+">";
					else
						text.textContent=name;
				}
				if(name!="" && name!="-")
				{
					if(obj.$slotMsg[name].length>0)
					{
						var tmpFlag=false;
						for(var j in obj.$usedSlots)
						{
							if(j==name)
							{
								obj.$usedSlots[j]++;
								tmpFlag=true;
								break;
							}
						}
						if(!tmpFlag)
							obj.$usedSlots[name]=1;
					}
				}
				line.appendChild(text);
				var x=(ep[0]+sp[0])/2;
				var y=(ep[1]+sp[1])/2;
				text.setAttribute("text-anchor","middle");
				text.setAttribute("x",x);
				text.setAttribute("y",y);
				line.style.cursor="pointer";
				text.style.cursor="text";
                text.style.fontSize=14*$scale+"px";
			}
		}
		return line;
	},
	//画一条三个以上点的折线
	drawPolyLine:function(id,arr,linedata,$scale,obj){
		var poly,strPath,minx,miny;
		var type=linedata.type,mark=linedata.mark,name=linedata.name;
		for(var i=0;i<arr.length;i++)
		{
			arr[i]["x"]+=50+14;
			arr[i]["y"]+=10+14;
		}
		if(arr.length>2)
		{
			minx=arr[parseInt(arr.length/2)]["y"];
			miny=arr[parseInt(arr.length/2)]["x"];
		}
		else
		{
			minx=(arr[0]["y"]+arr[1]["y"])/2;
			miny=(arr[0]["x"]+arr[1]["x"])/2;
		}
		var sp=arr.shift();
		var ep=arr.pop();
		poly=document.createElementNS("http://www.w3.org/2000/svg","g");
		var hi=document.createElementNS("http://www.w3.org/2000/svg","path");
		var path=document.createElementNS("http://www.w3.org/2000/svg","path");
		if(id!="")	poly.setAttribute("id",id);
		poly.setAttribute("from",sp["y"]+","+sp["x"]);
		poly.setAttribute("to",ep["y"]+","+ep["x"]);
		if(type=="cxl" || type=="axl")
		{
			hi.setAttribute("visibility","visible");	
			if(type=="axl")
			{
				hi.setAttribute("stroke","#FF0000");
			}
			else
			{
				hi.setAttribute("stroke","#3892D3");
			}
		}
		else
		{
			hi.setAttribute("visibility","hidden");
			hi.setAttribute("stroke","white");
		}
		hi.setAttribute("style", "stroke-dasharray:6,5");
		hi.setAttribute("stroke-width",4);
		hi.setAttribute("fill","none");	
		strPath="M "+sp["y"]+" "+sp["x"];
		for(var i=0;i<arr.length;i++)
		{
			strPath+=" L "+arr[i]["y"]+" "+arr[i]["x"];
		}
		strPath+=" L "+ep["y"]+" "+ep["x"];
		hi.setAttribute("d",strPath);
		hi.setAttribute("pointer-events","stroke");
		path.setAttribute("d",strPath);
		path.setAttribute("stroke-width",1.4);
		path.setAttribute("stroke-linecap","round");
		path.setAttribute("fill","none");
		if(type=="xl")	path.setAttribute("style", "stroke-dasharray:6,5");
		if(mark){
			path.setAttribute("stroke",GooFlow.prototype.color.mark||"#ff8800");
			path.setAttribute("marker-end","url(#arrow2)");
			//hi.setAttribute("marker-end","url(#arrow2)")
		}
		else{
			path.setAttribute("stroke",GooFlow.prototype.color.line||"#3892D3");
			path.setAttribute("marker-end","url(#arrow1)");
			//hi.setAttribute("marker-end","url(#arrow1)");
		}
		poly.appendChild(hi);
		poly.appendChild(path);
		var text=document.createElementNS("http://www.w3.org/2000/svg","text");
		text.setAttribute("fill",GooFlow.prototype.color.lineFont||"#333");
		if(name=="" || name=="-")
			text.textContent=name;
		else
		{
			if(obj.$slotMsg[name].length>0)
				text.textContent="<"+name+">";
			else
				text.textContent=name;
		}
		if(name!="" && name!="-")
		{
			if(obj.$slotMsg[name].length>0)
			{
				var tmpFlag=false;
				for(var j in obj.$usedSlots)
				{
					if(j==name)
					{
						obj.$usedSlots[j]++;
						tmpFlag=true;
						break;
					}
				}
				if(!tmpFlag)
					obj.$usedSlots[name]=1;
			}
		}
		poly.appendChild(text);
		var x=minx;
		var y=miny;
		text.setAttribute("text-anchor","middle");
		text.setAttribute("x",x);
		text.setAttribute("y",y);
		text.style.cursor="text";
		poly.style.cursor="pointer";
		text.style.fontSize=14*$scale+"px";
		return poly;
	},
	//画一条只有两个中点的折线
	drawPoly:function(id,sp,m1,m2,ep,mark,dash,$scale){
		var poly,strPath;
		if(GooFlow.prototype.useSVG!=""){
			poly=document.createElementNS("http://www.w3.org/2000/svg","g");
			var hi=document.createElementNS("http://www.w3.org/2000/svg","path");
			var path=document.createElementNS("http://www.w3.org/2000/svg","path");
			if(id!="")	poly.setAttribute("id",id);
			poly.setAttribute("from",sp[0]+","+sp[1]);
			poly.setAttribute("to",ep[0]+","+ep[1]);
			hi.setAttribute("visibility","hidden");
			hi.setAttribute("stroke-width",9);
			hi.setAttribute("fill","none");
			hi.setAttribute("stroke","white");
			strPath="M "+sp[0]+" "+sp[1];
			if(m1[0]!=sp[0]||m1[1]!=sp[1])
				strPath+=" L "+m1[0]+" "+m1[1];
			if(m2[0]!=ep[0]||m2[1]!=ep[1])
				strPath+=" L "+m2[0]+" "+m2[1];
			strPath+=" L "+ep[0]+" "+ep[1];
			hi.setAttribute("d",strPath);
			hi.setAttribute("pointer-events","stroke");
			path.setAttribute("d",strPath);
			path.setAttribute("stroke-width",mark? 2.4:1.4);
			path.setAttribute("stroke-linecap","round");
			path.setAttribute("fill","none");
            if(dash)	path.setAttribute("style", "stroke-dasharray:6,5");
			if(mark){
				path.setAttribute("stroke",GooFlow.prototype.color.mark||"#ff8800");
				path.setAttribute("marker-end","url(#arrow2)");
			}
			else{
				path.setAttribute("stroke",GooFlow.prototype.color.line||"#3892D3");
				path.setAttribute("marker-end","url(#arrow1)");
			}
			poly.appendChild(hi);
			poly.appendChild(path);
			var text=document.createElementNS("http://www.w3.org/2000/svg","text");
			text.setAttribute("fill",GooFlow.prototype.color.lineFont||"#333");
			poly.appendChild(text);
			var x=(m2[0]+m1[0])/2;
			var y=(m2[1]+m1[1])/2;
			text.setAttribute("text-anchor","middle");
			text.setAttribute("x",x);
			text.setAttribute("y",y);
			text.style.cursor="text";
			poly.style.cursor="pointer";
            text.style.fontSize=14*$scale+"px";
		}
		else{
			poly=document.createElement("v:Polyline");
			if(id!="")	poly.id=id;
			poly.filled="false";
			strPath=sp[0]+","+sp[1];
			if(m1[0]!=sp[0]||m1[1]!=sp[1])
				strPath+=" "+m1[0]+","+m1[1];
			if(m2[0]!=ep[0]||m2[1]!=ep[1])
				strPath+=" "+m2[0]+","+m2[1];
			strPath+=" "+ep[0]+","+ep[1];
			poly.points.value=strPath;
			poly.setAttribute("fromTo",sp[0]+","+sp[1]+","+ep[0]+","+ep[1]);
			poly.strokeWeight=mark? "2.4":"1.2";
			poly.stroke.EndArrow="Block";
			var text=document.createElement("div");
			//text.innerHTML=id;
			poly.appendChild(text);
			var x=(m2[0]-m1[0])/2;
			var y=(m2[1]-m1[1])/2;
			if(x<0) x=x*-1;
			if(y<0) y=y*-1;
			text.style.left=x+"px";
			text.style.top=y-4+"px";
            text.style.fontSize=14*$scale+"px";
            text.style.color=GooFlow.prototype.color.lineFont||"#333";
			poly.style.cursor="pointer";
            if(dash)	poly.stroke.dashStyle="Dash";
			if(mark)	poly.strokeColor=GooFlow.prototype.color.mark||"#ff8800";
			else	poly.strokeColor=GooFlow.prototype.color.line||"#3892D3";
		}
		return poly;
	},
	//计算两个结点间要连直线的话，连线的开始坐标和结束坐标
	calcStartEnd:function(type,n1,n2,scale){
		if(!scale)	scale=1.0;
		var X_1,Y_1,X_2,Y_2;
		//X判断：
		var x11=n1.left*scale ,x12=n1.left*scale +n1.width*scale ,x21=n2.left*scale ,x22=n2.left*scale +n2.width*scale ;
		//结点2在结点1左边
		if(x11>=x22){
			X_1=x11;X_2=x22;
		}
		//结点2在结点1右边
		else if(x12<=x21){
			X_1=x12;X_2=x21;
		}
		//结点2在结点1水平部分重合
		else if(x11<=x21&&x12>=x21&&x12<=x22){
			X_1=(x12+x21)/2;X_2=X_1;
		}
		else if(x11>=x21&&x12<=x22){
			X_1=(x11+x12)/2;X_2=X_1;
		}
		else if(x21>=x11&&x22<=x12){
			X_1=(x21+x22)/2;X_2=X_1;
		}
		else if(x11<=x22&&x12>=x22){
			X_1=(x11+x22)/2;X_2=X_1;
		}
		
		//Y判断：
		var y11=n1.top*scale ,y12=n1.top*scale +n1.height*scale ,y21=n2.top*scale ,y22=n2.top*scale +n2.height*scale ;
		//结点2在结点1上边
		if(y11>=y22){
			Y_1=y11;Y_2=y22;
		}
		//结点2在结点1下边
		else if(y12<=y21){
			Y_1=y12;Y_2=y21;
		}
		//结点2在结点1垂直部分重合
		else if(y11<=y21&&y12>=y21&&y12<=y22){
			Y_1=(y12+y21)/2;Y_2=Y_1;
		}
		else if(y11>=y21&&y12<=y22){
			Y_1=(y11+y12)/2;Y_2=Y_1;
		}
		else if(y21>=y11&&y22<=y12){
			Y_1=(y21+y22)/2;Y_2=Y_1;
		}
		else if(y11<=y22&&y12>=y22){
			Y_1=(y11+y22)/2;Y_2=Y_1;
		}
		var ret = {};
		ret = {"start":[X_1,Y_1],"end":[X_2,Y_2]};
		return ret;
	},

	//
	addDuodianLine:function(id,arr,json)
	{
		if(this.onItemAdd!=null&&!this.onItemAdd(id,"line",json))return;
		if(this.$undoStack&&this.$editable){
			this.pushOper("delLine",[id]);
		}
		if(json.from==json.to)	return;
		var n1=this.$nodeData[json.from],n2=this.$nodeData[json.to];//获取开始/结束结点的数据
		if(!n1||!n2)	return;
		//避免两个节点间不能有一条以上同向接连线
		for(var k in this.$lineData){
			if((json.from==this.$lineData[k].from&&json.to==this.$lineData[k].to&&json.dash==this.$lineData[k].dash))
				return;
		}
		//设置$lineData[id]
		this.$lineData[id]={};
		if(json.type){
			this.$lineData[id].type=json.type;
			this.$lineData[id].M=json.M;
		}
		else
		{
			if(json.name=="" || json.name =="-")
			{
				this.$lineData[id].type="xl";
			}else
			{
				this.$lineData[id].type="cl";//默认为直线
			}
		}
		this.$lineData[id].from=json.from;
		this.$lineData[id].to=json.to;
		this.$lineData[id].name=json.name;
		if(json.marked)	this.$lineData[id].marked=json.marked;
		else	this.$lineData[id].marked=false;
        if(json.dash)	this.$lineData[id].dash=json.dash;
        else	this.$lineData[id].dash=false;
		//设置$lineData[id]完毕
		var lineData=this.$lineData[id];
		if(lineData.type=="xl")
			lineData.dash=true;
		if(lineData.name.trim()=="")
			lineData.name="-";
		this.$lineDom[id]=GooFlow.prototype.drawPolyLine(id,arr,lineData,this.$scale,this);
		for(var i=0;i<this.$endNodes.length;i++)
		{
			if(this.$endNodes[i]==json.from)
			{
				this.$endNodes.splice(i,1);
				this.$nodeDom[json.from].css({"background-color":"#c0ccda"});
				break;
			}
		}
		this.$draw.appendChild(this.$lineDom[id]);	
		//this.$lineDom[id].childNodes[2].textContent=lineData.name;
		if(lineData.name!="-" && this.$slotMsg[lineData.name].length==0)
			$("#"+id)[0].childNodes[1].setAttribute("stroke","#FF0000");
		var isWebkit = navigator.userAgent.toLowerCase().indexOf('webkit') > -1;
			
		++this.$lineCount;
		if(this.$editable){
			this.$lineData[id].alt=true;
			if(this.$deletedItem[id])	delete this.$deletedItem[id];//在回退删除操作时,去掉该元素的删除记录
		}
	},
	//原lineData已经设定好的情况下，只在绘图工作区画一条线的页面元素
	addLineDom:function(id,lineData){
		var n1=this.$nodeData[lineData.from],n2=this.$nodeData[lineData.to];//获取开始/结束结点的数据
		if(!n1||!n2)	return;
		//开始计算线端点坐标
		var res;
		if(lineData.type)
		{
			res=GooFlow.prototype.calcStartEnd(lineData.type,n1,n2, this.$scale);
		}
		if(!res)	return;
		if(lineData.name.trim()=="")
			lineData.name="-";
		if(lineData.type=="cl" || lineData.type=="xl")
		{
			if(lineData.type=="xl")
				lineData.dash=true;
			this.$lineDom[id]=GooFlow.prototype.drawLine(id,res.start,res.end,lineData.marked,lineData.dash, this.$scale,lineData.name,this);
		}
		this.$draw.appendChild(this.$lineDom[id]);
		for(var j=0;j<this.$endNodes.length;j++)
		{
			if(this.$endNodes[j]==this.$lineData[id].from)
			{
				this.$endNodes.splice(j,1);
				this.$nodeDom[this.$lineData[id].from].css({"background-color":"#c0ccda"});
				break;
			}
		}
		if(GooFlow.prototype.useSVG==""){
			this.$lineDom[id].childNodes[1].innerHTML=lineData.name;
			if(lineData.type!="cl"){
				var Min=(res.start[0]>res.end[0]? res.end[0]:res.start[0]);
				if(Min>res.m2[0])	Min=res.m2[0];
				if(Min>res.m1[0])	Min=res.m1[0];
				this.$lineDom[id].childNodes[1].style.left = (res.m2[0]+res.m1[0])/2-Min-this.$lineDom[id].childNodes[1].offsetWidth/2+4;
				Min=(res.start[1]>res.end[1]? res.end[1]:res.start[1]);
				if(Min>res.m2[1])	Min=res.m2[1];
				if(Min>res.m1[1])	Min=res.m1[1];
				this.$lineDom[id].childNodes[1].style.top = (res.m2[1]+res.m1[1])/2-Min-this.$lineDom[id].childNodes[1].offsetHeight/2;
			}else
				this.$lineDom[id].childNodes[1].style.left=
				((res.end[0]-res.start[0])*(res.end[0]>res.start[0]? 1:-1)-this.$lineDom[id].childNodes[1].offsetWidth)/2+4;
		}
		else{
			if(lineData.name!="-" && this.$slotMsg[lineData.name].length==0)
				$("#"+id)[0].childNodes[1].setAttribute("stroke","#FF0000");
            var isWebkit = navigator.userAgent.toLowerCase().indexOf('webkit') > -1;
        }
	},
	//增加一条线
	addLine:function(id,json){
		if(this.onItemAdd!=null&&!this.onItemAdd(id,"line",json))return;
		if(this.$undoStack&&this.$editable){
			this.pushOper("delLine",[id]);
		}
		if(json.from==json.to)	return;
		var n1=this.$nodeData[json.from],n2=this.$nodeData[json.to];//获取开始/结束结点的数据
		if(!n1||!n2)	return;
		//避免两个节点间不能有一条以上同向接连线
		for(var k in this.$lineData){
			if((json.from==this.$lineData[k].from&&json.to==this.$lineData[k].to&&json.dash==this.$lineData[k].dash))
				return;
		}
		//设置$lineData[id]
		this.$lineData[id]={};
		if(json.type){
			this.$lineData[id].type=json.type;
			this.$lineData[id].M=json.M;
		}
		else
		{
			if(json.name=="" || json.name =="-")
			{
				this.$lineData[id].type="xl";
			}else
			{
				this.$lineData[id].type="cl";//默认为直线
			}
		}
		this.$lineData[id].from=json.from;
		this.$lineData[id].to=json.to;
		this.$lineData[id].name=json.name;
		if(json.marked)	this.$lineData[id].marked=json.marked;
		else	this.$lineData[id].marked=false;
        if(json.dash)	this.$lineData[id].dash=json.dash;
        else	this.$lineData[id].dash=false;
		//设置$lineData[id]完毕
		
		this.addLineDom(id,this.$lineData[id]);
		
		++this.$lineCount;
		if(this.$editable){
			this.$lineData[id].alt=true;
			if(this.$deletedItem[id])	delete this.$deletedItem[id];//在回退删除操作时,去掉该元素的删除记录
		}
	},
	//重构所有连向某个结点的线的显示，传参结构为$nodeData数组的一个单元结构
	resetLines:function(id,node){
		for(var i in this.$lineData){
		  var other=null;//获取结束/开始结点的数据
		  var res;
		  if(this.$lineData[i].from==id){//找结束点
			other=this.$nodeData[this.$lineData[i].to]||null;
			if(other==null)	continue;
			//if(this.$lineData[i].type=="cl" || this.$lineData[i].type=="xl")
				res=GooFlow.prototype.calcStartEnd(this.$lineData[i].type,node,other, this.$scale);
			if(!res)	break;
		  }
		  else if(this.$lineData[i].to==id){//找开始点
			other=this.$nodeData[this.$lineData[i].from]||null;
			if(other==null)	continue;
				res=GooFlow.prototype.calcStartEnd(this.$lineData[i].type,other,node, this.$scale);
			if(!res)	break;
		  }
		  if(other==null)	continue;
		  this.$draw.removeChild(this.$lineDom[i]);
		  //if(this.$lineData[i].type=="cl" || this.$lineData[i].type=="xl")
		  {
			  if(this.$lineData[i].type=="xl")
				  this.$lineData[i].dash=true;
		  	  this.$lineDom[i]=GooFlow.prototype.drawLine(i,res.start,res.end,this.$lineData[i].marked,this.$lineData[i].dash, this.$scale,this.$lineData[i].name,this,this.$lineData[i].type);
		  }
		  this.$draw.appendChild(this.$lineDom[i]);
		  if(GooFlow.prototype.useSVG==""){
			this.$lineDom[i].childNodes[1].innerHTML=this.$lineData[i].name;
			if(this.$lineData[i].type!="cl"){
				var Min=(res.start[0]>res.end[0]? res.end[0]:res.start[0]);
				if(Min>res.m2[0])	Min=res.m2[0];
				if(Min>res.m1[0])	Min=res.m1[0];
				this.$lineDom[i].childNodes[1].style.left = (res.m2[0]+res.m1[0])/2-Min-this.$lineDom[i].childNodes[1].offsetWidth/2+4;
				Min=(res.start[1]>res.end[1]? res.end[1]:res.start[1]);
				if(Min>res.m2[1])	Min=res.m2[1];
				if(Min>res.m1[1])	Min=res.m1[1];
				this.$lineDom[i].childNodes[1].style.top = (res.m2[1]+res.m1[1])/2-Min-this.$lineDom[i].childNodes[1].offsetHeight/2-4;
			}else
				this.$lineDom[i].childNodes[1].style.left=
				((res.end[0]-res.start[0])*(res.end[0]>res.start[0]? 1:-1)-this.$lineDom[i].childNodes[1].offsetWidth)/2+4;
		  }
		  else
		  {		
			  if(this.$lineData[i].name!="-" && this.$slotMsg[this.$lineData[i].name].length==0)
			      $("#"+i)[0].childNodes[1].setAttribute("stroke","#FF0000");
		  }
		}
	},
	//重新设置连线的样式 newType= "sl":直线, "lr":中段可左右移动型折线, "tb":中段可上下移动型折线
	setLineType:function(id,newType,name){
		if(!newType||newType==null||newType==""||newType==this.$lineData[id].type)	return false;
		if(this.onLineSetType!=null&&!this.onLineSetType(id,newType))	return;
		var dash=false;
		var color="#3892D3";
		switch(newType)
		{
			case "al":
				color="#FF0000";
				$("#"+id)[0].childNodes[1].setAttribute("style", "");
				$("#"+id)[0].childNodes[0].setAttribute("visibility","hidden");
				break;
			case "cl":
				$("#"+id)[0].childNodes[1].setAttribute("style", "");
				$("#"+id)[0].childNodes[0].setAttribute("visibility","hidden");
				break;
			case "xl":
				this.clearDivSlotArc("");
				dash=true;
				$("#"+id)[0].childNodes[2].textContent="-";
				this.$lineData[id].name="-";
				$("#"+id)[0].childNodes[1].setAttribute("style", "stroke-dasharray:6,5");
				break;
			case "cxl":
				$("#"+id)[0].childNodes[1].setAttribute("style", "");
				$("#"+id)[0].childNodes[0].setAttribute("visibility","visible");
				$("#"+id)[0].childNodes[0].setAttribute("stroke",color);
				break;
			case "axl":
				color="#FF0000";
				$("#"+id)[0].childNodes[1].setAttribute("style", "");
				$("#"+id)[0].childNodes[0].setAttribute("visibility","visible");
				$("#"+id)[0].childNodes[0].setAttribute("stroke",color);
				break;
		}
		this.$lineData[id].type=newType;
		this.$lineData[id].dash=dash;
		
		$("#"+id)[0].childNodes[1].setAttribute("stroke",color);
		//$("#"+id)[0].childNodes[1].setAttribute("stroke-width",width);
		delete this.$lineData[id].M;

		if(this.$focus==id){
			this.focusItem(id);
		}
		if(this.$editable){
			this.$lineData[id].alt=true;
		}
	},
	//删除转换线
	delLine:function(id,trigger){
		if(!this.$lineData[id])	return;
		if(false!=trigger && this.onItemDel!=null&&!this.onItemDel(id,"node"))	return;
		if(this.$undoStack){
			var paras=[id,this.$lineData[id]];
			this.pushOper("addLine",paras);
		}
		this.$draw.removeChild(this.$lineDom[id]);
		delete this.$lineData[id];
		delete this.$lineDom[id];
		if(this.$focus==id)	this.$focus="";
		--this.$lineCount;
		if(this.$editable){
			//在回退新增操作时,如果节点ID以this.$id+"_line_"开头,则表示为本次编辑时新加入的节点,这些节点的删除不用加入到$deletedItem中
			this.$deletedItem[id]="line";
			this.$mpFrom.hide().removeData("p");
			this.$mpTo.hide().removeData("p");
		}
	},
	//变更连线两个端点所连的结点
	//参数：要变更端点的连线ID，新的开始结点ID、新的结束结点ID；如果开始/结束结点ID是传入null或者""，则表示原端点不变
	moveLinePoints:function(lineId, newStart, newEnd, noStack){
		if(newStart==newEnd)	return;
		if(!lineId||!this.$lineData[lineId])	return;
		if(newStart==null||newStart=="")
			newStart=this.$lineData[lineId].from;
		if(newEnd==null||newEnd=="")
			newEnd=this.$lineData[lineId].to;

		//避免两个节点间不能有一条以上同向接连线
		for(var k in this.$lineData){
			if((newStart==this.$lineData[k].from&&newEnd==this.$lineData[k].to))
				return;
		}
		if(this.onLinePointMove!=null&&!this.onLinePointMove(lineId,newStart,newEnd))	return;
		if(newStart!=null&&newStart!=""){
			this.$lineData[lineId].from=newStart;
		}
		if(newEnd!=null&&newEnd!=""){
			this.$lineData[lineId].to=newEnd;
		}
		//重建转换线
		this.$draw.removeChild(this.$lineDom[lineId]);
		this.addLineDom(lineId,this.$lineData[lineId]);
		if(this.$editable){
			this.$lineData[lineId].alt=true;
		}
	},
	
	//用颜色标注/取消标注一个结点或转换线，常用于显示重点或流程的进度。
	//这是一个在编辑模式中无用,但是在纯浏览模式中非常有用的方法，实际运用中可用于跟踪流程的进度。
	markItem:function(id,type,mark){
		if(type=="node"){
			if(!this.$nodeData[id])	return;
			if(this.onItemMark!=null&&!this.onItemMark(id,"node",mark))	return;
			this.$nodeData[id].marked=mark||false;
			if(mark){
				this.$nodeDom[id].addClass("item_mark").css("border-color",GooFlow.prototype.color.mark);
			}
			else{
				this.$nodeDom[id].removeClass("item_mark");
				if(id!=this.$focus) this.$nodeDom[id].css("border-color","transparent");
			}
			
		}else if(type=="line"){
			if(!this.$lineData[id])	return;
			if(this.onItemMark!=null&&!this.onItemMark(id,"line",mark))	return;
			this.$lineData[id].marked=mark||false;
			if(GooFlow.prototype.useSVG!=""){
				if(mark){
					this.$lineDom[id].childNodes[1].setAttribute("stroke",GooFlow.prototype.color.mark||"#ff8800");
					this.$lineDom[id].childNodes[1].setAttribute("marker-end","url(#arrow2)");
                    this.$lineDom[id].childNodes[1].setAttribute("stroke-width",2.4);
				}else{
					this.$lineDom[id].childNodes[1].setAttribute("stroke",GooFlow.prototype.color.line||"#3892D3");
					this.$lineDom[id].childNodes[1].setAttribute("marker-end","url(#arrow1)");
                    this.$lineDom[id].childNodes[1].setAttribute("stroke-width",1.4);
				}
			}else{
				if(mark){
                    this.$lineDom[id].strokeColor=GooFlow.prototype.color.mark||"#ff8800";
                    this.$lineDom[id].strokeWeight="2.4";
				}
				else{
                    this.$lineDom[id].strokeColor=GooFlow.prototype.color.line||"#3892D3";
                    this.$lineDom[id].strokeWeight="1.2";
				}
			}
		}
	},
	///log操作函数
	clearLog:function(){
		$("#logbox")[0].value="";
	},
	addLog:function(text,flag){
		$("#logbox")[0].value="";
		$("#logbox")[0].value=text;
		if(flag)
		{
			//$("#logbox")[0].style.color="red";
			//$("#logbox")[0].style.fontSize="28px";
			var i=0,timer=null;
			clearInterval(timer);
			timer=setInterval(function(){
				$("#logbox")[0].style.backgroundColor=i++%2?"red":"";
				i>8&&clearInterval(timer);
			},100);
		}
		// else
		// {
			// $("#logbox")[0].style.color="black";
			// $("#logbox")[0].style.fontSize="12px";
		// }
	},
	////////////////////////以下为区域分组块操作
	moveArea:function(id,left,top){
		if(!this.$areaData[id])	return;
		if(this.onItemMove!=null&&!this.onItemMove(id,"area",left,top))	return;

		if(left<0)	left=0;
		if(top<0)	top=0;
		$("#"+id).css({left:left*this.$scale+"px",top:top*this.$scale+"px"});
		this.$areaData[id].left=left;
		this.$areaData[id].top=top;
		if(this.$editable){
			this.$areaData[id].alt=true;
		}
	},
	//删除区域分组
	delArea:function(id, trigger){
		if(!this.$areaData[id])	return;

		if(false!=trigger && this.onItemDel!=null&&!this.onItemDel(id,"node"))	return;
		delete this.$areaData[id];
		this.$areaDom[id].remove();
		delete this.$areaDom[id];
		--this.$areaCount;
		if(this.$editable){
			//在回退新增操作时,如果节点ID以this.$id+"_area_"开头,则表示为本次编辑时新加入的节点,这些节点的删除不用加入到$deletedItem中
			//if(id.indexOf(this.$id+"_area_")<0)
			this.$deletedItem[id]="area";
		}
	},
	//设置区域分组的颜色
	setAreaColor:function(id,color){
		if(!this.$areaData[id])	return;
		if(color=="red"||color=="yellow"||color=="blue"||color=="green"){
			this.$areaDom[id].removeClass("area_"+this.$areaData[id].color).addClass("area_"+color);
			this.$areaData[id].color=color;
		}
		if(this.$editable){
			this.$areaData[id].alt=true;
		}
	},
	//设置区域分块的尺寸
	resizeArea:function(id,width,height){
		if(!this.$areaData[id])	return;
		if(this.onItemResize!=null&&!this.onItemResize(id,"area",width,height))	return;

		this.$areaDom[id].children(".bg").css({width:width*this.$scale+"px",height:height*this.$scale+"px"});

		width=this.$areaDom[id].outerWidth();
		height=this.$areaDom[id].outerHeight();
		this.$areaDom[id].children("bg").css({width:width+"px",height:height+"px"});

		this.$areaData[id].width=width;
		this.$areaData[id].height=height;
		if(this.$editable){
			this.$areaData[id].alt=true;
		}
	},
	addArea:function(id,json){
		if(this.onItemAdd!=null&&!this.onItemAdd(id,"area",json))return;

		this.$areaDom[id]=$("<div id='"+id+"' class='GooFlow_area area_"+json.color+"' style='top:"+json.top*this.$scale+"px;left:"+json.left*this.$scale+"px'><div class='bg' style='width:"+(json.width*this.$scale)+"px;height:"+(json.height*this.$scale)+"px'></div>"
		+"<label>"+json.name+"</label><i></i><div><div class='rs_bottom'></div><div class='rs_right'></div><div class='rs_rb'></div><div class='rs_close'></div></div></div>");
		this.$areaData[id]=json;
		this.$group.append(this.$areaDom[id]);
		if(this.$nowType!="group")	this.$areaDom[id].children("div:eq(1)").css("display","none");
		++this.$areaCount;
		if(this.$editable){
			this.$areaData[id].alt=true;
			if(this.$deletedItem[id])	delete this.$deletedItem[id];//在回退删除操作时,去掉该元素的删除记录
		}
	},
	//重构整个流程图设计器的宽高
	reinitSize:function(width,height){
		var w=(width||this.$bgDiv.width());
		var h=(height||this.$bgDiv.height());
		this.$bgDiv.css({height:h+"px",width:w+"px"});
		var headHeight=0,hack=8;
		if(this.$head!=null){
			headHeight=26;
			hack=5;
		}
		if(this.$tool!=null){
			this.$tool.css({height:h-headHeight-hack+"px"});
			w-=31;
		}
		w-=9;
		h=h-headHeight-(this.$head!=null? 5:8);
		//this.$workArea.parent().css({height:h+"px",width:w+"px"});
		
		if(this.$workArea.width()>w){
			w=this.$workArea.width();
		}
		if(this.$workArea.height()>h){
			h=this.$workArea.height();
		}
		
		this.$workArea.css({height:h+"px",width:w+"px"});
		if(GooFlow.prototype.useSVG==""){
			this.$draw.coordsize = w+","+h;
		}
		this.$draw.style.width = w + "px";
		this.$draw.style.height = h + "px";
		if(this.$group!=null){
			this.$group.css({height:h+"px",width:w+"px"});
		}
	},
	//重设整个工作区内容的显示缩放比例，从0.5至4倍
	resetScale:function(scale){
		if(!scale)	scale=1.0;
		else if(scale<0.5)	scale=0.5;
		else if(scale>4)	scale=4;
		//以上是固定死取值范围：不让用户缩放过大或过小，已免无意中影响的显示效果
		if(this.$scale==scale)	return;
		var oldS=this.$scale;
		this.$scale=scale;
		var factor = oldS/scale;//因数（旧缩放比例除以新缩放比例）,元素的现有值除以该因子，就能得到新的缩放后的值
        var W=0,H=0,P={};//宽、高、左及上的临时变量
		//TODO:开始正式的缩放（节点、连线、泳道块有宽高和定位，其它编辑工具元素则只有定位）（全部以左上角为原点）
        this.blurItem();
		//先缩放工作区
        W=this.$workArea.width()/factor;
        H=this.$workArea.height()/factor;
        this.$workArea.css({"height":H+"px","width":W+"px"});
        if(GooFlow.prototype.useSVG!=""){

        }else{
            this.$draw.coordsize = W+","+H;
		}
        this.$draw.style.width = W + "px";
        this.$draw.style.height = H + "px";
        if(this.$group!=null){
            this.$group.css({height:H+"px",width:W+"px"});
        }
        //缩放节点
        var isWebkit = navigator.userAgent.toLowerCase().indexOf('webkit') > -1;
        this.$workArea.children(".GooFlow_item").each(function(i){
            var This=$(this);
            P=This.position();
            This.css({ "left":P.left/factor+"px", "top":P.top/factor+"px" });
            This=This.children("table");
            W=This.outerWidth()/factor;
            H=This.outerHeight()/factor;
            This.css({ "width":W+"px", "height":H+"px" });
            var tmp=18*scale;
            This.find("td[class='ico']").css({width:tmp+"px"});
            var newSize= {};
            if(tmp<12&&isWebkit){
                newSize["width"]="18px";newSize["height"]="18px";
                newSize["font-size"]="18px";
                newSize["transform"]="scale("+(tmp/18)+")";
                newSize["margin"]=-((18-tmp)/2)+"px";
            }else{
                newSize["width"]=tmp+"px"; newSize["height"]=tmp+"px";
                newSize["font-size"]=tmp+"px";
                newSize["transform"]="none";
                newSize["margin"]="0px auto";
            }
            This.find("td[class='ico']").children("i").css(newSize);

            tmp=14*scale;
            if(This.parent().find(".span").length==1){
                This.parent().css("border-radius",W/2+"px");
                This=This.parent().find(".span");
                This.css({"font-size":tmp+"px"});
            }else{
                This=This.find("td:eq(1) div");
                newSize={};
                if(tmp<12&&isWebkit){
                    newSize["font-size"]="14px";
                    newSize["transform"]="scale("+(tmp/14)+")";
                    var mW=(W/scale-18-(W-18*scale))/2;
                    var mH=(H/scale-H)/2;
                    newSize["margin"]=-mH+"px "+(-mW)+"px";
                }else{
                    newSize["transform"]="none";
                    newSize["font-size"]=tmp+"px";
                    newSize["margin"]="0px";
                }
                This.css(newSize);
            }
		});
        //缩放区域图
		var ifs=16*scale+2;
		var tttttt=this;
		this.$group.children(".GooFlow_area").each(function(i){
            var This=$(this);
            P=This.position();
            This.css({ "left":P.left/factor+"px", "top":P.top/factor+"px" });
            This=This.children("div:eq(0)");
            W=This.outerWidth()/factor;
            H=This.outerHeight()/factor;
            This.css({ "width":W+"px", "height":H+"px" });
            This.next("label").css({
				"font-size": 14*scale+"px",
				"left": ifs+3+"px"
            }).next("i").css({
				"font-size": ifs-2+"px",
				width:ifs+"px",
				height:ifs+"px",
				"line-height":ifs+"px"
            });
		});
		//缩放连线
		for(var id in this.$lineDom){
            this.$draw.removeChild(this.$lineDom[id]);
            delete this.$lineDom[id];
		}
        for (var key in this.$lineData) {
            this.addLineDom(key, this.$lineData[key]);
        }
	}
}
GooFlow.prototype.color={};
GooFlow.prototype.remarks={
    headBtns:{},
	toolBtns:{},
    extendRight:undefined,
    extendBottom:undefined
};
//将此类的构造函数加入至JQUERY对象中
jQuery.extend({
	createGooFlow:function(bgDiv,property){
		return new GooFlow(bgDiv,property);
	}
});
